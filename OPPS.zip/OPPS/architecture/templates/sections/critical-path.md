---
template: critical-path
version: "1.1"
owner_control: FWK-30
fields:
  - name: stage_id
    type: enum
    allowed: [S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11a, S11b]
    required: true
    consumer: [FWK-30, FWK-04, FWK-50]
  - name: hop_index
    type: int
    required: false
    consumer: [FWK-30]
  - name: elapsed_days_conservative
    type: range|UNKNOWN
    unit: days
    required: true
    consumer: [FWK-30, FWK-14, FWK-41, FWK-42, FWK-43]
  - name: elapsed_days_base
    type: range|UNKNOWN
    unit: days
    required: true
    consumer: [FWK-30, FWK-14, FWK-15, FWK-10]
  - name: elapsed_days_best
    type: range|UNKNOWN
    unit: days
    required: true
    consumer: [FWK-30, FWK-14, FWK-04]
  - name: provenance_conservative
    type: enum
    allowed: [MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN]
    required: true
    consumer: [FWK-63, FWK-30]
  - name: provenance_base
    type: enum
    allowed: [MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN]
    required: true
    consumer: [FWK-63, FWK-30]
  - name: provenance_best
    type: enum
    allowed: [MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN]
    required: true
    consumer: [FWK-63, FWK-30, FWK-04]
  - name: timing_tag
    type: enum
    allowed: [CALENDAR_FIXED, EFFORT_DRIVEN, CYCLE_BASED]
    required: true
    consumer: [FWK-30]
  - name: sequence_tag
    type: enum
    allowed: [SEQUENTIAL, PARALLEL]
    required: true
    consumer: [FWK-30]
  - name: overlaps_stage
    type: id
    required: false
    consumer: [FWK-30]
  - name: effort_hours
    type: range
    unit: hours
    required: true
    consumer: [FWK-38, FWK-30, FWK-50]
  - name: minimum_withdrawal_amount
    type: range|UNKNOWN
    unit: AED
    required: false
    consumer: [FWK-30, FWK-04]
  - name: kyc_at_withdrawal
    type: enum
    allowed: [YES, NO, UNKNOWN, NOT_APPLICABLE]
    required: false
    consumer: [FWK-30, FWK-04]
  - name: stage_source_id
    type: id
    required: true
    consumer: [FWK-60, SYS-09, FWK-04]
---

# Critical-path section (one row per stage; S10 repeats per hop)

Record-level companions on the opportunity record: day_zero and the per-case threshold attainability rows (`threshold_attainable_conservative`, `_base`, `_best`, each citing the EARNINGS_OR_CONVERSION claim id). Usable-cash day per case is computed per FWK-30; only S11b ends the model.
