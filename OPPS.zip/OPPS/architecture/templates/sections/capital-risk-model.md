---
template: capital-risk-model
version: "1.1"
owner_control: CAP-02
fields:
  - name: mechanism_kind
    type: enum
    allowed: [INVESTMENT, SPECULATION, TRADING, ARBITRAGE, YIELD, INCENTIVE_CAPTURE]
    required: true
    consumer: [CAP-11, FWK-45]
  - name: contractual_max_loss
    type: range
    unit: AED
    required: false
    consumer: [CAP-02, CAP-04]
  - name: contractual_max_loss_unlimited
    type: bool
    required: true
    consumer: [CAP-02, CAP-04]
  - name: max_drawdown
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [CAP-03, CAP-15]
  - name: volatility_measure
    type: text|UNKNOWN
    required: true
    consumer: [CAP-03, CAP-15]
  - name: liquidity_exit_one_day
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    consumer: [CAP-03, CAP-15]
  - name: leverage_ratio
    type: range|UNKNOWN
    unit: ratio
    required: true
    consumer: [CAP-04, FWK-13]
  - name: liquidation_trigger_move
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [CAP-04]
  - name: custody_model
    type: enum
    allowed: [SELF, EXCHANGE, BROKER, PROTOCOL_CONTRACT, OTHER, UNKNOWN]
    required: true
    consumer: [CAP-05, FWK-13]
  - name: counterparty_regulatory_status
    type: enum
    allowed: [LICENSED_FOR_UAE, NOT_LICENSED, UNVERIFIABLE, UNKNOWN]
    required: true
    evidence_ref: true
    consumer: [CAP-05, FWK-61, CAP-01, FWK-13]
  - name: counterparty_basis_id
    type: id
    required: true
    consumer: [CAP-05, FWK-64]
  - name: fees_spread_financing_slippage
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [CAP-06, FWK-31]
  - name: withdrawal_limit_and_hold
    type: range|UNKNOWN
    unit: days
    required: true
    consumer: [CAP-06, CAP-07, FWK-33]
  - name: settlement_stage_ids
    type: list
    required: true
    consumer: [CAP-07, FWK-04]
  - name: edge_claim_id
    type: id
    required: true
    consumer: [CAP-09, EVD-03]
  - name: edge_status
    type: enum
    allowed: [VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, HYPOTHESIS, UNKNOWN]
    required: true
    computed: true
    consumer: [CAP-09, CAP-14, FWK-47, CAP-15]
  - name: backtest_valid
    type: enum
    allowed: [YES, NO, NOT_USED, UNKNOWN]
    required: true
    consumer: [CAP-10]
  - name: repeatability_evidence
    type: enum
    allowed: [MULTI_PERIOD_NET, SINGLE_OUTCOME, NONE, UNKNOWN]
    required: true
    consumer: [CAP-11]
  - name: period_return_base_net
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [CAP-14]
  - name: period_return_best_net
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [CAP-14]
  - name: prob_impairment_30d
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [CAP-12, CAP-15]
  - name: prob_ruin
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [CAP-12, CAP-15]
  - name: prob_inputs_credible
    type: bool
    required: true
    evidence_ref: true
    consumer: [CAP-12]
  - name: expected_return
    type: range|UNKNOWN
    unit: AED
    required: true
    computed: true
    consumer: [CAP-14, CAP-15]
  - name: legal_review_status
    type: enum
    allowed: [PROFESSIONAL_LEGAL_REVIEW_REQUIRED, RESOLVED]
    required: true
    consumer: [CAP-13, FWK-62]
  - name: tax_review_status
    type: enum
    allowed: [PROFESSIONAL_TAX_REVIEW_REQUIRED, RESOLVED]
    required: true
    consumer: [CAP-13, FWK-34]
  - name: reg_ids
    type: list
    required: true
    consumer: [CAP-13, FWK-61]
---

# Capital-risk model section (records with a T2 component)

Capital quantities (capital_deployed, at_risk_capital, max_plausible_loss, capital_total) live on the opportunity record and are referenced here. edge_status is computed from the FINANCIAL_EDGE claim (CAP-09). expected_return is UNKNOWN whenever edge_status is UNKNOWN, HYPOTHESIS, or DIRECTIONAL (CAP-14). C5 closes only when no field here or on the referenced capital quantities is UNKNOWN (CAP-01).
