---
template: dependency-map
version: "1.1"
owner_control: FWK-37
fields:
  - name: dependency_type
    type: enum
    allowed: [HUMAN_NAMED, HUMAN_ROLE, PLATFORM_APPROVAL, KYC_IDENTITY, PAYMENT_PROCESSOR, SUPPLIER_FULFILMENT, SUPPORT_BURDEN, ACCOUNT_LIMIT, TOOLING, OPERATOR_COMPANY, CUSTODY_COUNTERPARTY]
    required: true
    consumer: [FWK-37, FWK-06, FWK-50, FWK-43, FWK-10, CAP-05]
  - name: provider_id
    type: id
    required: true
    consumer: [FWK-37, FWK-50, FWK-43, CAP-05]
  - name: description
    type: text
    required: true
    consumer: [admin]
    justification: human-readable label; evaluation uses dependency_type and the fields below
  - name: interaction_mode
    type: enum
    allowed: [SELF_SERVICE, STANDARDIZED_APPLICATION, INDIVIDUALIZED_NEGOTIATION, SPONSORED_BY_NAMED_PERSON]
    required: true
    evidence_ref: true
    consumer: [FWK-06, FWK-37]
  - name: blocks_cash
    type: bool
    required: true
    consumer: [FWK-37, FWK-06, FWK-50]
  - name: availability_status
    type: enum
    allowed: [AVAILABLE, UNAVAILABLE, UNKNOWN]
    required: true
    evidence_ref: true
    consumer: [FWK-37, FWK-11, FWK-50]
  - name: basis_id
    type: id
    required: true
    consumer: [FWK-37, EVD-03, FWK-64]
  - name: failure_impact
    type: enum
    allowed: [BLOCKS_CASH, DELAYS_CASH, REDUCES_CASH, NONE]
    required: true
    consumer: [FWK-37, FWK-13]
  - name: documented_limit
    type: range|UNKNOWN
    required: false
    consumer: [FWK-50]
---

# Dependency map section (one row per dependency)

Any HUMAN_NAMED row, or any cash-blocking row with interaction_mode INDIVIDUALIZED_NEGOTIATION or SPONSORED_BY_NAMED_PERSON, fails G5 (FWK-06). Any cash-blocking row at UNKNOWN availability keeps C2 open. The map counts as complete only when `dependency_map_attested_by` on the record names a perspective other than the Discoverer. OPERATOR_COMPANY availability cites the operator profile.
