---
template: cold-start-and-validation-experiment
version: "1.1"
owner_control: FWK-36
fields:
  - name: channel_entry_type
    type: enum
    allowed: [OPEN_MARKETPLACE_SEARCH, PAID_ADS, ALGORITHMIC_FEED, STANDARDIZED_APPLICATION, INVITE_ONLY, FOLLOWER_BASED]
    required: true
    evidence_ref: true
    consumer: [FWK-36, FWK-11]
  - name: channel_source_id
    type: id
    required: true
    consumer: [FWK-36, EVD-03]
  - name: cold_start_performance_claim_id
    type: id
    required: true
    consumer: [FWK-36, EVD-03, EVD-07, EVD-10]
  - name: demand_claim_id
    type: id
    required: true
    consumer: [FWK-36, EVD-03]
  - name: cold_start_channel_cost
    type: range
    unit: AED
    required: true
    consumer: [FWK-36, FWK-31]
  - name: exp_id
    type: id
    required: false
    consumer: [SYS-14, STR-02]
  - name: exp_claim_tested
    type: id
    required: false
    consumer: [FWK-35, SYS-14]
  - name: exp_metric
    type: text
    required: false
    consumer: [FWK-35]
  - name: exp_threshold
    type: range
    required: false
    consumer: [FWK-35]
  - name: exp_max_days
    type: int
    required: false
    consumer: [FWK-35]
  - name: exp_max_spend
    type: range
    unit: AED
    required: false
    consumer: [FWK-35, FWK-43]
  - name: exp_accounts_used
    type: list
    required: false
    consumer: [FWK-35, FWK-07]
  - name: exp_reversible
    type: enum
    allowed: [REVERSIBLE, BOUNDED_DOWNSIDE, IRREVERSIBLE]
    required: false
    consumer: [FWK-35, FWK-43]
  - name: exp_no_misleading_claims
    type: bool
    required: false
    evidence_ref: true
    consumer: [FWK-35]
  - name: exp_no_preselling_undeliverable
    type: bool
    required: false
    evidence_ref: true
    consumer: [FWK-35]
  - name: exp_compliance_checked
    type: bool
    required: false
    evidence_ref: true
    consumer: [FWK-35, FWK-07, FWK-02]
  - name: exp_basis_id
    type: id
    required: false
    consumer: [FWK-35, FWK-64]
  - name: exp_result
    type: enum
    allowed: [NOT_RUN, POSITIVE, NEGATIVE, AMBIGUOUS, VOID]
    required: false
    consumer: [SYS-14, STR-04, FWK-65, FWK-36]
---

# Cold-start distribution and validation experiment section

C1a closes when channel_entry_type is OPEN_MARKETPLACE_SEARCH, PAID_ADS, ALGORITHMIC_FEED, or STANDARDIZED_APPLICATION and channel_source_id is an admissible tier 3 source. C1b closes when the cold-start performance claim is at least DIRECTIONAL from sources with starting_audience_documented ZERO, or when exp_result is POSITIVE from a MEASURED cold-start experiment. Experiment fields are filled only for records selected under SYS-14.
