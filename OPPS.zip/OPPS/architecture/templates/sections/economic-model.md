---
template: economic-model
version: "1.1"
owner_control: FWK-31
fields:
  - name: case
    type: enum
    allowed: [CONSERVATIVE, BASE, BEST]
    required: true
    consumer: [FWK-31, FWK-14]
  - name: component
    type: enum
    allowed: [EARNED, REWARD, CAPITAL, ASSET]
    required: true
    consumer: [FWK-31, CAP-14, FWK-45]
  - name: receipts_gross
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [FWK-31, FWK-32]
  - name: receipts_claim_id
    type: id
    required: true
    consumer: [FWK-31, EVD-03]
  - name: reserve_withheld
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [FWK-31, FWK-33, STR-09]
  - name: refunds_realized
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: refund_rate
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [FWK-33]
  - name: refund_tail_days
    type: range|UNKNOWN
    unit: days
    required: true
    consumer: [FWK-33, STR-09]
  - name: refund_provision
    type: range|UNKNOWN
    unit: AED
    required: true
    computed: true
    consumer: [FWK-31, FWK-33]
  - name: platform_fees
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: processing_fees
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: dispute_fees
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: withholding_at_source
    type: range
    unit: AED
    required: true
    consumer: [FWK-31, FWK-34]
  - name: direct_costs_by_day30
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: withdrawal_and_fx_costs
    type: range
    unit: AED
    required: true
    consumer: [FWK-31, FWK-34]
  - name: fx_rate_source_id
    type: id
    required: true
    consumer: [FWK-34, STR-11]
  - name: recovered_principal
    type: range
    unit: AED
    required: true
    computed: true
    consumer: [FWK-32, FWK-31, STR-09, CAP-14]
  - name: realized_return
    type: range|UNKNOWN
    unit: AED
    required: true
    computed: true
    consumer: [FWK-32, CAP-14]
  - name: net_collectible_cash_pre_tax
    type: range|UNKNOWN
    unit: AED
    required: true
    computed: true
    consumer: [FWK-31, FWK-14, FWK-41, FWK-42, STR-09]
  - name: ncc_after_tax
    type: range|UNKNOWN
    unit: AED
    required: false
    computed: true
    consumer: [FWK-34]
  - name: contingent_liability_after_day30
    type: range
    unit: AED
    required: true
    computed: true
    consumer: [FWK-33, STR-09]
  - name: provenance_class
    type: enum
    allowed: [MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN]
    required: true
    computed: true
    consumer: [FWK-63, STR-11]
  - name: original_currency
    type: text
    required: true
    consumer: [STR-11, FWK-34]
---

# Economic model section (one row per case per component)

net_collectible_cash_pre_tax is computed by the FWK-31 formula and nothing else. For a CAPITAL component the cases are built per CAP-14 and recovered_principal per FWK-32. Any UNKNOWN required input makes the case UNKNOWN. Every header reads pre-tax.
