---
template: assumption-register
version: "1.0"
owner_control: EVD-06
fields:
  - name: asm_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: opp_id
    type: id
    required: false
    consumer: [SYS-08]
  - name: assumption_text
    type: text
    required: true
    consumer: [admin]
    justification: human-readable statement; effect is carried by the fields below
  - name: direction
    type: enum
    allowed: [FAVORABLE_TO_CANDIDATE, UNFAVORABLE, NEUTRAL]
    required: true
    consumer: [EVD-06, FWK-34]
  - name: justification_logged
    type: bool
    required: true
    consumer: [EVD-06]
  - name: estimator_basis
    type: text
    required: false
    consumer: [FWK-63]
  - name: affected_claim_ids
    type: list
    required: true
    consumer: [EVD-06, FWK-12]
  - name: replaceable_by
    type: enum
    allowed: [OPERATOR_INPUT_REQUIRED, FURTHER_RESEARCH_REQUIRED, PLATFORM_CONFIRMATION_REQUIRED, PROFESSIONAL_LEGAL_REVIEW_REQUIRED, PROFESSIONAL_TAX_REVIEW_REQUIRED, EVIDENCE_UNAVAILABLE]
    required: true
    consumer: [STR-05, SYS-10]
  - name: status
    type: enum
    allowed: [OPEN, RESOLVED, WITHDRAWN]
    required: true
    consumer: [SYS-10, FWK-65]
---

# Assumption register

A FAVORABLE_TO_CANDIDATE assumption without justification_logged true is a defect (EVD-06). No assumption may silently close a gate, a tax provision, a license-scope question, or an account-type question (FWK-34).
