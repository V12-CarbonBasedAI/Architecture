---
template: uncertainty-register
version: "1.0"
owner_control: STR-05
fields:
  - name: unc_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: scope
    type: enum
    allowed: [CANDIDATE, PROJECT, RESEARCH_LIMITATION, ARCHITECTURE]
    required: true
    consumer: [STR-10, SYS-17]
  - name: opp_id
    type: id
    required: false
    consumer: [SYS-10]
  - name: item_text
    type: text
    required: true
    consumer: [admin]
    justification: human-readable description; routing uses subtype and fields below
  - name: open_tbd_subtype
    type: enum
    allowed: [OPERATOR_INPUT_REQUIRED, FURTHER_RESEARCH_REQUIRED, PLATFORM_CONFIRMATION_REQUIRED, PROFESSIONAL_LEGAL_REVIEW_REQUIRED, PROFESSIONAL_TAX_REVIEW_REQUIRED, EVIDENCE_UNAVAILABLE]
    required: true
    consumer: [STR-05, SYS-10, SYS-17]
  - name: blocks_gate
    type: enum
    allowed: [G1, G2, G3, G4, G5, G6, G7, NONE]
    required: true
    consumer: [FWK-01, SYS-10]
  - name: affected_claim_ids
    type: list
    required: false
    consumer: [FWK-12]
  - name: resolver
    type: enum
    allowed: [OPERATOR, RESEARCHER, PLATFORM, PROFESSIONAL, NONE]
    required: true
    consumer: [SYS-10, FWK-66]
  - name: recheck_date
    type: date
    required: false
    consumer: [FWK-66, SYS-10]
  - name: status
    type: enum
    allowed: [OPEN, RESOLVED, STALE]
    required: true
    consumer: [FWK-66, SYS-17]
---

# Uncertainty register

Holds candidate-level unknowns, project-level unknowns, and research limitations (scope RESEARCH_LIMITATION), including the non-exhaustiveness statement required by SYS-06. Every row has a subtype; an unsubtyped unknown is a defect.
