---
template: operator-profile
version: "1.0"
owner_control: SYS-00
fields:
  - name: opr_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: residence_emirate
    type: text|OPERATOR_INPUT_REQUIRED
    required: true
    consumer: [FWK-61, FWK-02]
  - name: residency_status
    type: text|OPERATOR_INPUT_REQUIRED
    required: true
    consumer: [FWK-61, FWK-02]
  - name: account_types_available
    type: enum
    allowed: [PERSONAL, COMPANY, BOTH, OPERATOR_INPUT_REQUIRED]
    required: true
    consumer: [FWK-03, FWK-34, FWK-44]
  - name: license_scope_status
    type: enum
    allowed: [CONFIRMED, OPERATOR_INPUT_REQUIRED, PROFESSIONAL_LEGAL_REVIEW_REQUIRED]
    required: true
    consumer: [FWK-02, FWK-37, FWK-62]
  - name: license_scope_activities
    type: list
    required: false
    consumer: [FWK-02, FWK-61]
  - name: capital_available
    type: range|OPERATOR_INPUT_REQUIRED
    unit: AED
    required: true
    consumer: [FWK-13, FWK-44, FWK-50]
  - name: loss_limit
    type: range|OPERATOR_INPUT_REQUIRED
    unit: AED
    required: true
    consumer: [FWK-13, FWK-44, FWK-50, CAP-12]
  - name: weekly_hours
    type: range|OPERATOR_INPUT_REQUIRED
    unit: hours
    required: true
    consumer: [FWK-38, FWK-30, FWK-44, FWK-50]
  - name: experiment_budget
    type: range|OPERATOR_INPUT_REQUIRED
    unit: AED
    required: true
    consumer: [FWK-35, SYS-14]
  - name: experiments_per_cycle_cap
    type: int|OPERATOR_INPUT_REQUIRED
    required: true
    consumer: [SYS-14, FWK-35]
  - name: skills_held
    type: list
    required: true
    consumer: [FWK-38]
  - name: rails_available
    type: list
    required: true
    consumer: [FWK-03, FWK-04]
  - name: tax_status
    type: enum
    allowed: [PROFESSIONAL_TAX_REVIEW_REQUIRED, RESOLVED]
    required: true
    consumer: [FWK-34]
  - name: research_budget_queries
    type: int|OPERATOR_INPUT_REQUIRED
    required: true
    consumer: [SYS-06, FWK-21]
  - name: research_budget_hours
    type: range|OPERATOR_INPUT_REQUIRED
    unit: hours
    required: true
    consumer: [SYS-06, FWK-21]
  - name: open_tbd_subtypes
    type: list
    required: true
    consumer: [STR-05, SYS-17]
---

# Operator profile (one per research cycle, SYS-00)

Every operator fact the Framework consumes lives here and nowhere else. Unsupplied fields hold OPERATOR_INPUT_REQUIRED. No candidate record may assert a profile fact. Changes are DEC records and reopen affected candidates (FWK-65).
