---
template: decision-log
version: "1.1"
owner_control: STR-04
fields:
  - name: dec_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: decision_type
    type: enum
    allowed: [STATE_TRANSITION, MERGE, PROMOTION, NEAR_DUP_DECISION, TAXONOMY_REVIEW, DISCOVERY_FREEZE, DAY_ZERO, PROFILE_CHANGE, EXPERIMENT_RESULT, REOPEN, PORTFOLIO, VERSION_FREEZE]
    required: true
    consumer: [STR-04, FWK-20, SYS-05, FWK-30, FWK-65, SYS-13, SYS-00]
  - name: opp_id
    type: id
    required: false
    consumer: [STR-04]
  - name: related_ids
    type: list
    required: false
    consumer: [FWK-20, SYS-05]
  - name: from_state
    type: enum
    allowed: [DISCOVERED, MERGED, SCREENED, PROHIBITED, REJECTED, QUARANTINED, CONDITIONAL, ELIGIBLE, VALIDATION_PENDING, VALIDATED, INVALIDATED, NONE]
    required: true
    consumer: [STR-04]
  - name: to_state
    type: enum
    allowed: [DISCOVERED, MERGED, SCREENED, PROHIBITED, REJECTED, QUARANTINED, CONDITIONAL, ELIGIBLE, VALIDATION_PENDING, VALIDATED, INVALIDATED, NONE]
    required: true
    consumer: [STR-04]
  - name: trigger
    type: text
    required: true
    consumer: [STR-04, FWK-65]
  - name: rule_branch
    type: text
    required: false
    consumer: [FWK-20]
  - name: coverage_status
    type: enum
    allowed: [COVERAGE_COMPLETE, COVERAGE_INCOMPLETE, NOT_APPLICABLE]
    required: true
    consumer: [FWK-21, SYS-05]
  - name: new_family_proposed
    type: enum
    allowed: [YES, NO, NOT_APPLICABLE]
    required: true
    consumer: [SYS-05]
  - name: evidence_source_ids
    type: list
    required: false
    consumer: [FWK-65, EVD-03]
  - name: prior_values_preserved
    type: bool
    required: true
    consumer: [FWK-65, SYS-12]
  - name: decision_date
    type: date
    required: true
    consumer: [FWK-30, FWK-60]
  - name: perspective
    type: enum
    allowed: [DISCOVERER, VERIFIER, JURISDICTION_REVIEWER, CAPITAL_RISK_REVIEWER, ADVERSARY, INTEGRATOR]
    required: true
    consumer: [SYS-02]
---

# Decision log

Every state transition, merge, promotion, near-duplicate decision, taxonomy review, freeze, Day 0 declaration, profile change, experiment result, reopening, portfolio decision, and version freeze writes one row. Prior values are never overwritten.
