---
template: source-register
version: "1.1"
owner_control: EVD-01
fields:
  - name: so_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: locator
    type: text
    required: true
    consumer: [SYS-09]
  - name: tier
    type: int
    allowed: [1, 2, 3, 4, 5, 6, 7]
    required: true
    consumer: [EVD-01, EVD-03, FWK-60, EVD-02]
  - name: effective_tier
    type: int
    required: true
    computed: true
    consumer: [EVD-04, EVD-06]
  - name: admissible
    type: bool
    required: true
    computed: true
    consumer: [EVD-02, EVD-06]
  - name: rejection_reason
    type: enum
    allowed: [AFFILIATE_REVIEW, COURSE_FUNNEL, UNVERIFIED_SCREENSHOT, CONTENT_FARM, CIRCULAR_STATISTIC, UNDATED_LISTICLE, UNTRACEABLE_EARNINGS, NONE]
    required: true
    consumer: [EVD-02]
  - name: independence_class
    type: enum
    allowed: [A, B, C]
    required: true
    consumer: [EVD-04, EVD-05, FWK-12]
  - name: origin_id
    type: id
    required: true
    consumer: [EVD-04, EVD-06]
  - name: upstream_source_id
    type: id
    required: false
    consumer: [EVD-04, EVD-02]
  - name: publisher_incentive
    type: enum
    allowed: [NONE, AFFILIATE, SELLS_PRODUCT, PLATFORM_SELF, ADVERTISING, UNKNOWN]
    required: true
    consumer: [EVD-02]
  - name: operator_position
    type: enum
    allowed: [COLD_START, EXISTING_AUDIENCE, EXISTING_BRAND_OR_NETWORK, CAPITAL_ADVANTAGE, UNKNOWN, NOT_APPLICABLE]
    required: true
    consumer: [EVD-10]
  - name: starting_audience_documented
    type: enum
    allowed: [ZERO, NONZERO, UNDOCUMENTED, NOT_APPLICABLE]
    required: true
    consumer: [EVD-10, FWK-36]
  - name: publication_or_updated_date
    type: date|UNDATED
    required: true
    consumer: [EVD-11, FWK-60]
  - name: effective_date
    type: date
    required: false
    consumer: [FWK-60, EVD-11]
  - name: access_date
    type: date
    required: true
    consumer: [EVD-11, FWK-60]
  - name: freshness_status
    type: enum
    allowed: [FRESH, OUTDATED, PENDING]
    required: true
    computed: true
    consumer: [FWK-60, SYS-09, FWK-11]
  - name: supportable_claim_classes
    type: list
    required: true
    computed: true
    consumer: [EVD-10, EVD-01, EVD-02]
  - name: legal_source_class
    type: enum
    allowed: [BINDING_LAW, OFFICIAL_GUIDANCE, PROFESSIONAL_COMMENTARY, RESEARCHER_INTERPRETATION, NOT_LEGAL]
    required: true
    consumer: [EVD-13, FWK-02]
  - name: jurisdiction
    type: text|UNKNOWN
    required: true
    consumer: [EVD-10, FWK-61]
  - name: methodological_dependence
    type: text
    required: false
    consumer: [EVD-04]
---

# Source register (one row per source)

effective_tier, admissible, freshness_status, and supportable_claim_classes are computed from tier, rejection_reason, publisher_incentive, dates, and the upstream row (EVD-02, EVD-04, FWK-60). A class B row must name its upstream; a class A row must name its origin; two class A rows sharing an origin are a defect.
