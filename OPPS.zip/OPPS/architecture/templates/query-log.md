---
template: query-log
version: "1.0"
owner_control: SYS-03
fields:
  - name: query_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key referenced by L0 sightings
  - name: sweep_id
    type: id
    required: true
    consumer: [SYS-03, SYS-06]
  - name: family
    type: enum
    allowed: [F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14]
    required: true
    consumer: [SYS-03, FWK-21]
  - name: lens
    type: enum
    allowed: [MECHANISM_PAYER, ADJACENT_EMERGING, CONTRARY_FAILURE]
    required: true
    consumer: [SYS-04, SYS-03]
  - name: query_class
    type: enum
    allowed: [MECHANISM, PAYER, PLATFORM_POLICY, NEGATIVE_EVIDENCE, RECENCY_LIMITED]
    required: true
    consumer: [SYS-03, SYS-04]
  - name: query_text
    type: text
    required: true
    consumer: [SYS-03, EVD-09]
  - name: query_date
    type: date
    required: true
    consumer: [SYS-03]
  - name: search_surface
    type: text
    required: true
    consumer: [SYS-03, SYS-05]
  - name: language
    type: text
    required: true
    consumer: [SYS-03, FWK-21]
  - name: results_reviewed_n
    type: int
    required: true
    consumer: [SYS-03]
  - name: query_novelty
    type: enum
    allowed: [NEW, REPEATED]
    required: true
    consumer: [SYS-03, SYS-06]
  - name: sightings_logged
    type: int
    required: true
    consumer: [FWK-21, SYS-05]
---

# Query log (one row per query)
