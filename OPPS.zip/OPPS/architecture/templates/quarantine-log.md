---
template: quarantine-log
version: "1.0"
owner_control: SYS-10
fields:
  - name: qua_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: opp_id
    type: id
    required: true
    consumer: [STR-04, STR-09]
  - name: unknown_gate
    type: enum
    allowed: [G1, G2, G3, G4, G5, G6, G7, DECISION_CRITICAL_CLAIM]
    required: true
    consumer: [FWK-01, FWK-66]
  - name: blocking_item
    type: text
    required: true
    consumer: [SYS-10, FWK-66, STR-09]
  - name: open_tbd_subtype
    type: enum
    allowed: [OPERATOR_INPUT_REQUIRED, FURTHER_RESEARCH_REQUIRED, PLATFORM_CONFIRMATION_REQUIRED, PROFESSIONAL_LEGAL_REVIEW_REQUIRED, PROFESSIONAL_TAX_REVIEW_REQUIRED, EVIDENCE_UNAVAILABLE]
    required: true
    consumer: [STR-05, FWK-66, FWK-09]
  - name: resolver
    type: enum
    allowed: [OPERATOR, RESEARCHER, PLATFORM, PROFESSIONAL, NONE]
    required: true
    consumer: [SYS-10, FWK-66]
  - name: producing_step
    type: int
    required: true
    consumer: [FWK-66, SYS-07]
  - name: exit_evidence_class
    type: enum
    allowed: [ADMISSIBLE_SOURCE_AT_TIER, OPERATOR_PROFILE_INPUT, PLATFORM_CONFIRMATION, PROFESSIONAL_OPINION]
    required: true
    consumer: [FWK-66]
  - name: recheck_date
    type: date
    required: true
    consumer: [FWK-66, STR-09]
  - name: status
    type: enum
    allowed: [ACTIVE, STALE, EXITED]
    required: true
    consumer: [FWK-66, STR-09]
  - name: exit_evidence_source_id
    type: id
    required: false
    consumer: [FWK-66, EVD-03]
---

# Quarantine log

One row per quarantine event. A quarantined record never appears in an ordering (FWK-47) and exits only per FWK-66.
