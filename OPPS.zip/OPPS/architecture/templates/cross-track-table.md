---
template: cross-track-table
version: "1.0"
owner_control: FWK-45
fields:
  - name: opp_id
    type: id
    required: true
    consumer: [FWK-45]
  - name: track
    type: enum
    allowed: [T1, T2, T3, T4, T5]
    required: true
    consumer: [FWK-45]
  - name: component_tracks
    type: list
    required: true
    consumer: [FWK-45]
  - name: cash_band
    type: enum
    allowed: [CASH_A, CASH_B, CASH_C, CASH_D, CASH_U]
    required: true
    consumer: [FWK-45]
  - name: confidence_band
    type: enum
    allowed: [HIGH, MODERATE, LOW, UNRESOLVED]
    required: true
    consumer: [FWK-45]
  - name: risk_class
    type: enum
    allowed: [R0, R1, R2, R3]
    required: true
    consumer: [FWK-45]
  - name: feasibility_status
    type: enum
    allowed: [WITHIN, BEYOND, UNKNOWN]
    required: true
    consumer: [FWK-45]
  - name: ncc_conservative_pre_tax
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [FWK-45]
  - name: realized_return_conservative
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [FWK-45, FWK-32]
  - name: recovered_principal
    type: range
    unit: AED
    required: true
    consumer: [FWK-45, FWK-32]
  - name: s11b_day_conservative
    type: range|UNKNOWN
    unit: days
    required: true
    consumer: [FWK-45]
  - name: hours_per_week
    type: range
    unit: hours
    required: true
    consumer: [FWK-45]
  - name: capital_total
    type: range
    unit: AED
    required: true
    consumer: [FWK-45]
  - name: disclosure_note
    type: text
    required: true
    consumer: [FWK-45]
---

# Cross-track table (no rank column; units normalized; differences disclosed)
