---
template: claim-evidence-matrix
version: "1.1"
owner_control: STR-08
fields:
  - name: clm_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: opp_id
    type: id
    required: true
    consumer: [FWK-12, SYS-08]
  - name: claim_class
    type: enum
    allowed: [LEGALITY, PLATFORM_ELIGIBILITY, PLATFORM_POLICY_COMPLIANCE, PAYOUT_PATH, FEES_AND_COSTS, DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, FINANCIAL_EDGE, DEPENDENCY_AVAILABILITY]
    required: true
    consumer: [EVD-03, FWK-12, EVD-07]
  - name: claim_text
    type: text
    required: true
    consumer: [admin]
    justification: the claim as stated for human review; status is computed from the fields below
  - name: gate_ids
    type: list
    required: true
    consumer: [FWK-01, FWK-60, FWK-02, FWK-03, FWK-04, FWK-07]
  - name: source_fit
    type: map
    required: true
    consumer: [EVD-10, EVD-06]
  - name: origin_count
    type: int
    required: true
    computed: true
    consumer: [EVD-04, EVD-06, FWK-12]
  - name: denominator
    type: text|UNKNOWN
    required: true
    consumer: [EVD-07]
  - name: failure_base_rate_search
    type: enum
    allowed: [DONE_FOUND, DONE_NONE, NOT_DONE]
    required: true
    computed: true
    consumer: [EVD-07, EVD-09]
  - name: contradiction_ids
    type: list
    required: true
    consumer: [EVD-06, FWK-65, EVD-09]
  - name: policy_finding
    type: enum
    allowed: [PERMITTED, NOT_ADDRESSED, PROHIBITED, NOT_APPLICABLE]
    required: true
    consumer: [FWK-07]
  - name: edge_out_of_sample
    type: enum
    allowed: [YES, NO, UNKNOWN, NOT_APPLICABLE]
    required: true
    consumer: [CAP-09]
  - name: edge_net_of_costs
    type: enum
    allowed: [YES, NO, UNKNOWN, NOT_APPLICABLE]
    required: true
    consumer: [CAP-09]
  - name: edge_sample_size
    type: range|UNKNOWN
    unit: observations
    required: true
    consumer: [CAP-09]
  - name: edge_trials_count
    type: range|UNKNOWN
    unit: trials
    required: true
    consumer: [CAP-09, CAP-10]
  - name: regime_span
    type: enum
    allowed: [SINGLE_REGIME, MULTI_REGIME, UNKNOWN, NOT_APPLICABLE]
    required: true
    consumer: [CAP-08, EVD-06]
  - name: status
    type: enum
    allowed: [VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, INFERENCE, ASSUMPTION, HYPOTHESIS, CONTRADICTION, UNKNOWN, OUTDATED]
    required: true
    computed: true
    consumer: [EVD-06, FWK-12, FWK-01]
---

# Claim-evidence matrix (one row per claim)

Every claim in the ten classes is decision-critical. Status, origin_count, and failure_base_rate_search are computed (EVD-06, EVD-04, EVD-07) from the linked source rows and contradiction rows, never typed. `source_fit` maps each source id to FIT or NOT_APPLICABLE. Freshness is read from the linked sources.
