---
template: capital-risk-dashboard
version: "1.1"
owner_control: CAP-15
fields:
  - name: opp_id
    type: id
    required: true
    consumer: [CAP-15, STR-09]
  - name: component_tracks
    type: list
    required: true
    consumer: [CAP-15, FWK-45]
  - name: mechanism_kind
    type: enum
    allowed: [INVESTMENT, SPECULATION, TRADING, ARBITRAGE, YIELD, INCENTIVE_CAPTURE]
    required: true
    consumer: [CAP-11, CAP-15]
  - name: capital_deployed
    type: range
    unit: AED
    required: true
    consumer: [CAP-15, FWK-50]
  - name: max_plausible_loss
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [CAP-15, FWK-13]
  - name: max_drawdown
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [CAP-15, CAP-03]
  - name: volatility_measure
    type: text|UNKNOWN
    required: true
    consumer: [CAP-15, CAP-03]
  - name: liquidity_exit_one_day
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    consumer: [CAP-15, CAP-03]
  - name: leverage_ratio
    type: range|UNKNOWN
    unit: ratio
    required: true
    consumer: [CAP-15, CAP-04]
  - name: custody_model
    type: enum
    allowed: [SELF, EXCHANGE, BROKER, PROTOCOL_CONTRACT, OTHER, UNKNOWN]
    required: true
    consumer: [CAP-15, CAP-05]
  - name: counterparty_regulatory_status
    type: enum
    allowed: [LICENSED_FOR_UAE, NOT_LICENSED, UNVERIFIABLE, UNKNOWN]
    required: true
    consumer: [CAP-15, CAP-05]
  - name: edge_status
    type: enum
    allowed: [VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, HYPOTHESIS, UNKNOWN]
    required: true
    consumer: [CAP-15, CAP-09]
  - name: prob_impairment_30d
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [CAP-15, CAP-12]
  - name: prob_ruin
    type: range|UNKNOWN
    unit: fraction
    required: true
    consumer: [CAP-15, CAP-12]
  - name: realized_return_conservative
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [CAP-14, CAP-15, FWK-14]
  - name: recovered_principal
    type: range
    unit: AED
    required: true
    consumer: [FWK-32, CAP-15]
  - name: expected_return
    type: range|UNKNOWN
    unit: AED
    required: true
    consumer: [CAP-14, CAP-15]
  - name: legal_review_status
    type: enum
    allowed: [PROFESSIONAL_LEGAL_REVIEW_REQUIRED, RESOLVED]
    required: true
    consumer: [CAP-13, CAP-15]
  - name: tax_review_status
    type: enum
    allowed: [PROFESSIONAL_TAX_REVIEW_REQUIRED, RESOLVED]
    required: true
    consumer: [CAP-13, CAP-15]
---

# Capital-risk dashboard (D5)

One row per record with a T2 component. UNKNOWN is displayed as UNKNOWN. This dashboard carries no rank and never appears inside an income ordering (FWK-45).
