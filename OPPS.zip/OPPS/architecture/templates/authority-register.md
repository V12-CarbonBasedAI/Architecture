---
template: authority-register
version: "1.0"
owner_control: FWK-61
fields:
  - name: aut_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: authority_class
    type: text
    required: true
    consumer: [FWK-61]
  - name: authority_name
    type: text
    required: true
    consumer: [FWK-61]
  - name: jurisdiction
    type: text
    required: true
    consumer: [FWK-61, EVD-13]
  - name: remit_source_id
    type: id
    required: true
    consumer: [FWK-61, EVD-13]
  - name: confirmed_at
    type: date
    required: true
    consumer: [FWK-60, FWK-61]
  - name: activity_classes
    type: list
    required: true
    consumer: [FWK-61]
---

# Authority register

Names of regulators and authorities are verification targets, confirmed at a date against a tier 1 or 2 source, refreshed under the 90-day limit. The FWK-61 matrix cites authority classes only.
