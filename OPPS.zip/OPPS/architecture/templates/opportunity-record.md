---
template: opportunity-record
version: "1.1"
owner_control: STR-03
fields:
  - name: opp_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key for the record; consumed by every register through linkage
  - name: sweep_id
    type: id
    required: true
    consumer: [SYS-03, FWK-21]
  - name: lens
    type: enum
    allowed: [MECHANISM_PAYER, ADJACENT_EMERGING, CONTRARY_FAILURE]
    required: true
    consumer: [FWK-21, SYS-05]
  - name: query_id
    type: id
    required: true
    consumer: [FWK-21, SYS-05]
  - name: depth
    type: enum
    allowed: [L0, IDENTITY, L1, L2, L3]
    required: true
    consumer: [STR-03, FWK-47]
  - name: state
    type: enum
    allowed: [DISCOVERED, MERGED, SCREENED, PROHIBITED, REJECTED, QUARANTINED, CONDITIONAL, ELIGIBLE, VALIDATION_PENDING, VALIDATED, INVALIDATED]
    required: true
    computed: true
    consumer: [STR-04, FWK-47, SYS-15]
  - name: primary_family
    type: enum
    allowed: [F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15, F16]
    required: true
    consumer: [STR-01, FWK-21, SYS-06]
  - name: description
    type: text
    required: true
    consumer: [admin]
    justification: free text for human reading; excluded from all evaluation by FWK-64
  - name: source_locator
    type: text
    required: true
    consumer: [FWK-21, SYS-08]
  - name: first_seen
    type: date
    required: true
    consumer: [FWK-21, FWK-20]
  - name: mec_id
    type: id
    required_at: IDENTITY
    consumer: [FWK-20, STR-13, SYS-05]
  - name: variant_platform_id
    type: id
    required_at: IDENTITY
    consumer: [FWK-20, STR-13, FWK-50, FWK-43]
  - name: variant_geography
    type: text
    required_at: IDENTITY
    consumer: [FWK-20]
  - name: variant_pricing_model
    type: text
    required_at: IDENTITY
    consumer: [FWK-20]
  - name: variant_format
    type: text
    required_at: IDENTITY
    consumer: [FWK-20]
  - name: dedup_result
    type: enum
    allowed: [UNIQUE, MERGED, NEAR_DUPLICATE]
    required_at: IDENTITY
    computed: true
    consumer: [FWK-20, FWK-21, SYS-05]
  - name: merged_into
    type: id
    required: false
    computed: true
    consumer: [FWK-20]
  - name: capital_role
    type: enum
    allowed: [NONE, WORKING_CAPITAL, AT_RISK_CAPITAL]
    required_at: L1
    consumer: [FWK-10, CAP-16]
  - name: cash_source_is_reward
    type: bool
    required_at: L1
    evidence_ref: true
    consumer: [FWK-10]
  - name: asset_build_first
    type: bool
    required_at: L1
    consumer: [FWK-10]
  - name: refundable_stake
    type: range
    unit: AED
    required_at: L1
    consumer: [FWK-10, CAP-02]
  - name: component_tracks
    type: list
    required_at: L1
    computed: true
    consumer: [FWK-10, STR-06, FWK-45, CAP-01, EVD-03]
  - name: track
    type: enum
    allowed: [T1, T2, T3, T4, T5]
    required_at: L1
    computed: true
    consumer: [FWK-10, FWK-45, CAP-01, FWK-11]
  - name: sales_mode
    type: enum
    allowed: [SELF_SERVICE_CHECKOUT, STANDARDIZED_PROGRAM_PAYOUT, QUOTE_OR_PROPOSAL, NEGOTIATED]
    required_at: L1
    evidence_ref: true
    consumer: [FWK-06]
  - name: basis_id
    type: id
    required_at: L1
    consumer: [FWK-64, STR-12]
  - name: activity_classes
    type: list
    required_at: L1
    consumer: [FWK-61, FWK-62, CAP-13]
  - name: gate_G1
    type: enum
    allowed: [PASS, FAIL, UNKNOWN, DEFERRED]
    required_at: L1
    computed: true
    consumer: [FWK-02, FWK-09, FWK-47, STR-09]
  - name: gate_G2
    type: enum
    allowed: [PASS, FAIL, UNKNOWN, DEFERRED]
    required_at: L1
    computed: true
    consumer: [FWK-03, FWK-47, STR-09]
  - name: gate_G3
    type: enum
    allowed: [PASS, FAIL, UNKNOWN, DEFERRED]
    required_at: L2
    computed: true
    consumer: [FWK-04, FWK-47, STR-09]
  - name: gate_G4
    type: enum
    allowed: [PASS, FAIL, UNKNOWN, DEFERRED]
    required_at: L1
    computed: true
    consumer: [FWK-05, FWK-47, STR-09]
  - name: gate_G5
    type: enum
    allowed: [PASS, FAIL, UNKNOWN, DEFERRED]
    required_at: L1
    computed: true
    consumer: [FWK-06, FWK-47, STR-09]
  - name: gate_G6
    type: enum
    allowed: [PASS, FAIL, UNKNOWN, DEFERRED]
    required_at: L2
    computed: true
    consumer: [FWK-07, FWK-47, STR-09]
  - name: gate_G7
    type: enum
    allowed: [PASS, FAIL, UNKNOWN, DEFERRED]
    required_at: L1
    computed: true
    consumer: [FWK-08, FWK-09, FWK-47, STR-09]
  - name: material_unresolved_legal_question
    type: bool
    required_at: L2
    computed: true
    consumer: [FWK-09, FWK-62]
  - name: professional_opinion_id
    type: id
    required: false
    consumer: [FWK-62, CAP-13, FWK-02]
  - name: claim_ids
    type: list
    required_at: L2
    consumer: [FWK-12, SYS-08, EVD-03]
  - name: dependency_map_attested_by
    type: enum
    allowed: [VERIFIER, JURISDICTION_REVIEWER, CAPITAL_RISK_REVIEWER, ADVERSARY, INTEGRATOR, NONE]
    required_at: L2
    consumer: [FWK-37, FWK-06, SYS-02]
  - name: assumed_distribution
    type: bool
    required_at: L2
    computed: true
    consumer: [FWK-36]
  - name: setup_hours
    type: range
    unit: hours
    required_at: L2
    consumer: [FWK-38, FWK-50]
  - name: recurring_hours_per_week
    type: range
    unit: hours
    required_at: L2
    consumer: [FWK-38, FWK-41, FWK-42, FWK-43, FWK-50]
  - name: support_hours_per_week
    type: range
    unit: hours
    required_at: L2
    consumer: [FWK-38, FWK-41, FWK-50]
  - name: required_skills
    type: list
    required_at: L2
    consumer: [FWK-38]
  - name: skill_gap_status
    type: enum
    allowed: [NONE, LEARNABLE_IN_SETUP, BLOCKING]
    required_at: L2
    consumer: [FWK-38]
  - name: skill_substitute_documented
    type: bool
    required_at: L2
    evidence_ref: true
    consumer: [FWK-38]
  - name: setup_capital
    type: range
    unit: AED
    required_at: L2
    consumer: [FWK-38, FWK-50]
  - name: working_capital
    type: range
    unit: AED
    required_at: L2
    consumer: [FWK-38, FWK-50]
  - name: at_risk_capital
    type: range
    unit: AED
    required_at: L2
    consumer: [FWK-38, FWK-10, FWK-50, CAP-02]
  - name: capital_total
    type: range
    unit: AED
    required_at: L2
    computed: true
    consumer: [FWK-38, FWK-41, FWK-45, CAP-12]
  - name: capital_deployed
    type: range
    unit: AED
    required_at: L2
    consumer: [CAP-02, FWK-32, CAP-12]
  - name: max_plausible_loss
    type: range|UNKNOWN
    unit: AED
    required_at: L3
    consumer: [FWK-13, FWK-41, FWK-42, FWK-43, FWK-50, CAP-02, CAP-14]
  - name: risk_types
    type: list
    required_at: L3
    consumer: [FWK-13, FWK-50]
  - name: risk_class
    type: enum
    allowed: [R0, R1, R2, R3]
    required_at: L3
    computed: true
    consumer: [FWK-13, FWK-40, FWK-47, STR-09]
  - name: feasibility_status
    type: enum
    allowed: [WITHIN, BEYOND, UNKNOWN]
    required_at: L3
    computed: true
    consumer: [FWK-38, FWK-40, FWK-47, FWK-11, STR-09]
  - name: confidence_band
    type: enum
    allowed: [HIGH, MODERATE, LOW, UNRESOLVED]
    required_at: L3
    computed: true
    consumer: [FWK-12, FWK-40, FWK-47, STR-09]
  - name: cash_band
    type: enum
    allowed: [CASH_A, CASH_B, CASH_C, CASH_D, CASH_U]
    required_at: L3
    computed: true
    consumer: [FWK-14, FWK-40, FWK-47, STR-09]
  - name: horizon_class
    type: enum
    allowed: [H30, H90, H365, H_OPEN]
    required_at: L3
    computed: true
    consumer: [FWK-15, FWK-10]
  - name: day_zero
    type: date|UNDATED
    required_at: L3
    consumer: [FWK-30, FWK-14]
  - name: tax_status
    type: enum
    allowed: [PROFESSIONAL_TAX_REVIEW_REQUIRED, RESOLVED]
    required_at: L3
    consumer: [FWK-34, FWK-31, STR-05]
  - name: tax_opinion_id
    type: id
    required: false
    consumer: [FWK-34]
  - name: scalability_note
    type: text
    required: false
    consumer: [STR-10]
  - name: prioritization_result
    type: text
    required_at: L3
    computed: true
    consumer: [FWK-40, FWK-47, STR-10]
  - name: reverification_triggers
    type: list
    required_at: L3
    consumer: [SYS-09, FWK-65]
---

# Opportunity record template

One file per OPP. Fill depths in order: L0, identity at the freeze, L1, L2, L3. Signature fields live on the mechanism registry and are referenced through `mec_id`. Section fragments in `templates/sections/` are embedded at L2 and L3. Fields marked `computed` are produced by rule. Free text never changes an evaluation output (FWK-64). Fixture identifiers and STIPULATED provenance are prohibited here (STR-14).

## L0 Sighting
opp_id, sweep_id, lens, query_id, primary_family, description, source_locator, first_seen.

## Identity (at the discovery freeze)
mec_id, variant fields, dedup_result, merged_into.

## L1 Preliminary screen (FAIL-only)
capital_role, cash_source_is_reward, asset_build_first, refundable_stake, component_tracks, track, sales_mode, activity_classes, basis_id; gate values FAIL or DEFERRED for G1, G2, G4, G5, G7.

## L2 Investigation record
claim_ids for the mandatory set, gate values PASS, FAIL, or UNKNOWN for G1 to G7, embedded `sections/dependency-map.md` with dependency_map_attested_by, embedded `sections/cold-start-and-validation-experiment.md` (cold-start part), feasibility fields, professional_opinion_id where logged, jurisdiction routing output as REG ids.

## L3 Decision record
Embedded `sections/critical-path.md`, `sections/economic-model.md`, `sections/capital-risk-model.md` (T2 component), day_zero, tax_status, state, confidence_band, risk_class, feasibility_status, cash_band, horizon_class, max_plausible_loss, risk_types, prioritization_result, reverification_triggers, scalability_note; validation experiment design only when selected under SYS-14.
