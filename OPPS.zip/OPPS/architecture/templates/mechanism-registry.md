---
template: mechanism-registry
version: "1.1"
owner_control: STR-13
fields:
  - name: mec_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: signature_version
    type: text
    required: true
    consumer: [FWK-20, STR-13]
  - name: value_delivered_class
    type: enum
    allowed: [STANDARDIZED_DIGITAL_GOOD, STANDARDIZED_SERVICE_UNIT, METERED_SOFTWARE_ACCESS, AUDIENCE_ATTENTION, DEMAND_DELIVERY, DATASET_OR_REPORT, PARTICIPATION_AS_SUBJECT, IP_LICENSE, THIRD_PARTY_FULFILLED_GOOD, REFERRAL_OR_ONBOARDING, DIGITAL_PROPERTY_TRANSFER, DIGITAL_CAPACITY_RENTAL, PRIZE_OR_GRANT_ENTRY, RISK_BEARING_OR_LIQUIDITY, PROTOCOL_PARTICIPATION, SPREAD_CAPTURE, RECOVERY_OR_REBATE, OTHER]
    required: true
    consumer: [FWK-20, STR-13, SYS-05]
  - name: payer_types
    type: list
    allowed: [CONSUMER, BUSINESS, PLATFORM, PROTOCOL, SPONSOR_OR_GRANTOR, MARKET_COUNTERPARTY]
    required: true
    consumer: [FWK-20, FWK-10, CAP-16, STR-01]
  - name: operator_supplies
    type: list
    allowed: [LABOR, CAPITAL, ASSET, DATA, ATTENTION]
    required: true
    consumer: [FWK-20, FWK-10, CAP-16]
  - name: payment_rail
    type: enum
    allowed: [CARD, BANK, WALLET, PLATFORM_BALANCE, CRYPTO]
    required: true
    consumer: [FWK-20, FWK-33, FWK-03]
  - name: settlement_mechanism
    type: enum
    allowed: [DIRECT_PROCESSOR, PLATFORM_PAYOUT, EXCHANGE_OR_BROKER, ON_CHAIN, BANK_TRANSFER]
    required: true
    consumer: [FWK-20, FWK-10, CAP-16, FWK-30, FWK-33]
  - name: platform_dependency_class
    type: enum
    allowed: [NONE, SINGLE_PLATFORM, MULTI_PLATFORM, CUSTODIAL]
    required: true
    consumer: [FWK-20, FWK-43, FWK-13]
  - name: primary_family
    type: enum
    allowed: [F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15, F16]
    required: true
    consumer: [FWK-21, SYS-06]
  - name: secondary_families
    type: list
    required: false
    consumer: [FWK-21, STR-01]
  - name: family_assignment_reason
    type: text
    required: true
    consumer: [STR-01]
  - name: component_tracks
    type: list
    required_at: L1
    computed: true
    consumer: [FWK-10, FWK-45]
  - name: opp_ids
    type: list
    required: true
    consumer: [FWK-20, FWK-21]
  - name: near_duplicate_of
    type: list
    required: false
    consumer: [FWK-20]
  - name: first_seen
    type: date
    required: true
    consumer: [SYS-06]
  - name: last_seen
    type: date
    required: true
    consumer: [SYS-06]
  - name: sweep_ids
    type: list
    required: true
    consumer: [SYS-06, FWK-21]
  - name: saturation_contribution
    type: enum
    allowed: [NEW_IN_SWEEP, PREVIOUSLY_SEEN]
    required: true
    consumer: [SYS-06]
---

# Mechanism registry (one row per unique signature; canonical holder of the signature)

Signature equality across value_delivered_class, payer_types (as a set), operator_supplies (as a set), payment_rail, settlement_mechanism, and platform_dependency_class means one mechanism (FWK-20). Cross-field validity per STR-13. Coverage (FWK-21) and saturation (SYS-06) count rows here, never sightings or variants.
