---
template: family-sweep-coverage
version: "1.0"
owner_control: SYS-06
fields:
  - name: sweep_id
    type: id
    required: true
    consumer: [SYS-03, SYS-06]
  - name: family
    type: enum
    allowed: [F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14]
    required: true
    consumer: [SYS-06, FWK-21]
  - name: sweep_status
    type: enum
    allowed: [COMPLETE, PARTIAL]
    required: true
    consumer: [SYS-03, SYS-06, FWK-21]
  - name: novelty_requirement_met
    type: bool
    required: true
    computed: true
    consumer: [SYS-03, SYS-06]
  - name: sightings
    type: int
    required: true
    consumer: [FWK-21]
  - name: mechanisms_new_after_dedup
    type: int
    required: true
    computed: true
    consumer: [SYS-06, FWK-21]
  - name: near_duplicate_flags
    type: int
    required: true
    consumer: [FWK-21, FWK-20]
  - name: taxonomy_extensions
    type: int
    required: true
    consumer: [SYS-06, SYS-05]
  - name: family_saturation_status
    type: enum
    allowed: [SATURATED, UNSATURATED]
    required: true
    computed: true
    consumer: [SYS-06, FWK-21, STR-10]
---

# Family-sweep coverage (one row per family per sweep, filled at the freeze)
