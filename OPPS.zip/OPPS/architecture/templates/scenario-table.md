---
template: scenario-table
version: "1.0"
owner_control: FWK-44
fields:
  - name: scenario_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: hours_class
    type: enum
    allowed: [H1, H2, H3]
    required: true
    consumer: [FWK-44, FWK-38]
  - name: capital_class
    type: enum
    allowed: [C0, C1, C2, C3]
    required: true
    consumer: [FWK-44, FWK-13]
  - name: loss_tolerance_class
    type: enum
    allowed: [C0, C1, C2, C3]
    required: true
    consumer: [FWK-44, FWK-13]
  - name: account_access
    type: enum
    allowed: [PERSONAL, COMPANY, BOTH]
    required: true
    consumer: [FWK-44, FWK-03]
  - name: track
    type: enum
    allowed: [T1, T2, T3, T4, T5]
    required: true
    consumer: [FWK-45]
  - name: ordered_opp_ids
    type: list
    required: true
    computed: true
    consumer: [FWK-40, FWK-44]
  - name: deciding_levels
    type: list
    required: true
    computed: true
    consumer: [FWK-42, FWK-43]
  - name: ties
    type: list
    required: true
    computed: true
    consumer: [FWK-46]
  - name: reason_lists
    type: map
    required: true
    computed: true
    consumer: [FWK-47]
---

# Scenario table (at most eight scenarios per report, every input stated)
