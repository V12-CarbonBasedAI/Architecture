---
template: portfolio-feasibility
version: "1.1"
owner_control: FWK-50
fields:
  - name: por_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: member_opp_ids
    type: list
    required: true
    consumer: [FWK-50, SYS-15]
  - name: weekly_hours_profile
    type: list
    required: true
    computed: true
    consumer: [FWK-50]
  - name: peak_week_hours
    type: range
    unit: hours
    required: true
    computed: true
    consumer: [FWK-50]
  - name: peak_simultaneous_capital
    type: range
    unit: AED
    required: true
    computed: true
    consumer: [FWK-50]
  - name: aggregate_max_plausible_loss
    type: range|UNKNOWN
    unit: AED
    required: true
    computed: true
    consumer: [FWK-50]
  - name: shared_providers
    type: list
    required: true
    computed: true
    consumer: [FWK-50, FWK-07]
  - name: shared_limit_exceeded
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    computed: true
    consumer: [FWK-50]
  - name: correlated_risk_groups
    type: list
    required: true
    computed: true
    consumer: [FWK-50]
  - name: correlation_unknown_on_cash_blocking
    type: bool
    required: true
    computed: true
    consumer: [FWK-50]
  - name: limits_status
    type: enum
    allowed: [ALL_SET, OPERATOR_INPUT_REQUIRED]
    required: true
    consumer: [FWK-50, STR-05]
  - name: breakpoints
    type: map
    required: true
    computed: true
    consumer: [FWK-50, SYS-15]
  - name: result
    type: enum
    allowed: [FEASIBLE, INFEASIBLE, CONDITIONAL, BLOCKED_UNKNOWN]
    required: true
    computed: true
    consumer: [FWK-50, STR-09, SYS-15]
---

# Portfolio feasibility record

All aggregates are computed from member critical paths, capital fields, and dependency rows keyed by provider_id (FWK-50). Individual feasibility never establishes portfolio feasibility.
