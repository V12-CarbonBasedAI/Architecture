---
template: coverage-audit
version: "1.0"
owner_control: FWK-21
fields:
  - name: cycle_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: coverage_status
    type: enum
    allowed: [COVERAGE_COMPLETE, COVERAGE_INCOMPLETE]
    required: true
    computed: true
    consumer: [FWK-21, SYS-05, STR-10]
  - name: incomplete_reason
    type: enum
    allowed: [BUDGET_EXHAUSTED, TIME_BOX, SOURCE_ACCESS, NONE]
    required: true
    consumer: [FWK-21, SYS-06]
  - name: unsaturated_families
    type: list
    required: true
    consumer: [FWK-21, STR-10]
  - name: zero_mechanism_families
    type: list
    required: true
    consumer: [FWK-21]
  - name: familiarity_metric
    type: range
    unit: fraction
    required: true
    consumer: [SYS-05]
  - name: familiarity_result
    type: enum
    allowed: [NONE_FOUND, FINDING_LOGGED]
    required: true
    consumer: [SYS-05, FWK-21]
  - name: popularity_metric
    type: range
    unit: fraction
    required: true
    consumer: [SYS-05]
  - name: popularity_result
    type: enum
    allowed: [NONE_FOUND, FINDING_LOGGED]
    required: true
    consumer: [SYS-05, FWK-21]
  - name: emerging_f16_count
    type: int
    required: true
    consumer: [SYS-05]
  - name: emerging_recent_count
    type: int
    required: true
    consumer: [SYS-05]
  - name: emerging_result
    type: enum
    allowed: [NONE_FOUND, FINDING_LOGGED]
    required: true
    consumer: [SYS-05, FWK-21]
  - name: bias_reviewer
    type: enum
    allowed: [ADVERSARY]
    required: true
    consumer: [SYS-05, SYS-02]
  - name: f16_review_dec_id
    type: id
    required: true
    consumer: [SYS-05]
  - name: languages_markets_not_searched
    type: text
    required: true
    consumer: [FWK-21]
  - name: budget_consumed_queries
    type: int
    required: true
    consumer: [SYS-06]
  - name: budget_consumed_hours
    type: range
    unit: hours
    required: true
    consumer: [SYS-06]
  - name: linked_unc_ids
    type: list
    required: true
    consumer: [SYS-05, SYS-17]
---

# Coverage audit (one per research cycle, produced at the freeze and before every report)
