# 05 Source governance (Framework module)

Owner layer: Framework module. This file owns evidence admissibility, claim status, corroboration, survivorship, contradiction search, claim-source fit, legal-source classification, and methodological grounding. Field shapes are in `templates/source-register.md` and `templates/claim-evidence-matrix.md`. Process steps are in [02-system.md](02-system.md) (SYS-08, SYS-09).

### EVD-01 Source hierarchy and permitted uses

| Tier | Source type | Permitted use |
|---|---|---|
| 1 | Binding laws and regulations | Any claim class; required for LEGALITY |
| 2 | Official regulatory guidance | Any claim class; required for LEGALITY where tier 1 is silent |
| 3 | Current platform policies, terms, fees, eligibility, settlement, and payout documentation | PLATFORM_ELIGIBILITY, PLATFORM_POLICY_COMPLIANCE, PAYOUT_PATH, FEES_AND_COSTS, DEPENDENCY_AVAILABILITY; never for commercial results |
| 4 | Original datasets and transparent primary evidence | DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, FINANCIAL_EDGE |
| 5 | Strong independent research and reporting | Same as tier 4; `origin_id` of the underlying data mandatory |
| 6 | Transparent practitioner evidence | Discovery and hypothesis generation only; never supports a claim status |
| 7 | Community and social material | Discovery only; never supports a claim status |

`supportable_claim_classes` is derived from tier; a researcher may narrow it, never widen it.

### EVD-02 Rejected source types and derivation rules

A source with `rejection_reason` other than NONE is inadmissible for every claim status. Reasons: AFFILIATE_REVIEW, COURSE_FUNNEL, UNVERIFIED_SCREENSHOT, CONTENT_FARM, CIRCULAR_STATISTIC, UNDATED_LISTICLE, UNTRACEABLE_EARNINGS. Derivation rules the validator enforces: `publisher_incentive` AFFILIATE or SELLS_PRODUCT caps the tier at 6 and removes DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, and FINANCIAL_EDGE from `supportable_claim_classes`; `dated` false sets tier 7; a class B source whose `upstream_source_id` is missing or inadmissible is CIRCULAR_STATISTIC.

### EVD-03 Mandatory claim set and minimum admissible tier

Every record must hold one claim row for each class in the mandatory set of each component track; a missing mandatory claim is UNKNOWN and quarantines the record.

| Component | Mandatory claim classes |
|---|---|
| T1, T3, T4 | LEGALITY, PLATFORM_ELIGIBILITY, PLATFORM_POLICY_COMPLIANCE, PAYOUT_PATH, FEES_AND_COSTS, DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, DEPENDENCY_AVAILABILITY |
| T2 | LEGALITY, PLATFORM_ELIGIBILITY, PLATFORM_POLICY_COMPLIANCE, PAYOUT_PATH, FEES_AND_COSTS, FINANCIAL_EDGE, DEPENDENCY_AVAILABILITY |
| T5 | Union of its components |

| Claim class | Minimum tier | Additional requirement |
|---|---|---|
| LEGALITY | 1 or 2 | REG rows per FWK-61; `finding_basis` per FWK-02 |
| PLATFORM_ELIGIBILITY | 3 | Per account type and sub-check (FWK-03) |
| PLATFORM_POLICY_COMPLIANCE | 3 | Per platform dependency with `policy_finding` |
| PAYOUT_PATH | 3 | Every stage S05 to S11b and every hop documented |
| FEES_AND_COSTS | 3 | Within freshness |
| DEMAND | 4 or 5 | Denominator known (EVD-07) |
| EARNINGS_OR_CONVERSION | 4 or 5 | Denominator known; costs and dates disclosed; cited by receipts (FWK-31) |
| DISTRIBUTION_PERFORMANCE | 4 or 5 | `starting_audience_documented` ZERO (EVD-10) |
| FINANCIAL_EDGE | 4 | CAP-09 items present |
| DEPENDENCY_AVAILABILITY | 3 | Or logged platform confirmation |

A claim supported only by sources with an effective tier above its minimum is UNKNOWN, whatever its apparent plausibility.

### EVD-04 Independence classification and origin tracking

Each source carries `independence_class` and `origin_id`:

- Class A: genuinely independent underlying source or dataset with its own data collection; `origin_id` names that collection.
- Class B: a publication repeating, summarizing, or interpreting a registered source; `upstream_source_id` names it and `origin_id` is inherited. Effective tier is the worse of its own tier and the upstream's tier, and admissibility is inherited from the upstream.
- Class C: agreement between internal model, agent, or reviewer assessments.

Independent corroboration is counted as the number of distinct `origin_id` values among admissible class A sources. Class B sources add no origin. Class C never counts. Two class A sources sharing an `origin_id` are a register defect. A source with no `origin_id` is inadmissible.

### EVD-05 Internal agreement is not evidence

Agreement among subagents, reviewers, or repeated model passes is a consistency check on the architecture's application. It is recorded as class C and never raises a claim status, band, or gate value.

### EVD-06 Claim status assignment

Computed, never typed, from the claim's admissible sources (fit for the claim, class A or B, effective tier at or below the minimum, `admissible` true, `origin_id` present):

| Status | Assign when |
|---|---|
| UNKNOWN | No admissible source; or a performance claim with denominator unknown; or a FINANCIAL_EDGE claim missing any CAP-09 item; or a mandatory claim absent |
| OUTDATED | Every admissible source exceeds its freshness limit; expired sources otherwise simply do not count |
| CONTRADICTION | A linked contradiction row is FOUND_MATERIAL and UNRESOLVED |
| VERIFIED_FACT | An admissible tier 1 to 3 source within freshness for a class whose minimum tier is 3 or better, no unresolved contradiction |
| STRONGLY_SUPPORTED | At least two distinct origins among admissible class A sources within freshness, consistent, no unresolved contradiction |
| DIRECTIONAL | Exactly one origin, or class B support only |
| INFERENCE | Derived by logged reasoning from supported claims, with no direct source |
| ASSUMPTION | Adopted with an ASM row; a FAVORABLE_TO_CANDIDATE assumption requires `justification_logged` |
| HYPOTHESIS | Proposed for testing; or capped here when a performance claim's failure-base-rate search is NOT_DONE, when a contradiction row is RESOLVED_AGAINST_CLAIM and the claim is not yet restated, or when FINANCIAL_EDGE rests on a backtest alone (CAP-10) |

Additional caps: a FINANCIAL_EDGE claim from a single regime is at most DIRECTIONAL (CAP-08). Claim class, claim status, and the record's confidence band are three separate things and are never merged.

### EVD-07 Survivorship and denominator control

Every DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, and FINANCIAL_EDGE claim records `denominator` (the population from which reported outcomes were drawn) and links to FAILURE_ACCOUNT rows of the contradiction log. Denominator unknown makes the claim UNKNOWN with FURTHER_RESEARCH_REQUIRED. A claim with no FAILURE_ACCOUNT row is capped at HYPOTHESIS. `failure_base_rate_search` is computed from the log, never typed.

### EVD-08 Screenshots and earnings claims

A screenshot or self-reported figure carries zero evidential weight. It is tier 6 or 7 material and never supports a claim status, even with an attached export, unless the export itself is registered as a tier 4 dataset with its own `origin_id`.

### EVD-09 Contradiction and negative-evidence search minimum

For every record at L2 the verifier logs rows in the contradiction log with `search_type`, `dependency_id` or `jurisdiction`, queries, date, and result: one NEGATIVE_EVIDENCE row for the mechanism; one POLICY_REVERSAL row per platform dependency; one REGULATORY_ACTION row per mandatory jurisdiction role; one FAILURE_ACCOUNT row per performance claim. Conditional gate C8 closes only when every required row exists, including NONE_FOUND rows.

### EVD-10 Claim-source fit

Fit is recorded per claim-source pair in `source_fit`. A source supports only the classes its tier permits (EVD-01). Official policy documentation establishes eligibility, fees, and timing, never commercial results. For DISTRIBUTION_PERFORMANCE and DEMAND, a source is fit for a cold-start operator only when its `starting_audience_documented` is ZERO; NONZERO or UNDOCUMENTED sources are NOT_APPLICABLE. A source whose `jurisdiction` differs from the routed one is NOT_APPLICABLE for PLATFORM_ELIGIBILITY and LEGALITY. `operator_position` on every source records the position of the operator whose results it reports.

### EVD-11 Dating and recency

Every source records publication or last-updated date, access date, and `effective_date` where applicable. An undated source is tier 7. Freshness is measured per FWK-60 from the earlier of last-updated and access dates.

### EVD-12 Quantity is not quality

Source count, page count, document length, and research effort never raise a claim status, band, or gate. Many class B sources without a class A origin are at most DIRECTIONAL. Completion is judged by coverage of the mandatory claim set, claim-source fit, contradiction search, and recency, never by volume.

### EVD-13 Legal-source classification and non-inheritance

Every legal or compliance source is classified as BINDING_LAW, OFFICIAL_GUIDANCE, PROFESSIONAL_COMMENTARY, or RESEARCHER_INTERPRETATION, with issuing authority, jurisdiction, activity, effective date, access date, applicability, and uncertainty recorded. Platform policy is not a legal source and cannot appear on a REG row. A finding is separately classified by `finding_basis` (FWK-02): a researcher's reading of a binding source never inherits its authority. Where an operator-specific interpretation is needed, FWK-62 applies.

### EVD-14 Methodological references and adaptation limits

The following external references informed design decisions. Each is an adaptation, not external validation of this architecture. They are re-accessed and dated once per architecture version, not per research cycle.

| Reference | Used for | Adaptation limit |
|---|---|---|
| Cochrane Handbook, evidence assessment guidance | Claim-status and corroboration concepts | Designed for clinical evidence; tiers here are an analogy |
| UK Government Analysis Function, introductory guide to multi-criteria decision analysis | Reasons for avoiding a composite score; dominance and lexicographic ordering | Applied to ordering without weights |
| US GAO Schedule Assessment Guide | Critical-path discipline for the timing model | Scaled down to a 12-stage model |
| Bailey, Borwein, Lopez de Prado, Zhu, probability of backtest overfitting | CAP-09 and CAP-10 edge and backtest standards | Requires inputs that most candidates will lack; then edge is UNKNOWN |

Links were supplied in the planning stage and were not fetched during architecture construction; their availability is FURTHER_RESEARCH_REQUIRED at first use.
