# Changelog

## Design parameters (changed only by version)

| Parameter | Value | Rationale | Control |
|---|---|---|---|
| Risk near-limit threshold | 80 percent of an operator limit | Flags exposures approaching a limit before they exceed it | FWK-13 |
| Freshness limit, platform sources (tier 3) | 30 days | Platform terms change frequently and silently | FWK-60 |
| Freshness limit, regulatory sources (tiers 1 and 2) | 90 days | Regulatory change follows announcement cycles | FWK-60 |
| Freshness limit, datasets and research (tiers 4 and 5) | 365 days | Slower-moving evidence | FWK-60 |
| Freshness limit, practitioner and community (tiers 6 and 7) | 180 days | Discovery use only | FWK-60 |
| FX band for the conservative case | 3 percent widening of the converted AED figure | Bounds rate movement over a 30-day window without forecasting it | FWK-34, STR-11 |
| Query novelty for saturation | At least 50 percent new query strings per cell and one new surface or language | Prevents saturation by repeating identical queries | SYS-03 |
| Bias review floors | familiarity floor 30 percent of mechanisms from previously unknown sources; popularity floor 20 percent of mechanisms first seen beyond rank 10 or off-search | Below the floor a finding is mandatory; uncalibrated defaults | SYS-05 |
| Scenario capital and loss classes | C0 (0 AED), C1 (up to 2,000 AED), C2 (2,001 to 10,000 AED), C3 (above 10,000 AED) | Labels for bounded scenarios, not operator assumptions | FWK-44 |
| Scenario hours classes | H1 under 10, H2 10 to 25, H3 over 25 hours per week | Coarse bands avoid false precision | FWK-44 |
| Default scenario set | H1 or H2, by C0 or C1, by PERSONAL or COMPANY (eight scenarios) | Publishable without operator input | FWK-44 |
| Maximum published scenarios per report | 8 | Bounds scenario explosion | FWK-44 |
| Experiment maximum duration | 14 days | Keeps validation inside the horizon | FWK-35 |
| Saturation rule | Two consecutive complete, novelty-compliant family sweeps with zero new mechanisms | Bounded stopping rule, not exhaustiveness | SYS-06 |
| Significant figures in reports and ordering comparisons | 2 | Precision discipline | FWK-63 |

## Versions

### V0.1 (2026-09-17)

Initial architecture built from the audited and corrected implementation plan with all 22 corrections and 11 clarifications applied. Frozen to `versions/v0.1/` with a SHA-256 manifest before review. Three pre-freeze build defects (engine dedup wiring, one unqualified placeholder, missing findings file) are recorded in `tests/results.md`.

### V1.0 (2026-09-18)

Built from the six reviews of V0.1 recorded in `tests/red-team-findings.md` (93 findings: 10 critical, 37 high, 36 medium, 10 low). Every critical and high finding is fixed; medium and low findings are fixed or deferred with an owner and residual risk as recorded there. Principal changes: operator profile stage (SYS-00); identity step at the freeze with enumerated signature vocabulary, set-valued payer and supply fields, variants under mechanisms, survivor and promotion rules (STR-13, FWK-20); F15 and F16 as assignment classes, scope-note routing for seven blind-spot classes, family-sweep unit with novelty, structured bias reviews, split query, coverage, and audit templates (STR-01, SYS-03, SYS-05, SYS-06, FWK-21); FAIL-only L1 (STR-03); mandatory claim set per component track with all claims decision-critical (EVD-03); class B upstream inheritance, origin ids, derivation rules for affiliate, undated, and screenshot sources, computed claim status, denominator as UNKNOWN, contradiction-against cap, gate links (EVD-02 to EVD-10, FWK-60); finding basis on REG rows, mandatory jurisdiction rows, activity classes A11 to A14, authority register, derived professional-review flag (FWK-02, FWK-61, FWK-62); five G2 sub-checks per account type (FWK-03); twelve-stage timing with hops and S11b, stage-row computation, best case from documented values, case ordering, FAIL precedence (FWK-04, FWK-30); pre-tax net cash with reserve withheld, refund provision, dispute fees, withholding, computed principal, FX band (FWK-31 to FWK-34); track derivation from structured triggers with component tracks (FWK-10); capital cases per CAP-14, C5 closing only without UNKNOWN, mandatory edge claim, single edge ladder, unified capital field names, LEVERAGE risk type (CAP); C1a and C1b with a validation path, sales mode and interaction mode, dependency attestation, structured experiment preregistration, feasibility status and skill gaps (FWK-06, FWK-11, FWK-35 to FWK-38); eligibility reason lists, R0 and LOW outside ordering, lexicographic levels on disjoint rounded ranges, dominator lists (FWK-40 to FWK-47); portfolio weekly profiles and provider-keyed shared limits (FWK-50); research root and blind pack isolation (STR-14, SYS-16). Fixtures extended from 14 to 35 records plus 11 gate-matrix variants, 9 claim tests, 4 ordering tests, 4 portfolio tests; engine rewritten with no favorable defaults.
