# Architecture test results

Original results are preserved per version label and never overwritten (SYS-12). Fixture rows are controlled hypothetical architecture fixtures: stipulated facts testing framework logic only, never evidence, benchmarks, or ranking inputs.

# Results V0.1

Pre-freeze build defects fixed before freezing: duplicate-group dedup not wired in the engine (FIX-008b), an unqualified 'limits TBD' phrase in SYS-01, and a missing red-team findings file. Recorded here for completeness; they are build defects, not review findings.

## Fixture run: V0.1

Controlled hypothetical architecture fixtures. Stipulated facts test framework logic only; never evidence, benchmarks, or ranking inputs.

| Fixture | Note | State | Track | Cash band | Confidence | Detail | Result |
|---|---|---|---|---|---|---|---|
| FIX-001 | Strong candidate that should pass | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-002 | Weak candidate that should fail: payout threshold unattainable by Day 30 | REJECTED | T1 | None | None | G3 | PASS |
| FIX-003 | Candidate requiring quarantine: withdrawal availability undocumented | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-004 | Longer-horizon candidate: best case beyond Day 30 | REJECTED | T4 | None | None | G3 | PASS |
| FIX-005 | Capital-risk candidate without verified edge | QUARANTINED | T2 | CASH_B | UNRESOLVED | EVIDENCE_UNAVAILABLE | PASS |
| FIX-006 | Legally prohibited candidate under stipulated hypothetical rule | PROHIBITED | T1 | None | None | G1 | PASS |
| FIX-006b | Strong candidate with a material unresolved legal question | QUARANTINED | T1 | CASH_A | HIGH | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | PASS |
| FIX-007 | Candidate whose status changes after new evidence | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-007 | Phase 2: platform documentation confirms monetization | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-007 | Phase 3: platform source exceeds freshness limit | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-007 | Phase 4: source reverified, then a material contradiction on demand | QUARANTINED | T1 | CASH_A | UNRESOLVED | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-008a | Duplicate pair, first name | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-008b | Duplicate pair, second name, same signature | MERGED |  |  |  | merged into FIX-008a | PASS |
| FIX-009 | Day-25 sale with 14-day payout delay | ELIGIBLE | T1 | CASH_C | HIGH |  | PASS |
| FIX-010 | Platform viewable but unavailable for UAE monetization | REJECTED | T1 | None | None | G2 | PASS |
| FIX-011 | Highly scalable asset with no Day-30 cash path | ELIGIBLE | T4 | CASH_D | HIGH |  | PASS |
| FIX-013a | Plain, unglamorous evidence that should pass (false-rejection check) | ELIGIBLE | T1 | CASH_A | MODERATE |  | PASS |
| FIX-013b | Same structured facts with persuasive wording | ELIGIBLE | T1 | CASH_A | MODERATE |  | PASS |
| FIX-014 | Label evasion: described as risk-free arbitrage yield | QUARANTINED | T2 | CASH_A | UNRESOLVED | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | PASS |
| FIX-001-G1U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G1C | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G2F | gate matrix variant | REJECTED | T1 | None | None | G2 | PASS |
| FIX-001-G3U | gate matrix variant | QUARANTINED | T1 | CASH_U | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-001-G3F | gate matrix variant | REJECTED | T1 | None | None | G3 | PASS |
| FIX-001-G4F | gate matrix variant | REJECTED | T1 | None | None | G4 | PASS |
| FIX-001-G4U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G5F | gate matrix variant | REJECTED | T1 | None | None | G5 | PASS |
| FIX-001-G5U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G6F | gate matrix variant | REJECTED | T1 | None | None | G6 | PASS |
| FIX-001-G6U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-001-G7F | gate matrix variant | PROHIBITED | T1 | None | None | G7 | PASS |
| FIX-001-G7U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-C1 | gate matrix variant | CONDITIONAL | T1 | CASH_A | HIGH | C1 | PASS |
| FIX-001-C2 | gate matrix variant | CONDITIONAL | T1 | CASH_A | HIGH | C2 | PASS |
| FIX-008a/b | dedup: unique signatures | 1 |  |  |  |  | PASS |
| CT-01 | Internal agreement never raises status | DIRECTIONAL | DIRECTIONAL |  |  | classA=1 | PASS |
| CT-02 | Ten republications of one upstream cap at DIRECTIONAL | UNKNOWN | DIRECTIONAL |  |  | classA=0 | PASS |
| CT-03 | Two class B with same upstream as one class A count as one independent source | DIRECTIONAL | DIRECTIONAL |  |  | classA=1 | PASS |
| OT-02 | Dominance | front=['FIX-OT2-A'] | dominated={'FIX-OT2-B': 'FIX-OT2-A'} | ties=[] |  |  | PASS |
| OT-01 | Tie preserved | front=['FIX-OT1-A', 'FIX-OT1-B'] | dominated={} | ties=[('FIX-OT1-A', 'FIX-OT1-B')] |  |  | PASS |
| FIX-012 | Three individually feasible members that are infeasible together | INFEASIBLE | individually=['R1'] | breakpoints={'hours': 45, 'capital': 9000, 'loss': 4500} |  |  | PASS |
| FIX-012b | Same members with operator limits missing | CONDITIONAL | individually=['R0'] | breakpoints={'hours': 45, 'capital': 9000, 'loss': 4500} |  |  | PASS |
| FIX-012c | Same members with an unknown shared account limit | BLOCKED_UNKNOWN | individually=['R1'] | breakpoints={'hours': 12, 'capital': 600, 'loss': 600} |  |  | PASS |

| Test | Result |
|---|---|
| FIXTURES | PASS |
| T-11 | PASS |
| T-12 | PASS |
| T-13 | PASS |
| T-14 | PASS |
| T-16 | PASS |
| T-17 | PASS |
| T-18 | PASS |
| T-19 | PASS |
| T-20 | PASS |
| T-21 | PASS |
| T-23 | PASS |
| T-24 | PASS |
| T-25 | PASS |
| T-26 | PASS |
| T-27 | PASS |
| T-28 | PASS |
| T-29 | PASS |
| T-30 | PASS |
| T-31 | PASS |
| T-32 | PASS |
| T-33 | PASS |
| T-34 | PASS |
| T-35 | PASS |
| T-36 | PASS |

Gate coverage: G1=['FAIL', 'PASS', 'UNKNOWN'], G2=['FAIL', 'PASS', 'UNKNOWN'], G3=['FAIL', 'PASS', 'UNKNOWN'], G4=['FAIL', 'PASS', 'UNKNOWN'], G5=['FAIL', 'PASS', 'UNKNOWN'], G6=['FAIL', 'PASS', 'UNKNOWN'], G7=['FAIL', 'PASS', 'UNKNOWN']

## Manual tests V0.1

| Test | Result | Note |
|---|---|---|
| T-37 | PENDING | Blinded repeatability runs after the V0.1 freeze |
| T-38 | PENDING | Six reviews run after the V0.1 freeze |

## Structural validation after freeze V0.1

| Test | Result | Note |
|---|---|---|
| T-01 | PASS | 103 controls defined once; duplicates={}; index complete=True |
| T-02 | PASS | 103 distinct control references resolve |
| T-03 | PASS | all relative links and anchors resolve |
| T-04 | PASS | 316 fields, all with existing consumers |
| T-05 | PASS | no fixture identifiers outside tests/ |
| T-06 | PASS | no unqualified placeholders |
| T-07 | PASS | 56 requirements and 30 failure modes trace to existing controls and tests |
| T-08 | FAIL | tests without a result row for V0.1: ['T-01', 'T-02', 'T-03', 'T-04', 'T-05', 'T-06', 'T-07', 'T-08', 'T-09', 'T-10', 'T-15', 'T-22', 'T-39', 'T-40', 'T-41'] |
| T-09 | PASS | 11 states; unreferenced: [] |
| T-10 | PASS | v0.1 manifest validates |
| T-12 | PASS | fixture engine reports full PASS/FAIL/UNKNOWN coverage for G1..G7 |
| T-15 | PASS | scalability_note consumer is exactly [STR-10] |
| T-22 | PASS | no STIPULATED provenance outside schemas and definitions |
| T-39 | PASS | five validation-status headings present |
| T-40 | PASS | design parameters recorded |
| T-41 | PASS | non-exhaustiveness stated in SYS-06 and STR-10 |

# Results V1.0

Release status: RELEASED. All release conditions in 07-quality-and-release-audit.md read PASS.

Run date 2026-09-18 against the V1.0 working set after all corrections in tests/red-team-findings.md. The first V1.0 fixture run failed OT-03 because record B dominated record A outright; the fixture was adjusted so that neither dominates (recorded in fixtures.md) and the suite was rerun. Original V0.1 results above are preserved unchanged.

## Fixture run: V1.0

Controlled hypothetical architecture fixtures. Stipulated facts test framework logic only; never evidence, benchmarks, or ranking inputs.

| Fixture | Note | State | Track | Cash band | Confidence | Detail | Result |
|---|---|---|---|---|---|---|---|
| DEDUP | FWK-20 over all fixture records before evaluation | mecs=5 | merged={'FIX-008b': 'FIX-008a'} |  |  |  | PASS |
| FIX-001 | Strong candidate that should pass | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-002 | Weak candidate that should fail: payout threshold unattainable in every case | REJECTED | T1 |  |  | G3 | PASS |
| FIX-003 | Candidate requiring quarantine: withdrawal availability undocumented | QUARANTINED | T1 |  |  | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-004 | Longer-horizon candidate: best case beyond Day 30 | REJECTED | T4 |  |  | G3 | PASS |
| FIX-005 | Capital-risk candidate without verified edge (professional opinion stipulated as logged) | QUARANTINED | T2 |  |  | EVIDENCE_UNAVAILABLE | PASS |
| FIX-005b | Capital-risk candidate with stipulated strong edge: principal never income, conservative case is a loss | ELIGIBLE | T2 | CASH_C | HIGH |  | PASS |
| FIX-006 | Legally prohibited candidate under a stipulated hypothetical restriction | PROHIBITED | T1 |  |  | G1 | PASS |
| FIX-006b | Strong candidate with a material unresolved legal question | QUARANTINED | T1 |  |  | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | PASS |
| FIX-007 | Candidate whose status changes after new evidence | QUARANTINED | T1 |  |  | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-007 | Phase 2: platform documentation confirms monetization | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-007 | Phase 3: platform eligibility source exceeds freshness limit | QUARANTINED | T1 |  |  | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-007 | Phase 4: source reverified, then a material demand contradiction | QUARANTINED | T1 |  |  | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-008a | Duplicate group, first name | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-008b | Duplicate group, second name, identical signature and variant | MERGED |  |  |  | into FIX-008a | PASS |
| FIX-008c | Same mechanism, different platform variant: separate OPP under one MEC | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-009 | Day-25 sale (base case) with 14-day payout; only a best-case Day-14 sale reaches usable cash by Day 30 | ELIGIBLE | T4 | CASH_C | HIGH |  | PASS |
| FIX-010 | Platform viewable but unavailable for UAE monetization on every account type | REJECTED | T1 |  |  | G2 | PASS |
| FIX-011 | Highly scalable asset with no Day-30 cash path | ELIGIBLE | T4 | CASH_D | HIGH | no-30-day-cash | PASS |
| FIX-013a | Plain evidence that should pass (false-rejection check) | ELIGIBLE | T1 | CASH_A | MODERATE |  | PASS |
| FIX-013b | Same structured facts with persuasive wording | ELIGIBLE | T1 | CASH_A | MODERATE |  | PASS |
| FIX-014 | Label evasion: typed capital_role NONE and described as risk-free arbitrage yield; structured triggers say capital at risk | QUARANTINED | T2 |  |  | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | PASS |
| FIX-015 | Capital at risk by signature with every researcher-typed flag favorable | QUARANTINED | T2 |  |  | EVIDENCE_UNAVAILABLE | PASS |
| FIX-016 | Stage-row critical path with a PARALLEL stage overlapping KYC | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-017 | Availability differs by account type and the account type is unsupplied | QUARANTINED | T1 |  |  | OPERATOR_INPUT_REQUIRED | PASS |
| FIX-017b | Same divergence with the account type supplied as COMPANY | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-018 | Missing inputs are never defaulted favorably | QUARANTINED | T1 |  |  | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-019 | Missing mandatory demand claim | QUARANTINED | T1 |  |  | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-020 | Proposal-driven selling with no named person | REJECTED | T1 |  |  | G5 | PASS |
| FIX-021 | Dependency map not attested by an independent perspective | QUARANTINED | T1 |  |  | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-022 | Platform policy source expired | QUARANTINED | T1 |  |  | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-024 | Demand evidence without a failure-base-rate search: LOW confidence, listed outside ordering | ELIGIBLE | T1 | CASH_A | LOW | insufficient-evidence | PASS |
| FIX-025 | Refund rate undocumented: conservative case unknown | CONDITIONAL | T1 | CASH_U | HIGH | C3 | PASS |
| FIX-026 | Tax marked resolved without a professional opinion id | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-027 | Hybrid: earned plus reward components | ELIGIBLE | T5 | CASH_A | HIGH |  | PASS |
| FIX-028 | Hybrid: earned plus capital component inherits CAP | QUARANTINED | T5 |  |  | EVIDENCE_UNAVAILABLE | PASS |
| FIX-029 | Documented FAIL takes precedence over an unknown stage | REJECTED | T1 |  |  | G3 | PASS |
| FIX-030 | Licence required and licence scope unsupplied | QUARANTINED | T1 |  |  | OPERATOR_INPUT_REQUIRED | PASS |
| FIX-030b | Restriction found in a rule that does not apply | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-001-R0 | gate matrix variant | ELIGIBLE | T1 | CASH_A | HIGH | unassessed-risk | PASS |
| FIX-001-G3U | gate matrix variant | QUARANTINED | T1 |  |  | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-001-G4F | gate matrix variant | REJECTED | T1 |  |  | G4 | PASS |
| FIX-001-G4U | gate matrix variant | QUARANTINED | T1 |  |  | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G5F | gate matrix variant | REJECTED | T1 |  |  | G5 | PASS |
| FIX-001-G6F | gate matrix variant | REJECTED | T1 |  |  | G6 | PASS |
| FIX-001-G7F | gate matrix variant | PROHIBITED | T1 |  |  | G7 | PASS |
| FIX-001-G7U | gate matrix variant | QUARANTINED | T1 |  |  | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-C1 | gate matrix variant | CONDITIONAL | T1 | CASH_A | HIGH | C1a | PASS |
| FIX-001-C2 | gate matrix variant | CONDITIONAL | T1 | CASH_A | HIGH | C2 | PASS |
| FIX-001-FEAS | gate matrix variant | REJECTED | T1 |  |  | FEASIBILITY | PASS |
| CT-01 | Internal agreement never raises status | DIRECTIONAL | DIRECTIONAL |  |  | origins=1 | PASS |
| CT-02 | Ten republications of an unregistered upstream stay UNKNOWN | UNKNOWN | UNKNOWN |  |  | origins=0 | PASS |
| CT-03 | One class A plus two class B sharing its origin count as one origin | DIRECTIONAL | DIRECTIONAL |  |  | origins=1 | PASS |
| CT-04 | Class B with a registered admissible tier-4 upstream gives DIRECTIONAL | DIRECTIONAL | DIRECTIONAL |  |  | origins=0 | PASS |
| CT-05 | Affiliate-incentive source cannot support a performance claim | UNKNOWN | UNKNOWN |  |  | origins=0 | PASS |
| CT-06 | Undated source is tier 7 | UNKNOWN | UNKNOWN |  |  | origins=0 | PASS |
| CT-07 | Contradiction resolved against the claim caps at HYPOTHESIS | HYPOTHESIS | HYPOTHESIS |  |  | origins=2 | PASS |
| CT-08 | Unknown denominator makes a performance claim UNKNOWN | UNKNOWN | UNKNOWN |  |  | origins=0 | PASS |
| CT-09 | Edge with all five items but a single regime is DIRECTIONAL; a missing item makes it UNKNOWN | DIRECTIONAL | UNKNOWN |  |  | origins=1 | PASS |
| OT-02 | Dominance | front=['FIX-OT2-A'] | dominated={'FIX-OT2-B': ['FIX-OT2-A']} | ties=[] | decided={} |  | PASS |
| OT-01 | Tie preserved when every level overlaps | front=['FIX-OT1-A', 'FIX-OT1-B'] | dominated={} | ties=[('FIX-OT1-A', 'FIX-OT1-B')] | decided={} |  | PASS |
| OT-03 | Lexicographic order decided at the S11b level when NCC overlaps | front=['FIX-OT3-A', 'FIX-OT3-B'] | dominated={} | ties=[] | decided={('FIX-OT3-A', 'FIX-OT3-B'): 'FWK-42:s11'} |  | PASS |
| OT-04 | Tie-breaker on platform concentration after every level overlaps | front=['FIX-OT4-A', 'FIX-OT4-B'] | dominated={} | ties=[] | decided={('FIX-OT4-A', 'FIX-OT4-B'): 'FWK-43:concentration'} |  | PASS |
| FIX-012 | Three individually feasible members infeasible together | INFEASIBLE | individually=['R1'] | breakpoints={'peak_week_hours': 78.8, 'capital': 9000, 'loss': 4500, 'shared_providers': ['PLAT-001', 'PROC-001']} |  |  | PASS |
| FIX-012b | Same members with operator limits missing | CONDITIONAL | individually=['R1'] | breakpoints={'peak_week_hours': 78.8, 'capital': 9000, 'loss': 4500, 'shared_providers': ['PLAT-001', 'PROC-001']} |  |  | PASS |
| FIX-012c | Same members with an unknown shared account limit | BLOCKED_UNKNOWN | individually=['R1'] | breakpoints={'peak_week_hours': 13.5, 'capital': 600, 'loss': 600, 'shared_providers': ['PLAT-001', 'PLAT-SHARED', 'PROC-001']} |  |  | PASS |
| FIX-023 | Week-1 setup peak exceeds the limit although recurring hours sum within it | INFEASIBLE | individually=['R1'] | breakpoints={'peak_week_hours': 157.5, 'capital': 600, 'loss': 600, 'shared_providers': ['PLAT-001', 'PROC-001']} |  |  | PASS |

| Test | Result |
|---|---|
| FIXTURES | PASS |
| T-11 | PASS |
| T-12 | PASS |
| T-13 | PASS |
| T-14 | PASS |
| T-16 | PASS |
| T-17 | PASS |
| T-18 | PASS |
| T-19 | PASS |
| T-20 | PASS |
| T-21 | PASS |
| T-23 | PASS |
| T-24 | PASS |
| T-25 | PASS |
| T-26 | PASS |
| T-27 | PASS |
| T-28 | PASS |
| T-29 | PASS |
| T-30 | PASS |
| T-31 | PASS |
| T-32 | PASS |
| T-33 | PASS |
| T-34 | PASS |
| T-35 | PASS |
| T-36 | PASS |
| T-42 | PASS |
| T-43 | PASS |
| T-44 | PASS |
| T-45 | PASS |
| T-46 | PASS |
| T-47 | PASS |
| T-48 | PASS |
| T-49 | PASS |
| T-50 | PASS |
| T-51 | PASS |
| T-52 | PASS |
| T-53 | PASS |

Gate coverage: G1=['FAIL', 'PASS', 'UNKNOWN'], G2=['FAIL', 'PASS', 'UNKNOWN'], G3=['FAIL', 'PASS', 'UNKNOWN'], G4=['FAIL', 'PASS', 'UNKNOWN'], G5=['FAIL', 'PASS', 'UNKNOWN'], G6=['FAIL', 'PASS', 'UNKNOWN'], G7=['FAIL', 'PASS', 'UNKNOWN']

## Structural validation V1.0 (final)
| Test | Result | Note |
|---|---|---|
| T-01 | PASS | 104 controls defined once; duplicates={}; index complete=True |
| T-02 | PASS | 104 distinct control references resolve |
| T-03 | PASS | all relative links and anchors resolve |
| T-04 | PASS | 409 fields, all with existing consumers |
| T-05 | PASS | no fixture identifiers outside tests/ |
| T-06 | PASS | no unqualified placeholders |
| T-07 | PASS | 65 requirements and 38 failure modes trace to existing controls and tests |
| T-08 | PASS | all 54 tests have result rows for V1.0 |
| T-09 | PASS | 11 states; unreferenced: [] |
| T-10 | PASS | v0.1 manifest validates |
| T-12 | PASS | fixture engine reports full PASS/FAIL/UNKNOWN coverage for G1..G7 |
| T-15 | PASS | scalability_note consumer is exactly [STR-10] |
| T-22 | PASS | no STIPULATED provenance outside schemas and definitions |
| T-39 | PASS | five validation-status headings present |
| T-40 | PASS | design parameters recorded |
| T-41 | PASS | non-exhaustiveness stated in SYS-06 and STR-10 |
| T-54 | PASS | all 101 engine input fields exist on templates |

## Manual tests V1.0

| Test | Result | Note |
|---|---|---|
| T-37 | PASS | Blinded evaluator reproduced state, track, band, and portfolio result for every V0.1 fixture by hand; two divergences became RT-R7 and fourteen ambiguities were resolved in V1.0 text (see red-team-findings.md). The V1.0 blind pack is regenerated under tests/blind/ for the next cycle. |
| T-38 | PASS | Six reviews completed against the frozen V0.1; 93 findings dispositioned; no critical or high open. |

## Supplementary quality scores V1.0 (integrator self-assessment; supplementary only)

| Dimension | Explicit rule | Operational instructions | Ordinary case | Adverse case | Traceability | Total |
|---|---|---|---|---|---|---|
| 1 | 2 | 2 | 2 | 2 | 2 | 10 |
| 2 | 2 | 2 | 2 | 1 | 2 | 9 |
| 3 | 2 | 2 | 2 | 1 | 2 | 9 |
| 4 | 2 | 2 | 2 | 2 | 2 | 10 |
| 5 | 2 | 2 | 2 | 2 | 2 | 10 |
| 6 | 2 | 2 | 2 | 2 | 2 | 10 |
| 7 | 2 | 2 | 2 | 2 | 2 | 10 |
| 8 | 2 | 2 | 2 | 2 | 2 | 10 |
| 9 | 2 | 2 | 2 | 1 | 2 | 9 |
| 10 | 2 | 2 | 2 | 2 | 2 | 10 |
| 11 | 2 | 2 | 2 | 2 | 2 | 10 |
| 12 | 2 | 2 | 2 | 2 | 2 | 10 |
| 13 | 2 | 2 | 2 | 1 | 2 | 9 |
| 14 | 2 | 2 | 2 | 2 | 2 | 10 |
| 15 | 2 | 2 | 2 | 2 | 2 | 10 |
| 16 | 2 | 2 | 2 | 2 | 2 | 10 |
| 17 | 2 | 2 | 2 | 2 | 2 | 10 |
| 18 | 2 | 2 | 2 | 1 | 2 | 9 |
| 19 | 2 | 2 | 2 | 2 | 2 | 10 |
| 20 | 2 | 1 | 2 | 2 | 2 | 9 |

Adverse-case checks scored 1 where behavior under real research volume is unvalidated (dimensions 2, 3, 9, 13, 18); operational instructions scored 1 for skill convertibility because the engine is a reference model rather than a skill.
