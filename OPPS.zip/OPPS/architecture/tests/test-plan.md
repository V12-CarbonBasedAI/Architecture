# Test plan: architecture tests, adversarial themes, and edge conditions

Owner: SYS-11 and SYS-12 define the process; this file defines the tests. Structural tests run in `validate.py`. Logic tests run in `run_fixtures.py` against `fixtures.json`. Manual tests are recorded in `results.md` with the reviewer perspective. Every fixture is a controlled hypothetical architecture fixture: stipulated facts test framework logic only and are never empirical evidence, commercial benchmarks, profitability validation, or inputs to later opportunity rankings.

## Structural tests (validate.py)

| ID | Test | Pass condition |
|---|---|---|
| T-01 | Control ID uniqueness and index | Every SYS, STR, FWK, EVD, CAP heading appears exactly once across rule files and in the README control index |
| T-02 | Control references resolve | Every control ID referenced anywhere exists |
| T-03 | Links and anchors | Every relative markdown link and heading anchor resolves |
| T-04 | Template schemas | Every template front matter parses; every field has a consumer; every consumer ID exists; admin fields have a justification; enum fields list allowed values |
| T-05 | Fixture isolation | No `FIX-` plus three digits outside `tests/`, scanning every file under `research/` and every markdown file elsewhere |
| T-06 | No placeholders | No TODO, TBC, XXX, FIXME, lorem, or "TBD" not qualified as Open/TBD in any rule file or template |
| T-07 | Traceability | Every REQ names at least one existing control and one existing test; every FM names an existing control |
| T-08 | Test results recorded | Every T-id in this plan has a result row in `results.md` for the current version |
| T-09 | State machine closure | Every state in the STR-04 transition table is in the state list and every state appears in at least one transition |
| T-10 | Manifest | `versions/v0.1/MANIFEST.sha256` matches the frozen files |
| T-12 | Gate coverage | Across fixtures, every gate G1 to G7 is exercised at PASS, FAIL, and UNKNOWN |
| T-15 | Scalability isolation | `scalability_note` lists STR-10 as its only consumer |
| T-22 | Provenance isolation | No STIPULATED provenance value outside schemas, definitions, and `tests/` |
| T-39 | Five-way status | `07-quality-and-release-audit.md` contains all five validation-status headings |
| T-40 | Design parameters | `CHANGELOG.md` records the risk threshold, the four freshness limits, the FX band, the bias floors, and the scenario class thresholds |
| T-41 | Non-exhaustiveness | SYS-06 and STR-10 both state that saturation is not exhaustive discovery |
| T-54 | Engine inputs on templates | Every structured input the engine reads exists as a template field |

## Logic tests (run_fixtures.py)

| ID | Test | Pass condition |
|---|---|---|
| T-11 | Label evasion | A record described as risk-free arbitrage yield with capital_role typed NONE, and a record with every typed flag favorable, both have a T2 component from signature triggers and CAP applies (FIX-014, FIX-015) |
| T-13 | Dedup before coverage | Deduplication runs over the whole fixture set before any evaluation; identical signature and variant merge; same signature with a different variant is a separate OPP under one MEC; the MEC count equals the preregistered count (FIX-008a, FIX-008b, FIX-008c) |
| T-14 | Track before track gates | CAP is applied only to records with a T2 component and never to FIX-001 |
| T-16 | Principal never income | Recovered principal is computed from capital deployed and receipts, the conservative capital case is a loss, and base-case net cash excludes principal (FIX-005b) |
| T-17 | Day 30 ends at S11b | Usable-cash day is computed from stage rows including PARALLEL overlap (FIX-016); a base-case sale on Day 25 with a 14-day payout does not support the horizon (FIX-009) |
| T-18 | Portfolio aggregation | Weekly workload profiles from critical paths, capital sums, shared providers, and unknown shared limits produce INFEASIBLE, CONDITIONAL, and BLOCKED_UNKNOWN as preregistered (FIX-012, FIX-012b, FIX-012c, FIX-023) |
| T-19 | Freshness expiry | An ELIGIBLE record whose platform-eligibility source expires becomes QUARANTINED (FIX-007 phase 3) |
| T-20 | Unknown means quarantine | One UNKNOWN fatal gate with everything else strong gives QUARANTINED with no bands assigned (FIX-003) |
| T-21 | Reopen on evidence | QUARANTINED, then ELIGIBLE after admissible evidence, then QUARANTINED after a material contradiction (FIX-007) |
| T-23 | Internal agreement not evidence | Adding class C sources never raises a claim status (CT-01) |
| T-24 | Wording invariance | Identical structured fields with different descriptions produce identical outputs (FIX-013a, FIX-013b) |
| T-25 | Volume not quality | Ten republications of an unregistered upstream stay UNKNOWN (CT-02) |
| T-26 | Monotonicity | Increasing hold days or costs never improves the cash band or net cash (FIX-001 perturbations) |
| T-27 | No favorable defaults | Missing operator limits give R0 and an unassessed-risk listing, never an ordering position (FIX-001-R0); missing limits give a CONDITIONAL portfolio (FIX-012b) |
| T-28 | Republication not corroboration | Two class B sources sharing a class A origin count as one origin (CT-03) |
| T-29 | Legal override | A researcher reading or an unresolved customer-jurisdiction row, and any A5 activity without a professional opinion, quarantine with PROFESSIONAL_LEGAL_REVIEW_REQUIRED (FIX-006b, FIX-014) |
| T-30 | Prohibition stops | A verified applicable restriction gives PROHIBITED with no bands (FIX-006) |
| T-31 | Ties preserved | Overlapping ranges on every level and equal tie-breakers report a tie (OT-01) |
| T-32 | Non-dominance | A dominated record is placed behind its dominator and every dominator is named (OT-02) |
| T-33 | Scalable asset excluded | A CASH_D record is absent from the ordering and its outputs are unchanged when the scalability note is removed (FIX-011) |
| T-34 | Day-25 sale with 14-day payout | Band is CASH_C, labelled best case only (FIX-009) |
| T-35 | Viewable not monetizable | Monetization unavailable on every account type gives REJECTED at G2 (FIX-010) |
| T-36 | Capital risk without edge | Missing edge evidence quarantines the record, expected return is UNKNOWN, no bands are assigned (FIX-005) |
| T-42 | Missing inputs and claims | Deleted gate inputs and a deleted mandatory claim both quarantine (FIX-018, FIX-019) |
| T-43 | Bespoke selling | Proposal-driven selling is REJECTED at G5; an unattested dependency map leaves G5 UNKNOWN (FIX-020, FIX-021) |
| T-44 | Account-type divergence | Divergent availability with the account type unsupplied gives OPERATOR_INPUT_REQUIRED; supplied as COMPANY gives ELIGIBLE (FIX-017, FIX-017b) |
| T-45 | Policy source expiry | An expired platform-policy claim leaves G6 UNKNOWN (FIX-022) |
| T-46 | Insufficient evidence | A HYPOTHESIS-capped demand claim gives LOW confidence and an insufficient-evidence listing outside the ordering (FIX-024) |
| T-47 | Reserve and tax | Undocumented refund rate gives CASH_U and CONDITIONAL; tax marked resolved without an opinion id stays PROFESSIONAL_TAX_REVIEW_REQUIRED (FIX-025, FIX-026) |
| T-48 | Hybrids | Earned plus reward is T5 in the income ordering; earned plus capital is T5 with CAP applied (FIX-027, FIX-028) |
| T-49 | G1 and G3 precedence | Documented FAIL precedes an unknown stage; licence required with scope unsupplied gives OPERATOR_INPUT_REQUIRED; a restriction that does not apply never prohibits (FIX-029, FIX-030, FIX-030b) |
| T-50 | Source derivation rules | Class B with a registered admissible upstream is DIRECTIONAL; affiliate incentive and undated sources cannot support performance claims; contradiction resolved against caps at HYPOTHESIS; unknown denominator is UNKNOWN; edge ladder (CT-04 to CT-09) |
| T-51 | Lexicographic level | When net-cash ranges overlap and neither dominates, the order is decided at the S11b level and the level is named (OT-03) |
| T-52 | Tie-breaker | After every level overlaps, platform concentration decides and is named (OT-04) |
| T-53 | Strong record ordered | With a supplied operator profile the strong record is R1, WITHIN, and enters the ordering (FIX-001) |

## Manual tests

| ID | Test | Pass condition |
|---|---|---|
| T-37 | Blinded repeatability | An evaluator who did not see expected outcomes reproduces the state and band of every fixture; divergences are logged as findings |
| T-38 | Six reviews | All six SYS-11 reviews completed against the frozen V0.1, every finding dispositioned, no critical or high open |

## Adversarial themes and edge conditions

| Theme | Tests |
|---|---|
| Republication mistaken for corroboration | T-28, T-25 |
| Internal agreement mistaken for evidence | T-23 |
| Fixture contamination of rankings | T-05, T-22 |
| Volume masking missing critical claims | T-25, T-42 |
| Returned principal counted as earnings | T-16 |
| Operator scenarios becoming favorable defaults | T-27, T-44, T-47 |
| Individually feasible candidates forming an infeasible portfolio | T-18 |
| Persuasive wording changing outcomes | T-24, T-11 |
| Costs or delays rising while assessments improve | T-26 |
| New evidence reopening decisions | T-21 |
| Mislabelled capital-risk entering the earned track | T-11, T-48 |
| Synonym inflating coverage | T-13 |
| Expired source supporting approval | T-19, T-45 |
| Unknown gate treated as conditional pass | T-20, T-42 |
| Scalability leaking into 30-day ordering | T-15, T-33 |
| Legal unknown overridden by strength elsewhere | T-29, T-49 |
| Prohibition followed by scoring | T-30 |
| Ties forced into a total order | T-31, T-51, T-52 |
| Hype, affiliate, screenshot, undated sources laundered into evidence | T-50 |
| Bespoke selling hidden in dependencies | T-43 |
