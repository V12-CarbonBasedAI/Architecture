#!/usr/bin/env python3
"""Fixture engine V1.0: applies the Framework rules (04, 05, 06) to controlled hypothetical
architecture fixtures and compares results with preregistered expected outcomes.
Everything here is STIPULATED. Nothing is evidence about any real opportunity.
Absent inputs are never defaulted favorably: a missing required key evaluates as UNKNOWN (FWK-01).
Usage: python3 run_fixtures.py [--label V1.0] [--blind]
"""
import copy, json, math, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
MIN_TIER = {"LEGALITY": 2, "PLATFORM_ELIGIBILITY": 3, "PLATFORM_POLICY_COMPLIANCE": 3, "PAYOUT_PATH": 3,
            "FEES_AND_COSTS": 3, "DEMAND": 5, "EARNINGS_OR_CONVERSION": 5, "DISTRIBUTION_PERFORMANCE": 5,
            "FINANCIAL_EDGE": 4, "DEPENDENCY_AVAILABILITY": 3}
PERF = {"DEMAND", "EARNINGS_OR_CONVERSION", "DISTRIBUTION_PERFORMANCE", "FINANCIAL_EDGE"}
MANDATORY = {"T1": ["LEGALITY", "PLATFORM_ELIGIBILITY", "PLATFORM_POLICY_COMPLIANCE", "PAYOUT_PATH", "FEES_AND_COSTS", "DEMAND", "EARNINGS_OR_CONVERSION", "DISTRIBUTION_PERFORMANCE", "DEPENDENCY_AVAILABILITY"],
             "T2": ["LEGALITY", "PLATFORM_ELIGIBILITY", "PLATFORM_POLICY_COMPLIANCE", "PAYOUT_PATH", "FEES_AND_COSTS", "FINANCIAL_EDGE", "DEPENDENCY_AVAILABILITY"]}
MANDATORY["T3"] = MANDATORY["T1"]; MANDATORY["T4"] = MANDATORY["T1"]
RANK = ["VERIFIED_FACT", "STRONGLY_SUPPORTED", "DIRECTIONAL", "INFERENCE", "ASSUMPTION", "HYPOTHESIS"]
UNRES = {"CONTRADICTION", "UNKNOWN", "OUTDATED"}
CASH_ORDER = ["CASH_A", "CASH_B", "CASH_C", "CASH_D", "CASH_U"]
CONF_ORDER = ["HIGH", "MODERATE", "LOW", "UNRESOLVED"]
RISK_ORDER = ["R1", "R2", "R3", "R0"]
BANDED = {"CONDITIONAL", "ELIGIBLE", "VALIDATION_PENDING", "VALIDATED", "INVALIDATED"}
UNK = "UNKNOWN"

# ---------- patching ----------
def apply_patch(rec, patch):
    rec = copy.deepcopy(rec)
    for path, val in patch.items():
        parts = path.split("."); node = rec
        for p in parts[:-1]:
            node = _step(node, p)
        last = parts[-1]
        if last == "+":
            node.append(copy.deepcopy(val))
        elif last == "-":
            node[:] = [x for x in node if not (isinstance(x, dict) and x.get("id") == val)]
        elif isinstance(node, list):
            for i, item in enumerate(node):
                if isinstance(item, dict) and item.get("id") == last:
                    node[i] = copy.deepcopy(val)
        elif val == "__DELETE__":
            node.pop(last, None)
        else:
            node[last] = copy.deepcopy(val)
    return rec

def _step(node, p):
    if isinstance(node, list):
        for item in node:
            if isinstance(item, dict) and item.get("id") == p:
                return item
        raise KeyError(p)
    return node[p]

def g(d, k):
    """Strict getter: absent key means UNKNOWN (FWK-01)."""
    return d.get(k, UNK) if isinstance(d, dict) else UNK

def rng(v):
    return isinstance(v, list) and len(v) == 2

# ---------- EVD-02 / EVD-04 source admissibility ----------
def effective_source(s):
    """Returns (admissible, effective_tier, origin) applying EVD-02 and EVD-04."""
    tier = g(s, "tier"); indep = g(s, "indep"); origin = g(s, "origin")
    if tier == UNK or indep == UNK or origin in (UNK, None):
        return False, 7, None
    if g(s, "rejection_reason") not in (UNK, "NONE"):
        return False, 7, origin
    if g(s, "dated") is False:
        tier = 7
    if g(s, "publisher_incentive") in ("AFFILIATE", "SELLS_PRODUCT"):
        tier = max(tier, 6)
    if indep == "C":
        return False, tier, origin
    if indep == "B":
        if not g(s, "upstream_registered") or g(s, "upstream_admissible") is not True:
            return False, 7, origin          # CIRCULAR_STATISTIC
        tier = max(tier, g(s, "upstream_tier") if g(s, "upstream_tier") != UNK else 7)
    return True, tier, origin

# ---------- EVD-06 claim status ----------
def claim_status(claim):
    cls = g(claim, "class")
    if cls == UNK:
        return UNK, 0
    adm = []
    for s in g(claim, "sources") if g(claim, "sources") != UNK else []:
        ok, tier, origin = effective_source(s)
        if not ok or tier > MIN_TIER[cls] or g(s, "fit") is not True:
            continue
        if cls in ("DEMAND", "DISTRIBUTION_PERFORMANCE") and g(s, "starting_audience") != "ZERO":
            continue                          # EVD-10 cold-start fit
        adm.append((s, tier, origin))
    if not adm:
        return UNK, 0
    fresh = [a for a in adm if g(a[0], "fresh") is True]
    if not fresh:
        return "OUTDATED", 0
    if g(claim, "contradiction") == "UNRESOLVED":
        return "CONTRADICTION", 0
    if cls in PERF and g(claim, "denominator_known") is not True:
        return UNK, 0
    if cls == "FINANCIAL_EDGE":
        e = g(claim, "edge")
        if e == UNK or any(g(e, k) in (UNK, "NO", None) for k in ("out_of_sample", "net_of_costs")) or any(g(e, k) in (UNK, None) for k in ("sample_size", "trials")):
            return UNK, 0
    origins = {a[2] for a in fresh if a[0]["indep"] == "A"}
    n = len(origins)
    if any(a[1] <= 3 for a in fresh) and MIN_TIER[cls] <= 3:
        status = "VERIFIED_FACT"
    elif n >= 2:
        status = "STRONGLY_SUPPORTED"
    else:
        status = "DIRECTIONAL"
    if cls in PERF and g(claim, "failure_row") is not True:
        status = _cap(status, "HYPOTHESIS")
    if g(claim, "contradiction") == "RESOLVED_AGAINST":
        status = _cap(status, "HYPOTHESIS")
    if cls == "FINANCIAL_EDGE":
        if g(claim, "regime") != "MULTI_REGIME":
            status = _cap(status, "DIRECTIONAL")
        if g(claim, "backtest_only") is True:
            status = _cap(status, "HYPOTHESIS")
    return status, n

def _cap(status, cap):
    return status if RANK.index(status) >= RANK.index(cap) else cap

def mandatory_set(components):
    s = []
    for c in components:
        for k in MANDATORY[c]:
            if k not in s:
                s.append(k)
    return s

def claim_table(rec, components):
    """Map class -> (status, origins) over the mandatory set; missing class -> UNKNOWN."""
    table = {}
    claims = rec.get("claims", [])
    for cls in mandatory_set(components):
        rows = [c for c in claims if c.get("class") == cls]
        if not rows:
            table[cls] = (UNK, 0); continue
        # a class with several rows (e.g. per platform) takes the weakest
        statuses = [claim_status(c) for c in rows]
        worst = min(statuses, key=lambda x: (0 if x[0] in UNRES else 1, -RANK.index(x[0]) if x[0] in RANK else 0))
        table[cls] = worst
    return table

def confidence_band(table):
    vals = [v[0] for v in table.values()]
    if any(v in UNRES for v in vals):
        return "UNRESOLVED"
    if all(v in ("VERIFIED_FACT", "STRONGLY_SUPPORTED") for v in vals):
        return "HIGH"
    if all(RANK.index(v) <= RANK.index("DIRECTIONAL") for v in vals):
        return "MODERATE"
    return "LOW"

# ---------- FWK-10 track ----------
def components(rec):
    sig = rec.get("signature", {}); comp = []
    deps = rec.get("dependencies", []) if isinstance(rec.get("dependencies"), list) else []
    cap_trigger = (g(rec, "capital_role") == "AT_RISK_CAPITAL"
                   or any(p in ("MARKET_COUNTERPARTY", "PROTOCOL") for p in sig.get("payer_types", []))
                   or sig.get("settlement_mechanism") in ("EXCHANGE_OR_BROKER", "ON_CHAIN")
                   or "CAPITAL" in sig.get("operator_supplies", [])
                   or (rng(rec.get("at_risk_capital")) and rec["at_risk_capital"][1] > 0)
                   or (rng(rec.get("refundable_stake")) and rec["refundable_stake"][1] > 0)
                   or any(d.get("type") == "CUSTODY_COUNTERPARTY" for d in deps))
    if cap_trigger: comp.append("T2")
    if rec.get("cash_source_is_reward") is True: comp.append("T3")
    base_day = usable_day(rec, "base")
    if rec.get("asset_build_first") is True or (isinstance(base_day, (int, float)) and base_day > 30): comp.append("T4")
    if any(p in ("CONSUMER", "BUSINESS") for p in sig.get("payer_types", [])): comp.append("T1")
    if "T4" in comp and "T1" in comp: comp.remove("T1")   # earned cash beyond the horizon is the asset component
    if not comp: comp.append("T1")
    return comp

def track_of(comp):
    return comp[0] if len(comp) == 1 else "T5"

# ---------- FWK-30 timing from stage rows ----------
def usable_day(rec, case):
    t = rec.get("timing")
    if not isinstance(t, dict) or not isinstance(t.get("stages"), list):
        return UNK
    total = 0; days_of = {}
    for st in t["stages"]:
        v = st.get(case)
        if v == UNK or v is None or not rng(v):
            return UNK
        if case == "best":
            d = v[0] if st.get("prov_best") in ("DOCUMENTED", "MEASURED", "STIPULATED") else v[1]
        else:
            d = v[1]
        if st.get("tag") == "EFFORT_DRIVEN":
            hrs = st.get("effort_hours"); wk = (rec.get("profile") or {}).get("hours")
            if rng(hrs) and isinstance(wk, (int, float)) and wk > 0 and d < hrs[1] / (wk / 7.0):
                return UNK
        days_of[st["id"]] = d
        if st.get("seq") == "PARALLEL" and st.get("overlaps") in days_of:
            total += max(0, d - days_of[st["overlaps"]])
        else:
            total += d
    return total

def stage_docs_ok(rec):
    t = rec.get("timing", {}); ids = {s.get("id") for s in t.get("stages", [])}
    return all(x in ids for x in ("S05", "S06", "S07", "S08", "S09", "S10", "S11a", "S11b"))

# ---------- gates ----------
def gate_g1(rec):
    g1 = rec.get("g1"); prof = rec.get("profile") or {}
    if not isinstance(g1, dict): return UNK, "FURTHER_RESEARCH_REQUIRED", False
    if prof.get("residence_supplied") is not True or prof.get("license_scope_supplied") is not True:
        return UNK, "OPERATOR_INPUT_REQUIRED", False
    classes = g1.get("activity_classes", []); rows = g1.get("reg_rows", [])
    material = False
    if any(c in ("A3", "A4", "A5", "A6") for c in classes) and not g1.get("professional_opinion_id"):
        material = True
    needed = {"OPERATOR_RESIDENCE", "COMPANY_JURISDICTION", "PLATFORM_JURISDICTION", "CUSTOMER_LOCATION"}
    seen = set(); unknown_sub = None; fail = False
    for r in rows:
        seen.add(r.get("role"))
        if r.get("fresh") is not True or r.get("legal_source_class") not in ("BINDING_LAW", "OFFICIAL_GUIDANCE"):
            unknown_sub = unknown_sub or "FURTHER_RESEARCH_REQUIRED"; continue
        f = r.get("finding"); ap = r.get("applicability"); basis = r.get("finding_basis")
        if f == "RESTRICTION_FOUND" and ap == "APPLIES": fail = True
        elif f == "LICENSE_REQUIRED" and ap == "APPLIES":
            hl = r.get("operator_holds_licence")
            if hl == "NO": fail = True
            elif hl != "YES": unknown_sub = unknown_sub or "OPERATOR_INPUT_REQUIRED"
        elif f == "UNRESOLVED":
            if ap in ("APPLIES", "UNCERTAIN"): material = True
            unknown_sub = unknown_sub or "FURTHER_RESEARCH_REQUIRED"
        elif f == "NO_RESTRICTION_FOUND":
            if basis == "RESEARCHER_READING": material = True; unknown_sub = unknown_sub or "PROFESSIONAL_LEGAL_REVIEW_REQUIRED"
            elif ap == "UNCERTAIN": material = True
    if fail: return "FAIL", None, material
    if material and g1.get("professional_opinion_id"): material = False
    if material: return UNK, "PROFESSIONAL_LEGAL_REVIEW_REQUIRED", True
    if needed - seen: return UNK, "FURTHER_RESEARCH_REQUIRED", False
    if unknown_sub: return UNK, unknown_sub, False
    return "PASS", None, False

def gate_g2(rec, elig_status):
    g2 = rec.get("g2"); prof = rec.get("profile") or {}
    if not isinstance(g2, dict): return UNK, "PLATFORM_CONFIRMATION_REQUIRED"
    acct = prof.get("account_type", "OPERATOR_INPUT_REQUIRED")
    types = ["PERSONAL", "COMPANY"] if acct in ("BOTH", "OPERATOR_INPUT_REQUIRED") else [acct]
    def val(t):
        sub = g2.get(t)
        if not isinstance(sub, dict): return UNK
        vs = [sub.get(k, UNK) for k in ("signup", "monetize", "withdraw", "kyc_docs", "tax_form")]
        if "FAIL" in vs: return "FAIL"
        if UNK in vs: return UNK
        return "PASS"
    vals = {t: val(t) for t in types}
    if elig_status in UNRES: return UNK, "PLATFORM_CONFIRMATION_REQUIRED"
    if all(v == "FAIL" for v in vals.values()): return "FAIL", None
    if acct == "OPERATOR_INPUT_REQUIRED" and len(set(vals.values())) > 1: return UNK, "OPERATOR_INPUT_REQUIRED"
    if acct == "OPERATOR_INPUT_REQUIRED" and all(v == "PASS" for v in vals.values()): return "PASS", None
    if all(v == "PASS" for v in vals.values()): return "PASS", None
    if any(v == UNK for v in vals.values()): return UNK, "PLATFORM_CONFIRMATION_REQUIRED"
    return "PASS", None   # BOTH with one PASS and one FAIL: usable type exists

def gate_g3(rec, g2_val, payout_status):
    t = rec.get("timing")
    if not isinstance(t, dict): return UNK
    if payout_status in UNRES or not stage_docs_ok(rec): return UNK
    if g2_val == "FAIL": return "FAIL"
    thr = t.get("threshold", {})
    best = usable_day(rec, "best"); base = usable_day(rec, "base"); cons = usable_day(rec, "conservative")
    if thr.get("best") == "NO" and thr.get("base") == "NO" and thr.get("conservative") == "NO": return "FAIL"
    if isinstance(best, (int, float)) and best > 30: return "FAIL"
    if any(x == UNK for x in (best, base, cons)): return UNK
    if not (best <= base <= cons): return UNK
    if thr.get("best") != "YES" or g2_val == UNK: return UNK
    return "PASS"

def gate_g5(rec):
    sm = g(rec, "sales_mode")
    deps = rec.get("dependencies")
    if sm in ("QUOTE_OR_PROPOSAL", "NEGOTIATED"): return "FAIL"
    if isinstance(deps, list):
        for d in deps:
            if d.get("type") == "HUMAN_NAMED": return "FAIL"
            if d.get("blocks_cash") and d.get("interaction_mode") in ("INDIVIDUALIZED_NEGOTIATION", "SPONSORED_BY_NAMED_PERSON"): return "FAIL"
    if sm == UNK or not isinstance(deps, list) or rec.get("dependency_map_attested_by") in (None, "NONE", "DISCOVERER"): return UNK
    return "PASS"

def gate_g6(rec, table):
    st = table.get("PLATFORM_POLICY_COMPLIANCE", (UNK, 0))[0]
    findings = [c.get("policy_finding") for c in rec.get("claims", []) if c.get("class") == "PLATFORM_POLICY_COMPLIANCE"]
    if "PROHIBITED" in findings: return "FAIL"
    if st in UNRES: return UNK
    return "PASS"

# ---------- cash ----------
def ncc_case(e):
    if not isinstance(e, dict) or e.get("unknown"): return None
    keys_hi = ["reserve_withheld", "refunds_realized", "platform_fees", "processing_fees", "dispute_fees", "withholding", "direct_costs", "fx_costs"]
    for k in ["receipts_gross"] + keys_hi:
        if not rng(e.get(k)): return None
    rr = e.get("refund_rate")
    if not rng(rr): return None
    net_refundable = [max(0, e["receipts_gross"][0] - e["refunds_realized"][1]), max(0, e["receipts_gross"][1] - e["refunds_realized"][0])]
    prov = [net_refundable[0] * rr[0], net_refundable[1] * rr[1]]
    rp = e.get("recovered_principal", [0, 0])
    lo = e["receipts_gross"][0] - sum(e[k][1] for k in keys_hi) - prov[1] - rp[1]
    hi = e["receipts_gross"][1] - sum(e[k][0] for k in keys_hi) - prov[0] - rp[0]
    return [round(lo), round(hi)]

def build_cases(rec, comp, edge_status):
    """Per case economic rows; capital component built per CAP-14 and FWK-32."""
    out = {}
    econ = rec.get("economics", {}); cases = econ.get("cases", {}) if isinstance(econ, dict) else {}
    for case in ("conservative", "base", "best"):
        e = copy.deepcopy(cases.get(case)) if isinstance(cases.get(case), dict) else None
        if e is None: out[case] = None; continue
        if "T2" in comp:
            cd = rec.get("capital_deployed"); mpl = rec.get("max_plausible_loss"); cap = rec.get("cap") or {}
            if not rng(cd) or not rng(mpl): out[case] = None; continue
            if case == "conservative":
                ret = [-mpl[1], -mpl[0]]
            else:
                ok = edge_status in ("VERIFIED_FACT", "STRONGLY_SUPPORTED") and cap.get("regime") == "MULTI_REGIME"
                pr = cap.get("period_return_base_net" if case == "base" else "period_return_best_net")
                if not ok or not rng(pr): out[case] = None; continue
                ret = pr
            e["receipts_gross"] = [max(0, cd[0] + ret[0]), max(0, cd[1] + ret[1])]
            e["recovered_principal"] = [min(e["receipts_gross"][0], cd[0]), min(e["receipts_gross"][1], cd[1])]
            e["refund_rate"] = [0, 0]
        else:
            e["recovered_principal"] = [0, 0]
            if rec.get("signature", {}).get("settlement_mechanism") in ("EXCHANGE_OR_BROKER", "ON_CHAIN"):
                e["refund_rate"] = [0, 0]
        e["ncc"] = ncc_case(e)
        out[case] = e
    return out

def cash_band(rec, cases):
    sup = {}
    for c in ("conservative", "base", "best"):
        e = cases.get(c); day = usable_day(rec, c)
        sup[c] = None if (e is None or e.get("ncc") is None or day == UNK) else (day <= 30 and e["ncc"][0] > 0)
    if any(v is None for v in sup.values()): return "CASH_U", sup
    if sup["conservative"]: return "CASH_A", sup
    if sup["base"]: return "CASH_B", sup
    if sup["best"]: return "CASH_C", sup
    return "CASH_D", sup

def horizon(rec):
    d = usable_day(rec, "base")
    if d == UNK: return "H_OPEN"
    return "H30" if d <= 30 else "H90" if d <= 90 else "H365" if d <= 365 else "H_OPEN"

def risk_class(rec):
    prof = rec.get("profile") or {}; mpl = rec.get("max_plausible_loss"); cap = rec.get("cap") or {}
    if not rng(mpl) or not isinstance(prof.get("loss"), (int, float)) or not isinstance(prof.get("capital"), (int, float)): return "R0"
    if "T2" in components(rec) and cap.get("counterparty_status") in (None, UNK, "UNVERIFIABLE"): return "R0"
    ct = capital_total(rec)
    if ct is None: return "R0"
    ratios = [mpl[1] / prof["loss"], ct[1] / prof["capital"]]
    if any(r > 1.0 for r in ratios): return "R3"
    if any(r >= 0.8 for r in ratios): return "R2"
    return "R1"

def capital_total(rec):
    parts = [rec.get("setup_capital"), rec.get("working_capital"), rec.get("at_risk_capital")]
    if not all(rng(p) for p in parts): return None
    return [sum(p[0] for p in parts), sum(p[1] for p in parts)]

def feasibility(rec):
    prof = rec.get("profile") or {}; wk = prof.get("hours")
    rh = rec.get("recurring_hours"); sh = rec.get("support_hours")
    gap = g(rec, "skill_gap")
    if gap == "BLOCKING" and rec.get("skill_substitute_documented") is not True: return "REJECT"
    if not isinstance(wk, (int, float)) or not rng(rh) or not rng(sh) or gap == UNK: return UNK
    return "WITHIN" if rh[1] + sh[1] <= wk else "BEYOND"

# ---------- SYS-07 evaluation ----------
def evaluate(rec):
    out = {"gates": {}, "conditional": {}, "bands_assigned": False, "in_ordering": False, "in_income_ordering": False,
           "failed_gate": None, "subtype": None, "unknown_gate": None, "open_conditional": None, "cap_applied": False,
           "reason": None, "quarantine_reasons": []}
    comp = components(rec); out["component_tracks"] = comp; out["track"] = track_of(comp)   # step 2
    gt = out["gates"]
    g1, g1sub, material = gate_g1(rec); gt["G1"] = g1; gt["G7"] = g(rec, "g7")                 # step 3
    if g1 == "FAIL": out.update(state="PROHIBITED", failed_gate="G1"); return out
    if gt["G7"] == "FAIL": out.update(state="PROHIBITED", failed_gate="G7"); return out
    table = claim_table(rec, comp)
    gt["G2"], g2sub = gate_g2(rec, table.get("PLATFORM_ELIGIBILITY", (UNK, 0))[0])           # step 4
    if gt["G2"] == "FAIL": out.update(state="REJECTED", failed_gate="G2"); return out
    gt["G4"] = g(rec, "g4") if table.get("DEPENDENCY_AVAILABILITY", (UNK, 0))[0] not in UNRES else UNK
    gt["G5"] = gate_g5(rec); gt["G6"] = gate_g6(rec, table)                                    # step 5
    for k in ("G4", "G5", "G6"):
        if gt[k] == "FAIL": out.update(state="REJECTED", failed_gate=k); return out
    gt["G3"] = gate_g3(rec, gt["G2"], table.get("PAYOUT_PATH", (UNK, 0))[0])                   # step 6
    if gt["G3"] == "FAIL": out.update(state="REJECTED", failed_gate="G3"); return out
    c = out["conditional"]; cs = rec.get("cold_start") or {}                                  # step 7
    c["C1a"] = "CLOSED" if (cs.get("channel_entry_type") in ("OPEN_MARKETPLACE_SEARCH", "PAID_ADS", "ALGORITHMIC_FEED", "STANDARDIZED_APPLICATION") and cs.get("channel_source_admissible") is True) else "OPEN"
    dist = table.get("DISTRIBUTION_PERFORMANCE", (UNK, 0))[0]
    c["C1b"] = "CLOSED" if ((dist in RANK and RANK.index(dist) <= RANK.index("DIRECTIONAL")) or cs.get("experiment_measured_positive") is True or "T2" in comp and "T1" not in comp and "T3" not in comp) else "OPEN"
    deps = rec.get("dependencies") if isinstance(rec.get("dependencies"), list) else None      # step 8
    c["C2"] = "CLOSED" if (deps is not None and rec.get("dependency_map_attested_by") not in (None, "NONE", "DISCOVERER") and not any(d.get("blocks_cash") and d.get("availability") != "AVAILABLE" for d in deps)) else "OPEN"
    feas = feasibility(rec)
    if feas == "REJECT": out.update(state="REJECTED", failed_gate="FEASIBILITY"); return out
    quarantine = []                                                                             # step 9
    if material: quarantine.append(("G1", "PROFESSIONAL_LEGAL_REVIEW_REQUIRED"))
    elif g1 == UNK: quarantine.append(("G1", g1sub))
    if gt["G2"] == UNK: quarantine.append(("G2", g2sub))
    for k, sub in (("G3", "PLATFORM_CONFIRMATION_REQUIRED"), ("G4", "FURTHER_RESEARCH_REQUIRED"), ("G5", "FURTHER_RESEARCH_REQUIRED"), ("G6", "PLATFORM_CONFIRMATION_REQUIRED"), ("G7", "FURTHER_RESEARCH_REQUIRED")):
        if gt[k] == UNK: quarantine.append((k, sub))
    for cls, (st, n) in table.items():                                                          # step 10
        if st in UNRES:
            quarantine.append(("CLAIM_" + cls, "EVIDENCE_UNAVAILABLE" if cls == "FINANCIAL_EDGE" else "FURTHER_RESEARCH_REQUIRED"))
    out["claim_table"] = {k: v[0] for k, v in table.items()}
    c["C7"] = "CLOSED" if all(v[0] != "OUTDATED" for v in table.values()) else "OPEN"
    c["C8"] = "CLOSED" if rec.get("contradiction_rows_complete") is True else "OPEN"
    c["C9"] = "CLOSED" if feas in ("WITHIN", "BEYOND") else "OPEN"
    edge_status = table.get("FINANCIAL_EDGE", (UNK, 0))[0] if "T2" in comp else None
    if "T2" in comp:                                                                            # step 12 (CAP)
        out["cap_applied"] = True; cap = rec.get("cap") or {}
        out["expected_return"] = cap.get("expected_return") if edge_status in ("VERIFIED_FACT", "STRONGLY_SUPPORTED") and rng(cap.get("expected_return")) else UNK
        if not rng(rec.get("max_plausible_loss")): quarantine.append(("CAP_MAX_PLAUSIBLE_LOSS", "EVIDENCE_UNAVAILABLE"))
        if cap.get("counterparty_status") in (None, UNK, "UNVERIFIABLE"): quarantine.append(("CAP_COUNTERPARTY", "PLATFORM_CONFIRMATION_REQUIRED"))
        c["C5"] = "CLOSED" if all(cap.get(k) not in (None, UNK) for k in ("drawdown", "liquidity", "leverage", "custody", "regime", "repeatability")) else "OPEN"
        if cap.get("track_gate_fail") is True: out.update(state="REJECTED", failed_gate="C5_TRACK_GATE"); return out
    else:
        c["C5"] = "CLOSED"
    if quarantine:
        legal = [q for q in quarantine if q[1] == "PROFESSIONAL_LEGAL_REVIEW_REQUIRED"]
        gate, sub = legal[0] if legal else quarantine[0]
        out.update(state="QUARANTINED", subtype=sub, unknown_gate=gate, quarantine_reasons=[q[0] for q in quarantine]); return out
    cases = build_cases(rec, comp, edge_status)                                                 # step 11
    out["ncc"] = {k: (v["ncc"] if v else None) for k, v in cases.items()}
    out["recovered_principal"] = cases["conservative"]["recovered_principal"] if cases["conservative"] else None
    out["cash_band"], out["supports"] = cash_band(rec, cases)
    out["confidence"] = confidence_band(table)
    out["risk_class"] = risk_class(rec); out["feasibility"] = feas; out["horizon_class"] = horizon(rec)
    out["usable_day"] = {k: usable_day(rec, k) for k in ("conservative", "base", "best")}
    out["tax_status"] = "RESOLVED" if (rec.get("tax_status") == "RESOLVED" and rec.get("tax_opinion_id")) else "PROFESSIONAL_TAX_REVIEW_REQUIRED"
    c["C3"] = "CLOSED" if all(v is not None for v in out["ncc"].values()) else "OPEN"
    c["C4"] = "CLOSED" if all(v != UNK for v in out["usable_day"].values()) else "OPEN"
    out["bands_assigned"] = True
    required = [k for k in c if k != "C6"]
    open_c = [k for k in required if c[k] == "OPEN"]                                          # step 13
    if open_c:
        out.update(state="CONDITIONAL", open_conditional=sorted(open_c)[0]); return out
    out["state"] = "ELIGIBLE"
    if out["confidence"] == "LOW": out["reason"] = "insufficient-evidence"
    elif out["cash_band"] == "CASH_D": out["reason"] = "no-30-day-cash"
    elif out["cash_band"] == "CASH_U": out["reason"] = "unresolved"
    elif out["risk_class"] == "R0": out["reason"] = "unassessed-risk"
    elif "T2" in comp and (edge_status not in ("VERIFIED_FACT", "STRONGLY_SUPPORTED") or not (rec.get("g1") or {}).get("professional_opinion_id")): out["reason"] = "t2-edge-or-opinion"
    out["in_ordering"] = out["reason"] is None
    out["in_income_ordering"] = out["in_ordering"] and "T2" not in comp and "T4" not in comp
    return out

# ---------- FWK-20 dedup ----------
SIG_KEYS = ("value_delivered_class", "payer_types", "operator_supplies", "payment_rail", "settlement_mechanism", "platform_dependency_class")
VAR_KEYS = ("platform_id", "geography", "pricing_model", "format")
def signature(rec):
    s = rec.get("signature", {})
    return tuple(tuple(sorted(s.get(k, []))) if isinstance(s.get(k), list) else s.get(k) for k in SIG_KEYS)
def variant(rec):
    v = rec.get("variant", {}); return tuple(v.get(k) for k in VAR_KEYS)
def dedup(items):
    """items: list of (id, rec). Returns mec map id->mec_index, merged map id->survivor, mec count."""
    mecs, opps, merged, mec_of = [], {}, {}, {}
    for fid, rec in items:
        sig = signature(rec)
        if sig not in mecs: mecs.append(sig)
        mec_of[fid] = mecs.index(sig)
        key = (sig, variant(rec))
        if key in opps: merged[fid] = opps[key]
        else: opps[key] = fid
    return mec_of, merged, len(mecs)

# ---------- ordering ----------
def r2(x):
    if x == 0: return 0
    return round(x, -int(math.floor(math.log10(abs(x)))) + 1)
def dims(rec, out):
    ct = capital_total(rec)
    return {"ncc": [r2(v) for v in out["ncc"]["conservative"]], "s11": [out["usable_day"]["conservative"]] * 2,
            "hours": [r2(rec["recurring_hours"][0] + rec["support_hours"][0]), r2(rec["recurring_hours"][1] + rec["support_hours"][1])],
            "capital": [r2(v) for v in ct], "loss": [r2(v) for v in rec["max_plausible_loss"]]}
HIGHER = {"ncc"}
def at_least(a, b, d): return (a[0] >= b[0] and a[1] >= b[1]) if d in HIGHER else (a[0] <= b[0] and a[1] <= b[1])
def strictly(a, b, d): return a[0] > b[1] if d in HIGHER else a[1] < b[0]
def dominates(da, db): return all(at_least(da[d], db[d], d) for d in da) and any(strictly(da[d], db[d], d) for d in da)
def order(items):
    D = {i: dims(r, o) for i, r, o in items}
    dominated = {i: sorted(j for j in D if j != i and dominates(D[j], D[i])) for i in D}
    dominated = {i: v for i, v in dominated.items() if v}
    front = [i for i in D if i not in dominated]
    decided = {}; ties = []
    for a in front:
        for b in front:
            if a >= b: continue
            level = None
            for lv in ("ncc", "s11", "loss", "hours"):
                if strictly(D[a][lv], D[b][lv], lv) or strictly(D[b][lv], D[a][lv], lv):
                    level = "FWK-42:" + lv; break
            if level is None:
                pa = items_by(items, a)[0].get("platform_concentration"); pb = items_by(items, b)[0].get("platform_concentration")
                ea = (items_by(items, a)[0].get("experiment") or {}).get("max_spend"); eb = (items_by(items, b)[0].get("experiment") or {}).get("max_spend")
                if isinstance(ea, (int, float)) and isinstance(eb, (int, float)) and ea != eb: level = "FWK-43:experiment"
                elif isinstance(pa, int) and isinstance(pb, int) and pa != pb: level = "FWK-43:concentration"
            if level is None: ties.append((a, b))
            else: decided[(a, b)] = level
    return front, dominated, ties, decided
def items_by(items, i):
    return next((r, o) for j, r, o in items if j == i)

# ---------- FWK-50 portfolio ----------
def weekly_profile(rec):
    wk = [0.0] * 6
    d = {c: usable_day(rec, "conservative") for c in ["x"]}
    stages = {s["id"]: s for s in rec.get("timing", {}).get("stages", [])}
    def day_of(sid):
        tot = 0
        for s in rec["timing"]["stages"]:
            v = s["conservative"][1] if rng(s.get("conservative")) else 0
            tot += v
            if s["id"] == sid: return tot
        return tot
    setup_end = day_of("S03"); s3 = day_of("S03"); s4 = day_of("S04"); s11 = day_of("S11b")
    setup = rec["setup_hours"][1]; rec_h = rec["recurring_hours"][1]; sup = rec["support_hours"][1]
    for w in range(6):
        ws, we = w * 7, w * 7 + 7
        ov = max(0, min(we, setup_end) - ws)
        if setup_end > 0: wk[w] += setup * (ov / setup_end)
        if we > s3 and ws < s11: wk[w] += rec_h
        if we > s4 and ws < s11: wk[w] += sup
    return wk
def portfolio(members, limits, deps_by_member):
    prof = [weekly_profile(m) for m in members]
    peak_hours = max(sum(p[w] for p in prof) for w in range(6))
    cap = sum(capital_total(m)[1] for m in members)
    loss = sum(m["max_plausible_loss"][1] for m in members)
    providers = {}
    for i, deps in enumerate(deps_by_member):
        for d in deps: providers.setdefault(d.get("provider_id"), []).append((i, d))
    shared = {p: v for p, v in providers.items() if len({i for i, _ in v}) > 1}
    shared_exceeded = "NO"; corr_unknown = False
    for p, rows in shared.items():
        for i, d in rows:
            if d.get("type") == "ACCOUNT_LIMIT":
                lim = d.get("documented_limit")
                if not rng(lim): shared_exceeded = UNK
                elif len(rows) > lim[1] and shared_exceeded != UNK: shared_exceeded = "YES"
            if d.get("blocks_cash") and d.get("availability") == UNK: corr_unknown = True
    bp = {"peak_week_hours": round(peak_hours, 1), "capital": cap, "loss": loss, "shared_providers": sorted(k for k in shared if k)}
    if shared_exceeded == UNK or corr_unknown: return "BLOCKED_UNKNOWN", bp
    if not limits: return "CONDITIONAL", bp
    if peak_hours > limits["hours"] or cap > limits["capital"] or loss > limits["loss"] or shared_exceeded == "YES": return "INFEASIBLE", bp
    return "FEASIBLE", bp

# ---------- harness ----------
def check(expected, out):
    fails = []
    for k, v in expected.items():
        if k == "identical_to": continue
        if k == "ncc_conservative_low_at_or_below_zero": ok = out.get("ncc", {}).get("conservative") is not None and out["ncc"]["conservative"][0] <= 0
        elif k == "base_supports": ok = out.get("supports", {}).get("base") == v
        elif k == "best_supports": ok = out.get("supports", {}).get("best") == v
        elif k == "quarantine_includes": ok = v in out.get("quarantine_reasons", [])
        elif k == "usable_day_conservative": ok = out.get("usable_day", {}).get("conservative") == v
        else: ok = out.get(k) == v
        if not ok: fails.append(f"{k}: expected {v!r}, observed {out.get(k)!r}")
    return fails

def main():
    label = sys.argv[sys.argv.index("--label") + 1] if "--label" in sys.argv else "unlabelled"
    blind = "--blind" in sys.argv
    fx = json.load(open(os.path.join(HERE, "fixtures.json")))
    base = fx["base_record"]; rows = []; outputs = {}; results = {}
    gate_seen = {f"G{i}": set() for i in range(1, 8)}; all_ok = True

    def run(fid, rec, expected, note=""):
        nonlocal all_ok
        out = evaluate(rec); outputs[fid] = (rec, out)
        for k, v in out["gates"].items(): gate_seen[k].add(v)
        fails = [] if blind else check(expected, out); all_ok &= not fails
        detail = out.get("subtype") or out.get("failed_gate") or out.get("open_conditional") or out.get("reason") or ""
        rows.append((fid, note, out.get("state"), out.get("track"), out.get("cash_band") if out["bands_assigned"] else "", out.get("confidence") if out["bands_assigned"] else "", detail, "PASS" if not fails else "FAIL: " + "; ".join(fails)))
        return out

    # dedup pass over the whole fixture set BEFORE any evaluate() (FWK-20, T-13)
    recs = [(f["id"], apply_patch(base, f["patch"])) for f in fx["records"]]
    mec_of, merged, mec_count = dedup(recs)
    results["T-13"] = mec_count == fx["dedup_expected"]["mec_count"] and merged == fx["dedup_expected"]["merged"]
    rows.append(("DEDUP", "FWK-20 over all fixture records before evaluation", f"mecs={mec_count}", f"merged={merged}", "", "", "", "PASS" if results["T-13"] else "FAIL"))
    for f in fx["records"]:
        fid = f["id"]; rec = dict(r for i, r in recs if i == fid) if False else next(r for i, r in recs if i == fid)
        if fid in merged:
            out = {"state": "MERGED", "dedup": "MERGED", "merged_into": merged[fid], "gates": {}, "bands_assigned": False}
            outputs[fid] = (rec, out); fails = [] if blind else check(f["expected"], out); all_ok &= not fails
            rows.append((fid, f["label"], "MERGED", "", "", "", f"into {merged[fid]}", "PASS" if not fails else "FAIL: " + "; ".join(fails))); continue
        out = run(fid, rec, f["expected"], f["label"])
        for ph in f.get("phases", []):
            rec = apply_patch(rec, ph["patch"]); out = run(fid, rec, ph["expected"], ph["label"])
    for f in fx["gate_matrix"]:
        run(f["id"], apply_patch(base, f["patch"]), f["expected"], "gate matrix variant")

    o = lambda i: outputs[i][1]
    results["T-24"] = o("FIX-013a") == o("FIX-013b")
    results["T-11"] = o("FIX-014")["track"] == "T2" and o("FIX-014")["cap_applied"] and o("FIX-015")["track"] == "T2"
    results["T-14"] = o("FIX-001")["cap_applied"] is False and o("FIX-005")["cap_applied"] is True
    results["T-16"] = o("FIX-005b")["ncc"]["conservative"][0] <= 0 and o("FIX-005b")["recovered_principal"][1] <= base["capital_deployed"][1] and o("FIX-005b")["ncc"]["base"] is not None and o("FIX-005b")["ncc"]["base"][0] < 1000
    results["T-17"] = o("FIX-009")["supports"]["base"] is False and o("FIX-009")["usable_day"]["base"] > 30 and o("FIX-016")["usable_day"]["conservative"] == fx["records_meta"]["FIX-016_expected_day"]
    results["T-34"] = o("FIX-009")["cash_band"] == "CASH_C"
    results["T-35"] = o("FIX-010")["state"] == "REJECTED" and o("FIX-010")["failed_gate"] == "G2"
    results["T-36"] = o("FIX-005")["state"] == "QUARANTINED" and "CLAIM_FINANCIAL_EDGE" in o("FIX-005")["quarantine_reasons"] and o("FIX-005")["expected_return"] == UNK and not o("FIX-005")["bands_assigned"]
    alt = evaluate(apply_patch(outputs["FIX-011"][0], {"scalability_note": ""}))
    results["T-33"] = o("FIX-011")["cash_band"] == "CASH_D" and not o("FIX-011")["in_ordering"] and alt == o("FIX-011")
    results["T-29"] = o("FIX-006b")["subtype"] == "PROFESSIONAL_LEGAL_REVIEW_REQUIRED" and o("FIX-014")["subtype"] == "PROFESSIONAL_LEGAL_REVIEW_REQUIRED"
    results["T-30"] = o("FIX-006")["state"] == "PROHIBITED" and not o("FIX-006")["bands_assigned"]
    results["T-20"] = o("FIX-003")["state"] == "QUARANTINED" and not o("FIX-003")["bands_assigned"]
    ph = [r for r in rows if r[0] == "FIX-007"]
    results["T-19"] = ph[2][2] == "QUARANTINED"
    results["T-21"] = ph[0][2] == "QUARANTINED" and ph[1][2] == "ELIGIBLE" and ph[3][2] == "QUARANTINED"
    r1, o1 = outputs["FIX-001"]
    worse = evaluate(apply_patch(r1, {"timing.stages.S06.conservative": [20, 22]}))
    costlier = evaluate(apply_patch(r1, {"economics.cases.conservative.direct_costs": [300, 400]}))
    results["T-26"] = CASH_ORDER.index(worse["cash_band"]) >= CASH_ORDER.index(o1["cash_band"]) and costlier["ncc"]["conservative"][0] < o1["ncc"]["conservative"][0] and CASH_ORDER.index(costlier["cash_band"]) >= CASH_ORDER.index(o1["cash_band"])
    results["T-12"] = all(gate_seen[k] >= {"PASS", "FAIL", "UNKNOWN"} for k in gate_seen)
    results["T-42"] = o("FIX-018")["state"] == "QUARANTINED" and o("FIX-019")["state"] == "QUARANTINED" and "CLAIM_DEMAND" in o("FIX-019")["quarantine_reasons"]
    results["T-43"] = o("FIX-020")["failed_gate"] == "G5" and o("FIX-021")["unknown_gate"] == "G5"
    results["T-44"] = o("FIX-017")["subtype"] == "OPERATOR_INPUT_REQUIRED" and o("FIX-017b")["state"] == "ELIGIBLE"
    results["T-45"] = o("FIX-022")["unknown_gate"] == "G6"
    results["T-46"] = o("FIX-024")["state"] == "ELIGIBLE" and o("FIX-024")["confidence"] == "LOW" and not o("FIX-024")["in_ordering"]
    results["T-47"] = o("FIX-025")["cash_band"] == "CASH_U" and o("FIX-026")["tax_status"] == "PROFESSIONAL_TAX_REVIEW_REQUIRED"
    results["T-48"] = o("FIX-027")["track"] == "T5" and o("FIX-027")["in_income_ordering"] is True and o("FIX-028")["track"] == "T5" and o("FIX-028")["cap_applied"]
    results["T-49"] = o("FIX-029")["failed_gate"] == "G3" and o("FIX-030")["subtype"] == "OPERATOR_INPUT_REQUIRED" and o("FIX-030b")["state"] != "PROHIBITED"
    results["T-27"] = o("FIX-001-R0")["reason"] == "unassessed-risk" and not o("FIX-001-R0")["in_ordering"]
    results["T-53"] = o("FIX-001")["state"] == "ELIGIBLE" and o("FIX-001")["in_ordering"]
    # claim tests
    ct = {}
    for t in fx["claim_tests"]:
        cl = {"class": t["class"], "sources": list(t["before"]), "denominator_known": True, "failure_row": True, "contradiction": "NONE"}
        cl.update(t.get("claim_extra", {}))
        before, nb = claim_status(cl)
        if "add_repeated" in t: cl["sources"] += [t["add_repeated"]["source"]] * t["add_repeated"]["count"]
        else: cl["sources"] += t.get("add", [])
        cl.update(t.get("after_extra", {}))
        after, na = claim_status(cl)
        ok = True
        if "expected_before" in t: ok &= before == t["expected_before"]
        if "expected_after" in t: ok &= after == t["expected_after"]
        if "expected_origins" in t: ok &= nb == t["expected_origins"]
        ct[t["id"]] = ok
        rows.append((t["id"], t["label"], before, after, "", "", f"origins={nb}", "PASS" if ok else "FAIL"))
    results["T-23"], results["T-25"], results["T-28"] = ct["CT-01"], ct["CT-02"], ct["CT-03"]
    results["T-50"] = all(ct[k] for k in ("CT-04", "CT-05", "CT-06", "CT-07", "CT-08", "CT-09"))
    # ordering tests
    for t in fx["ordering_tests"]:
        items = []
        for r in t["records"]:
            rec = apply_patch(base, r["patch"]); out = evaluate(rec); items.append((r["id"], rec, out))
        front, dominated, ties, decided = order(items)
        exp = t["expected"]; ok = all(o["in_ordering"] for _, _, o in items)
        if "front" in exp: ok &= front == exp["front"]
        if "dominated" in exp: ok &= dominated == exp["dominated"]
        if "tie" in exp: ok &= (exp["tie"][0], exp["tie"][1]) in ties
        if "decided" in exp: ok &= decided.get(tuple(exp["decided"]["pair"])) == exp["decided"]["level"]
        results[t["test"]] = ok
        rows.append((t["id"], t["label"], f"front={front}", f"dominated={dominated}", f"ties={ties}", f"decided={decided}", "", "PASS" if ok else "FAIL"))
    # portfolio tests
    pf = {}
    for t in fx["portfolio"]:
        members = [apply_patch(base, t["member_patch"]) for _ in t["members"]]
        deps = [m.get("dependencies", []) for m in members]
        if t.get("shared_dependency"):
            for d in deps: d.append(t["shared_dependency"])
        indiv = {risk_class(m) for m in members}
        res, bp = portfolio(members, t["limits"], deps)
        ok = res == t["expected"]["result"]
        if "members_individually" in t["expected"]: ok &= indiv == {t["expected"]["members_individually"]}
        if "peak_exceeds_sum_of_recurring" in t["expected"]: ok &= bp["peak_week_hours"] > sum(m["recurring_hours"][1] for m in members)
        pf[t["id"]] = ok
        rows.append((t["id"], t["label"], res, f"individually={sorted(indiv)}", f"breakpoints={bp}", "", "", "PASS" if ok else "FAIL"))
    results["T-18"] = all(pf.values())
    results["FIXTURES"] = all_ok
    print(f"## Fixture run: {label}{' (blind)' if blind else ''}\n")
    print("Controlled hypothetical architecture fixtures. Stipulated facts test framework logic only; never evidence, benchmarks, or ranking inputs.\n")
    print("| Fixture | Note | State | Track | Cash band | Confidence | Detail | Result |\n|---|---|---|---|---|---|---|---|")
    for r in rows: print("| " + " | ".join(str(x) for x in r) + " |")
    print("\n| Test | Result |\n|---|---|")
    for k in sorted(results): print(f"| {k} | {'PASS' if results[k] else 'FAIL'} |")
    print("\nGate coverage: " + ", ".join(f"{k}={sorted(v)}" for k, v in gate_seen.items()))
    json.dump({"label": label, "results": results}, open(os.path.join(HERE, f"results-{label}.json"), "w"), indent=1)
    sys.exit(0 if all(results.values()) else 1)

if __name__ == "__main__":
    main()
