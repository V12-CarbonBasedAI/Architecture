# Controlled hypothetical architecture fixtures

> Controlled hypothetical architecture fixture set. Stipulated facts test framework logic only. They are not empirical evidence, commercial benchmarks, profitability validation, or inputs to later opportunity rankings. Every value carries `provenance_class: STIPULATED`. Fixture identifiers never leave `tests/` (SYS-16, STR-14).

Machine-readable definitions and preregistered expected outcomes are in `fixtures.json`. `run_fixtures.py` evaluates them with the Framework rules and compares observed to expected. All fixtures derive from one abstract base record (a standardized digital item sold to unknown consumers through a single platform payout, with a supplied operator profile) by patching structured fields; the base record has no real-world referent, and variant platform identifiers are labels only. Expected outcomes were written before each run; changes since V0.1 are listed at the end with their justification (SYS-12).

## The fourteen mandated fixtures

| Fixture | Mandated case | Stipulated change from base | Preregistered outcome | Tests |
|---|---|---|---|---|
| FIX-001 | Candidate that should pass | None | T1, ELIGIBLE, CASH_A, HIGH, R1, WITHIN, in ordering | T-53, T-26 |
| FIX-002 | Candidate that should fail | Payout threshold unattainable in every case | REJECTED at G3, no bands | T-12 |
| FIX-003 | Candidate requiring quarantine | Withdrawal availability undocumented | QUARANTINED, PLATFORM_CONFIRMATION_REQUIRED, no bands | T-20 |
| FIX-004 | Longer-horizon candidate | Best-case first sale beyond Day 30 | T4, REJECTED at G3, horizon recorded | T-12 |
| FIX-005 | Capital-risk candidate without verified edge | At-risk capital, professional opinion stipulated as logged, edge evidence a practitioner source | T2, CAP applied, QUARANTINED (EVIDENCE_UNAVAILABLE), expected return UNKNOWN, no bands | T-36 |
| FIX-006 | Legally prohibited candidate | Stipulated applicable restriction | PROHIBITED at G1, no bands | T-30 |
| FIX-007 | Status changes after new evidence | Monetization undocumented; confirmed; source expires; demand contradiction | QUARANTINED, ELIGIBLE, QUARANTINED, QUARANTINED | T-19, T-21 |
| FIX-008a, FIX-008b, FIX-008c | Duplicates sharing one mechanism | Identical signature and variant; same signature, different platform variant | 008b MERGED into 008a; 008c a separate OPP; one MEC | T-13 |
| FIX-009 | Day-25 sale with 14-day payout | Base-case sale on day 25 and usable cash on day 39; best-case sale on day 14 | ELIGIBLE, CASH_C labelled best case only | T-17, T-34 |
| FIX-010 | Platform viewable but not monetizable in the UAE | Monetization unavailable on every account type | REJECTED at G2 | T-35 |
| FIX-011 | Highly scalable asset with no Day-30 cash path | Base-case sale after Day 30, receipts below costs in every case, large scalability note | T4, ELIGIBLE on gates, CASH_D, listed as no-30-day-cash, output unchanged without the note | T-33 |
| FIX-012, FIX-012b, FIX-012c, FIX-023 | Individually feasible candidates infeasible together | Three R1 members; limits missing; unknown shared account limit; week-1 setup peak | INFEASIBLE; CONDITIONAL; BLOCKED_UNKNOWN; INFEASIBLE on peak | T-18 |
| FIX-013a, FIX-013b | False-rejection and wording pair | Plain single-source demand evidence; persuasive wording | Both ELIGIBLE, MODERATE, CASH_A, identical outputs | T-24 |
| FIX-014 | Label evasion | Described as risk-free arbitrage yield, capital_role typed NONE, on-chain protocol signature, no professional opinion | T2 by triggers, CAP applied, QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED | T-11, T-29 |

## Additional fixtures added in V1.0 from review findings

| Fixture | Finding | Preregistered outcome | Tests |
|---|---|---|---|
| FIX-005b | RT-C2, RT-C4 | Strong stipulated edge: T2, ELIGIBLE, CASH_C, conservative case a loss, principal excluded from net cash, in T2 ordering only | T-16 |
| FIX-006b | RT-P16, RT-P17 | Researcher reading on an uncertain customer-jurisdiction row: PROFESSIONAL_LEGAL_REVIEW_REQUIRED | T-29 |
| FIX-015 | RT-C1 | Signature triggers with every typed flag favorable: T2 | T-11 |
| FIX-016 | RT-P22 | Stage rows with a PARALLEL stage: conservative usable day 27 | T-17 |
| FIX-017, FIX-017b | RT-P11, RT-R3 | Account-type divergence: OPERATOR_INPUT_REQUIRED; supplied as COMPANY: ELIGIBLE | T-44 |
| FIX-018 | RT-R5 | Deleted inputs: QUARANTINED | T-42 |
| FIX-019 | RT-R1, RT-E2 | Deleted mandatory demand claim: QUARANTINED | T-42 |
| FIX-020, FIX-021 | RT-O3 | Proposal selling REJECTED at G5; unattested map G5 UNKNOWN | T-43 |
| FIX-022 | RT-E10 | Expired policy claim: G6 UNKNOWN | T-45 |
| FIX-024 | RT-E3 | No failure-base-rate search: LOW, outside ordering | T-46 |
| FIX-025, FIX-026 | RT-P7, RT-P8, RT-R8 | Undocumented refund rate: CASH_U and CONDITIONAL; tax resolved without opinion: stays professional-review | T-47 |
| FIX-027, FIX-028 | RT-C5 | Earned plus reward T5 in income ordering; earned plus capital T5 with CAP | T-48 |
| FIX-029, FIX-030, FIX-030b | RT-P5, RT-P18 | FAIL precedence; licence scope unsupplied; inapplicable restriction | T-49 |
| Gate-matrix variants FIX-001-R0, -G3U, -G4F, -G4U, -G5F, -G6F, -G7F, -G7U, -C1, -C2, -FEAS | T-12 coverage | REJECTED, QUARANTINED, CONDITIONAL, or ELIGIBLE-unassessed with the responsible gate | T-12, T-27 |

## Claim-level and ordering tests

| Test | Stipulation | Preregistered outcome |
|---|---|---|
| CT-01 | One class A source, then two class C internal assessments | DIRECTIONAL before and after |
| CT-02 | Ten class B republications of an unregistered upstream | UNKNOWN |
| CT-03 | One class A plus two class B sharing its origin | One origin; DIRECTIONAL |
| CT-04 | One class B with a registered admissible tier-4 upstream | DIRECTIONAL, zero independent origins |
| CT-05 | Affiliate-incentive tier-4 source on an earnings claim | UNKNOWN |
| CT-06 | Undated tier-4 source | UNKNOWN |
| CT-07 | Two origins, contradiction resolved against the claim | HYPOTHESIS |
| CT-08 | Two origins, denominator unknown | UNKNOWN |
| CT-09 | Edge with all five items, single regime; then trials count removed | DIRECTIONAL; UNKNOWN |
| OT-01 | Overlapping net cash, equal other levels | Tie |
| OT-02 | Record better on every dimension without overlap | Front and named dominator |
| OT-03 | Partially overlapping net cash, earlier S11b | Decided at FWK-42 S11b level |
| OT-04 | Every level overlapping, different platform concentration | Decided at FWK-43 concentration |

## Preregistration changes since V0.1 (SYS-12 justifications)

- FIX-005 no longer expects a confidence band: bands are not assigned to quarantined records (RT-R7b, STR-04). It now expects the quarantine reason to name the FINANCIAL_EDGE claim and the professional opinion is stipulated as logged so that the edge logic, not the legal override, is tested (RT-R2).
- FIX-009 stage values were corrected so the base case really is a Day-25 sale (RT-P22) and usable cash is computed from stage rows.
- FIX-011 base-case sale moved beyond Day 30 so the T4 component is derived from timing rather than a flag (RT-R7a).
- FIX-001 expects R1 and an ordering position because the base record now carries a supplied operator profile; the unassessed case moved to FIX-001-R0 (RT-O5, RT-O9).
- FIX-004 expects T4 by timing derivation; the earned component is replaced by the asset component when base-case cash is beyond Day 30 (FWK-10).
- FIX-014 now types capital_role NONE to test that signature triggers, not typed flags, assign T2 (RT-C1).
- OT-03 records were adjusted so that neither dominates the other, which the first V1.0 run exposed; the adjustment is recorded in results.md.

## Blinded repeatability

`tests/blind/fixtures-blind.json` is generated from `fixtures.json` with expected outcomes removed. `run_fixtures.py --blind` prints observed outcomes without comparison. The V0.1 blinded evaluation is recorded in `results.md` under T-37.
