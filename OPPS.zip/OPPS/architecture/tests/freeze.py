#!/usr/bin/env python3
"""Freeze the current file set into versions/<version>/ with a SHA-256 manifest (SYS-13).
Usage: python3 freeze.py v0.1        (refuses to overwrite an existing frozen version)
       python3 freeze.py v0.1 --verify
"""
import hashlib, os, shutil, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
ver = sys.argv[1]; dest = os.path.join(ROOT, "versions", ver)
def files():
    for dp, dn, fn in os.walk(ROOT):
        if os.sep + "versions" in dp or dp.endswith("versions"):
            continue
        for f in sorted(fn):
            if f.endswith((".md", ".json", ".py")) and not f.startswith("results-") and not f.startswith("structural-"):
                yield os.path.relpath(os.path.join(dp, f), ROOT)
if "--verify" in sys.argv:
    bad = []
    for line in open(os.path.join(dest, "MANIFEST.sha256")):
        h, _, rel = line.strip().partition("  ")
        p = os.path.join(dest, rel)
        if not os.path.exists(p) or hashlib.sha256(open(p, "rb").read()).hexdigest() != h:
            bad.append(rel)
    print("MANIFEST_OK" if not bad else f"MANIFEST_MISMATCH {bad}"); sys.exit(1 if bad else 0)
if os.path.exists(dest):
    print(f"refusing to overwrite existing frozen version {ver}"); sys.exit(2)
lines = []
for rel in files():
    src = os.path.join(ROOT, rel); dst = os.path.join(dest, rel)
    os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copy2(src, dst)
    lines.append(f"{hashlib.sha256(open(src, 'rb').read()).hexdigest()}  {rel}")
open(os.path.join(dest, "MANIFEST.sha256"), "w").write("\n".join(lines) + "\n")
print(f"frozen {len(lines)} files into versions/{ver}")
