# Research Architecture: 30-Day Net Collectible Cash Opportunity Research

Version: V1.0, RELEASED 2026-09-18 (see [CHANGELOG.md](CHANGELOG.md) and [07-quality-and-release-audit.md](07-quality-and-release-audit.md)). Frozen baselines: `versions/v0.1/` and `versions/v1.0/`.

## What this is

An auditable System, Structure, and Framework for later mass research into broad, legal, laptop-executable opportunities that could produce net collectible cash within 30 calendar days for a UAE-linked operator.

It contains **no researched opportunities, no rankings, no recommendations, no earnings benchmarks, and no mass-research prompt**. Nothing here claims that any opportunity will produce income or investment performance. Every hypothetical example in `tests/` is a controlled hypothetical architecture fixture and is quarantined from real research by rule.

## The three layers and their ownership rule

| Layer | File | Owns |
|---|---|---|
| System | [02-system.md](02-system.md) | Process: stages, roles, sweeps, verification, review, red team, revision, versioning, stopping. IDs `SYS-nn`. |
| Structure | [03-structure.md](03-structure.md) and `templates/` | Data: taxonomy, identifiers, record depths, state machine, registers, dashboards, schemas. IDs `STR-nn`. |
| Framework | [04-framework.md](04-framework.md) | Decisions: gates, tracks, bands, timing and cash models, prioritization, portfolio, freshness, jurisdiction routing, precision, reopening. IDs `FWK-nn`. |
| Framework module | [05-source-governance.md](05-source-governance.md) | Evidence admissibility and claim rules. IDs `EVD-nn`. |
| Framework module | [06-capital-risk-protocol.md](06-capital-risk-protocol.md) | Capital-risk and hybrid controls. IDs `CAP-nn`. |

**Ownership rule.** A process step lives only in the System file. A field definition lives only in the Structure file or a template schema. A decision rule lives only in the Framework or one of its two modules. Any other file may cite a control by ID but may not restate it. If two files appear to state the same rule, the one holding the ID heading is authoritative and the other is a defect.

## Identifier scheme

| Prefix | Meaning | Defined in |
|---|---|---|
| `REQ-nn`, `FM-nn` | Requirement; failure mode converted to a control | [01-requirements-and-failures.md](01-requirements-and-failures.md) |
| `SYS-nn`, `STR-nn`, `FWK-nn`, `EVD-nn`, `CAP-nn` | Controls | Files above |
| `T-nn` | Architecture test | [tests/test-plan.md](tests/test-plan.md) |
| `FIX-nnn` | Controlled hypothetical architecture fixture | `tests/` only |
| `RT-nn` | Red-team finding | [tests/red-team-findings.md](tests/red-team-findings.md) |

Record identifiers for later real research (`OPP-`, `MEC-`, `CLM-`, `SO-`, `ASM-`, `CON-`, `UNC-`, `REJ-`, `QUA-`, `REG-`, `DEC-`, `EXP-`, `POR-`, `SWP-`) are defined in STR-02.

## How to use this architecture in later research

1. Read [08-handoff-contract.md](08-handoff-contract.md) first. It lists obligations, what is unvalidated, what the operator must supply, and what needs professional review.
2. Open the operator profile (SYS-00) and create the `research/` root for real records.
3. Run family sweeps (SYS-03, SYS-04) across F01 to F14, recording L0 sightings only.
4. At the discovery freeze (SYS-05), resolve identity fields, deduplicate into mechanisms and variants (FWK-20), and complete the coverage audit and bias reviews (FWK-21).
5. Evaluate every variant in the fixed 13-step sequence (SYS-07): L1 FAIL-only screen, L2 investigation resolving every fatal gate, L3 decision. UNKNOWN or missing means quarantine, never a favorable default (FWK-01).
6. Order eligible records per track with reason lists (FWK-40 to FWK-47). There is no composite score and no ordering without a profile.
7. Test any portfolio (FWK-50) and publish the dashboards and five-way status (SYS-17).

## File map

```text
architecture/
├── README.md
├── 01-requirements-and-failures.md
├── 02-system.md
├── 03-structure.md
├── 04-framework.md
├── 05-source-governance.md
├── 06-capital-risk-protocol.md
├── 07-quality-and-release-audit.md
├── 08-handoff-contract.md
├── CHANGELOG.md
├── templates/
│   ├── operator-profile.md, opportunity-record.md
│   ├── sections/ (critical-path, economic-model, capital-risk-model, dependency-map, cold-start-and-validation-experiment)
│   ├── mechanism-registry.md, claim-evidence-matrix.md, source-register.md, authority-register.md
│   ├── query-log.md, family-sweep-coverage.md, coverage-audit.md
│   ├── assumption-register.md, contradiction-log.md, uncertainty-register.md, rejection-log.md, quarantine-log.md
│   ├── regulatory-verification-log.md, decision-log.md, capital-risk-dashboard.md, scenario-table.md, cross-track-table.md, portfolio-feasibility.md
├── tests/
│   ├── test-plan.md, fixtures.md, fixtures.json, results.md, red-team-findings.md, traceability.md
│   ├── run_fixtures.py, validate.py, freeze.py, blind/fixtures-blind.json
├── research/ (created by a research cycle; the only root for real records)
└── versions/ (v0.1 and v1.0 frozen baselines with MANIFEST.sha256)
```

## Running the checks

```bash
python3 tests/run_fixtures.py --label V1.0
```

```bash
python3 tests/validate.py --label V1.0
```

## Control index

Generated by `tests/validate.py`. Do not edit by hand.

<!-- CONTROL-INDEX-START -->
| ID | File | Heading |
|---|---|---|
| SYS-00 | [02-system.md](02-system.md#sys-00-operator-profile-intake) | Operator profile intake |
| SYS-01 | [02-system.md](02-system.md#sys-01-operating-stages) | Operating stages |
| SYS-02 | [02-system.md](02-system.md#sys-02-roles-and-perspectives) | Roles and perspectives |
| SYS-03 | [02-system.md](02-system.md#sys-03-family-sweep-definition) | Family sweep definition |
| SYS-04 | [02-system.md](02-system.md#sys-04-search-lenses-and-negative-evidence-query-classes) | Search lenses and negative-evidence query classes |
| SYS-05 | [02-system.md](02-system.md#sys-05-discovery-freeze-checkpoint) | Discovery freeze checkpoint |
| SYS-06 | [02-system.md](02-system.md#sys-06-research-saturation-and-stopping-rule) | Research saturation and stopping rule |
| SYS-07 | [02-system.md](02-system.md#sys-07-evaluation-sequence) | Evaluation sequence |
| SYS-08 | [02-system.md](02-system.md#sys-08-verification-procedure) | Verification procedure |
| SYS-09 | [02-system.md](02-system.md#sys-09-reverification-procedure) | Reverification procedure |
| SYS-10 | [02-system.md](02-system.md#sys-10-escalation-and-quarantine-handling) | Escalation and quarantine handling |
| SYS-11 | [02-system.md](02-system.md#sys-11-review-and-red-team-procedure) | Review and red-team procedure |
| SYS-12 | [02-system.md](02-system.md#sys-12-revision-and-regression-procedure) | Revision and regression procedure |
| SYS-13 | [02-system.md](02-system.md#sys-13-versioning-and-freeze-procedure) | Versioning and freeze procedure |
| SYS-14 | [02-system.md](02-system.md#sys-14-validation-experiment-procedure) | Validation experiment procedure |
| SYS-15 | [02-system.md](02-system.md#sys-15-portfolio-assembly-procedure) | Portfolio assembly procedure |
| SYS-16 | [02-system.md](02-system.md#sys-16-fixture-quarantine-procedure) | Fixture quarantine procedure |
| SYS-17 | [02-system.md](02-system.md#sys-17-reporting-procedure) | Reporting procedure |
| STR-01 | [03-structure.md](03-structure.md#str-01-discovery-families-and-secondary-dimensions) | Discovery families and secondary dimensions |
| STR-02 | [03-structure.md](03-structure.md#str-02-identifier-scheme) | Identifier scheme |
| STR-03 | [03-structure.md](03-structure.md#str-03-research-depths) | Research depths |
| STR-04 | [03-structure.md](03-structure.md#str-04-decision-state-machine) | Decision state machine |
| STR-05 | [03-structure.md](03-structure.md#str-05-opentbd-status-taxonomy) | Open/TBD status taxonomy |
| STR-06 | [03-structure.md](03-structure.md#str-06-analytical-tracks-and-components) | Analytical tracks and components |
| STR-07 | [03-structure.md](03-structure.md#str-07-project-level-registers-and-the-research-root) | Project-level registers and the research root |
| STR-08 | [03-structure.md](03-structure.md#str-08-claim-status-vocabulary-and-claim-classes) | Claim status vocabulary and claim classes |
| STR-09 | [03-structure.md](03-structure.md#str-09-dashboards) | Dashboards |
| STR-10 | [03-structure.md](03-structure.md#str-10-report-organization) | Report organization |
| STR-11 | [03-structure.md](03-structure.md#str-11-units-currencies-dates-and-numeric-provenance) | Units, currencies, dates, and numeric provenance |
| STR-12 | [03-structure.md](03-structure.md#str-12-template-schema-convention) | Template schema convention |
| STR-13 | [03-structure.md](03-structure.md#str-13-mechanism-record-and-variant-structure) | Mechanism record and variant structure |
| STR-14 | [03-structure.md](03-structure.md#str-14-fixture-namespace-isolation) | Fixture namespace isolation |
| FWK-01 | [04-framework.md](04-framework.md#fwk-01-gate-values-and-the-unknown-rule) | Gate values and the unknown rule |
| FWK-02 | [04-framework.md](04-framework.md#fwk-02-g1-legality) | G1 Legality |
| FWK-03 | [04-framework.md](04-framework.md#fwk-03-g2-platform-and-account-availability) | G2 Platform and account availability |
| FWK-04 | [04-framework.md](04-framework.md#fwk-04-g3-payout-path-to-usable-operator-controlled-cash) | G3 Payout path to usable operator-controlled cash |
| FWK-05 | [04-framework.md](04-framework.md#fwk-05-g4-laptop-executability) | G4 Laptop executability |
| FWK-06 | [04-framework.md](04-framework.md#fwk-06-g5-no-bespoke-selling-or-named-individual-dependency) | G5 No bespoke-selling or named-individual dependency |
| FWK-07 | [04-framework.md](04-framework.md#fwk-07-g6-platform-policy-compliance) | G6 Platform-policy compliance |
| FWK-08 | [04-framework.md](04-framework.md#fwk-08-g7-ethical-exclusion) | G7 Ethical exclusion |
| FWK-09 | [04-framework.md](04-framework.md#fwk-09-gate-order-stop-rules-and-overrides) | Gate order, stop rules, and overrides |
| FWK-10 | [04-framework.md](04-framework.md#fwk-10-track-assignment-from-structured-fields) | Track assignment from structured fields |
| FWK-11 | [04-framework.md](04-framework.md#fwk-11-conditional-gates) | Conditional gates |
| FWK-12 | [04-framework.md](04-framework.md#fwk-12-evidence-confidence-bands) | Evidence-confidence bands |
| FWK-13 | [04-framework.md](04-framework.md#fwk-13-risk-classification) | Risk classification |
| FWK-14 | [04-framework.md](04-framework.md#fwk-14-30-day-cash-compatibility-bands) | 30-day cash compatibility bands |
| FWK-15 | [04-framework.md](04-framework.md#fwk-15-horizon-classes-and-the-scalability-rule) | Horizon classes and the scalability rule |
| FWK-20 | [04-framework.md](04-framework.md#fwk-20-mechanism-deduplication-and-variants) | Mechanism deduplication and variants |
| FWK-21 | [04-framework.md](04-framework.md#fwk-21-category-coverage-audit) | Category coverage audit |
| FWK-30 | [04-framework.md](04-framework.md#fwk-30-thirty-day-timing-model) | Thirty-day timing model |
| FWK-31 | [04-framework.md](04-framework.md#fwk-31-net-collectible-cash-model) | Net collectible cash model |
| FWK-32 | [04-framework.md](04-framework.md#fwk-32-recovered-principal-and-realized-return) | Recovered principal and realized return |
| FWK-33 | [04-framework.md](04-framework.md#fwk-33-reserve-refund-and-chargeback-tail) | Reserve, refund, and chargeback tail |
| FWK-34 | [04-framework.md](04-framework.md#fwk-34-currency-conversion-withholding-tax-and-account-type) | Currency conversion, withholding, tax, and account type |
| FWK-35 | [04-framework.md](04-framework.md#fwk-35-validation-experiment-constraints) | Validation experiment constraints |
| FWK-36 | [04-framework.md](04-framework.md#fwk-36-cold-start-distribution-verification) | Cold-start distribution verification |
| FWK-37 | [04-framework.md](04-framework.md#fwk-37-dependency-mapping) | Dependency mapping |
| FWK-38 | [04-framework.md](04-framework.md#fwk-38-time-capital-skill-and-workload-feasibility) | Time, capital, skill, and workload feasibility |
| FWK-40 | [04-framework.md](04-framework.md#fwk-40-prioritization-sequence) | Prioritization sequence |
| FWK-41 | [04-framework.md](04-framework.md#fwk-41-within-track-non-dominance) | Within-track non-dominance |
| FWK-42 | [04-framework.md](04-framework.md#fwk-42-lexicographic-fallback) | Lexicographic fallback |
| FWK-43 | [04-framework.md](04-framework.md#fwk-43-tie-breakers) | Tie-breakers |
| FWK-44 | [04-framework.md](04-framework.md#fwk-44-bounded-scenario-dependent-ordering) | Bounded scenario-dependent ordering |
| FWK-45 | [04-framework.md](04-framework.md#fwk-45-cross-track-reporting) | Cross-track reporting |
| FWK-46 | [04-framework.md](04-framework.md#fwk-46-ties-and-incomparability) | Ties and incomparability |
| FWK-47 | [04-framework.md](04-framework.md#fwk-47-prioritization-eligibility) | Prioritization eligibility |
| FWK-50 | [04-framework.md](04-framework.md#fwk-50-portfolio-feasibility-gate) | Portfolio feasibility gate |
| FWK-60 | [04-framework.md](04-framework.md#fwk-60-source-freshness-limits) | Source freshness limits |
| FWK-61 | [04-framework.md](04-framework.md#fwk-61-jurisdiction-routing-question-matrix) | Jurisdiction routing question matrix |
| FWK-62 | [04-framework.md](04-framework.md#fwk-62-professional-verification-rule) | Professional verification rule |
| FWK-63 | [04-framework.md](04-framework.md#fwk-63-precision-and-numeric-provenance) | Precision and numeric provenance |
| FWK-64 | [04-framework.md](04-framework.md#fwk-64-wording-invariance) | Wording invariance |
| FWK-65 | [04-framework.md](04-framework.md#fwk-65-reopening-on-new-evidence) | Reopening on new evidence |
| FWK-66 | [04-framework.md](04-framework.md#fwk-66-quarantine-exit) | Quarantine exit |
| EVD-01 | [05-source-governance.md](05-source-governance.md#evd-01-source-hierarchy-and-permitted-uses) | Source hierarchy and permitted uses |
| EVD-02 | [05-source-governance.md](05-source-governance.md#evd-02-rejected-source-types-and-derivation-rules) | Rejected source types and derivation rules |
| EVD-03 | [05-source-governance.md](05-source-governance.md#evd-03-mandatory-claim-set-and-minimum-admissible-tier) | Mandatory claim set and minimum admissible tier |
| EVD-04 | [05-source-governance.md](05-source-governance.md#evd-04-independence-classification-and-origin-tracking) | Independence classification and origin tracking |
| EVD-05 | [05-source-governance.md](05-source-governance.md#evd-05-internal-agreement-is-not-evidence) | Internal agreement is not evidence |
| EVD-06 | [05-source-governance.md](05-source-governance.md#evd-06-claim-status-assignment) | Claim status assignment |
| EVD-07 | [05-source-governance.md](05-source-governance.md#evd-07-survivorship-and-denominator-control) | Survivorship and denominator control |
| EVD-08 | [05-source-governance.md](05-source-governance.md#evd-08-screenshots-and-earnings-claims) | Screenshots and earnings claims |
| EVD-09 | [05-source-governance.md](05-source-governance.md#evd-09-contradiction-and-negative-evidence-search-minimum) | Contradiction and negative-evidence search minimum |
| EVD-10 | [05-source-governance.md](05-source-governance.md#evd-10-claim-source-fit) | Claim-source fit |
| EVD-11 | [05-source-governance.md](05-source-governance.md#evd-11-dating-and-recency) | Dating and recency |
| EVD-12 | [05-source-governance.md](05-source-governance.md#evd-12-quantity-is-not-quality) | Quantity is not quality |
| EVD-13 | [05-source-governance.md](05-source-governance.md#evd-13-legal-source-classification-and-non-inheritance) | Legal-source classification and non-inheritance |
| EVD-14 | [05-source-governance.md](05-source-governance.md#evd-14-methodological-references-and-adaptation-limits) | Methodological references and adaptation limits |
| CAP-01 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-01-applicability) | Applicability |
| CAP-02 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-02-capital-fields) | Capital fields |
| CAP-03 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-03-drawdown-volatility-and-liquidity) | Drawdown, volatility, and liquidity |
| CAP-04 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-04-leverage-and-liquidation) | Leverage and liquidation |
| CAP-05 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-05-counterparty-and-custody) | Counterparty and custody |
| CAP-06 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-06-fees-spread-financing-slippage-and-withdrawal-holds) | Fees, spread, financing, slippage, and withdrawal holds |
| CAP-07 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-07-settlement-and-withdrawal) | Settlement and withdrawal |
| CAP-08 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-08-market-regime-dependency) | Market-regime dependency |
| CAP-09 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-09-evidence-of-persistent-edge) | Evidence of persistent edge |
| CAP-10 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-10-backtest-validity) | Backtest validity |
| CAP-11 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-11-repeatability-after-costs) | Repeatability after costs |
| CAP-12 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-12-probability-of-impairment-and-ruin) | Probability of impairment and ruin |
| CAP-13 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-13-regulatory-and-tax-routing) | Regulatory and tax routing |
| CAP-14 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-14-cases-reporting-and-ordering-of-capital-risk-outcomes) | Cases, reporting, and ordering of capital-risk outcomes |
| CAP-15 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-15-capital-risk-dashboard) | Capital-risk dashboard |
| CAP-16 | [06-capital-risk-protocol.md](06-capital-risk-protocol.md#cap-16-wording-cannot-evade-the-protocol) | Wording cannot evade the protocol |
<!-- CONTROL-INDEX-END -->
