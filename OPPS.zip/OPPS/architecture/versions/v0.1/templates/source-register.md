---
template: source-register
version: "1.0"
owner_control: EVD-01
fields:
  - name: so_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: locator
    type: text
    required: true
    consumer: [SYS-09]
  - name: tier
    type: int
    allowed: [1, 2, 3, 4, 5, 6, 7]
    required: true
    consumer: [EVD-01, EVD-03, FWK-60]
  - name: admissible
    type: bool
    required: true
    consumer: [EVD-02, EVD-03]
  - name: rejection_reason
    type: enum
    allowed: [AFFILIATE_REVIEW, COURSE_FUNNEL, UNVERIFIED_SCREENSHOT, CONTENT_FARM, CIRCULAR_STATISTIC, UNDATED_LISTICLE, UNTRACEABLE_EARNINGS, NONE]
    required: true
    consumer: [EVD-02]
  - name: independence_class
    type: enum
    allowed: [A, B, C]
    required: true
    consumer: [EVD-04, EVD-05, FWK-12]
  - name: upstream_source_id
    type: id
    required: false
    consumer: [EVD-04, EVD-02]
  - name: publisher_incentive
    type: text
    required: true
    consumer: [EVD-02]
  - name: affiliate_links_present
    type: bool
    required: true
    consumer: [EVD-02]
  - name: sells_course_or_coaching
    type: bool
    required: true
    consumer: [EVD-02]
  - name: dated
    type: bool
    required: true
    consumer: [EVD-11, EVD-02]
  - name: publication_date
    type: date
    required: false
    consumer: [EVD-11, FWK-60]
  - name: last_verified_date
    type: date
    required: true
    consumer: [FWK-60, SYS-09]
  - name: access_date
    type: date
    required: true
    consumer: [EVD-11]
  - name: freshness_class
    type: enum
    allowed: [PLATFORM, REGULATORY, DATASET, PRACTITIONER]
    required: true
    consumer: [FWK-60]
  - name: freshness_status
    type: enum
    allowed: [FRESH, OUTDATED]
    required: true
    consumer: [FWK-60, SYS-09, FWK-11]
  - name: supportable_claim_classes
    type: list
    required: true
    consumer: [EVD-10, EVD-01]
  - name: legal_source_class
    type: enum
    allowed: [BINDING_LAW, OFFICIAL_GUIDANCE, PLATFORM_POLICY, PROFESSIONAL_COMMENTARY, RESEARCHER_INTERPRETATION, NOT_LEGAL]
    required: true
    consumer: [EVD-13, FWK-02]
  - name: jurisdiction
    type: text
    required: false
    consumer: [EVD-10, FWK-61]
  - name: methodological_dependence
    type: text
    required: false
    consumer: [EVD-04]
---

# Source register (one row per source)

Freshness fields replace any separate freshness log. freshness_status is computed from last_verified_date and the FWK-60 limit for freshness_class.
