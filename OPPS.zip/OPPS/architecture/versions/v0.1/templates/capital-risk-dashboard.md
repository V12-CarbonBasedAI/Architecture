---
template: capital-risk-dashboard
version: "1.0"
owner_control: CAP-15
fields:
  - name: opp_id
    type: id
    required: true
    consumer: [CAP-15, STR-09]
  - name: track
    type: enum
    allowed: [T2, T5]
    required: true
    consumer: [CAP-15, FWK-45]
  - name: mechanism_kind
    type: enum
    allowed: [INVESTMENT, SPECULATION, TRADING, ARBITRAGE, YIELD, INCENTIVE_CAPTURE]
    required: true
    consumer: [CAP-11, CAP-15]
  - name: capital_deployed
    type: range
    unit: AED
    required: true
    consumer: [CAP-15, FWK-50]
  - name: plausible_max_loss
    type: range
    unit: AED
    required: true
    consumer: [CAP-15, FWK-13]
  - name: leverage_ratio
    type: range
    unit: ratio
    required: true
    consumer: [CAP-15, CAP-04]
  - name: custody_model
    type: enum
    allowed: [SELF, EXCHANGE, BROKER, PROTOCOL_CONTRACT, OTHER, UNKNOWN]
    required: true
    consumer: [CAP-15, CAP-05]
  - name: counterparty_regulatory_status
    type: enum
    allowed: [LICENSED_FOR_UAE, NOT_LICENSED, UNVERIFIABLE, UNKNOWN]
    required: true
    consumer: [CAP-15, CAP-05]
  - name: edge_status
    type: enum
    allowed: [VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, HYPOTHESIS, UNKNOWN]
    required: true
    consumer: [CAP-15, CAP-09]
  - name: prob_impairment_30d
    type: range
    unit: fraction
    required: true
    consumer: [CAP-15, CAP-12]
  - name: prob_ruin
    type: range
    unit: fraction
    required: true
    consumer: [CAP-15, CAP-12]
  - name: realized_return_conservative
    type: range
    unit: AED
    required: true
    consumer: [CAP-14, CAP-15, FWK-14]
  - name: recovered_principal
    type: range
    unit: AED
    required: true
    consumer: [FWK-32, CAP-15]
  - name: expected_return
    type: range
    unit: AED
    required: true
    consumer: [CAP-14, CAP-15]
  - name: reg_review_status
    type: enum
    allowed: [PROFESSIONAL_LEGAL_REVIEW_REQUIRED, PROFESSIONAL_TAX_REVIEW_REQUIRED, RESOLVED]
    required: true
    consumer: [CAP-13, CAP-15]
---

# Capital-risk dashboard (D5)

One row per T2 or T5 record. UNKNOWN is displayed as UNKNOWN. This dashboard never carries a rank and never appears inside an income ordering (FWK-45).
