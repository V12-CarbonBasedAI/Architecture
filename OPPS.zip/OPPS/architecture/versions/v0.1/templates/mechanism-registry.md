---
template: mechanism-registry
version: "1.0"
owner_control: STR-13
fields:
  - name: mec_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: value_delivered
    type: text
    required: true
    consumer: [FWK-20, STR-13]
  - name: payer_type
    type: enum
    allowed: [CONSUMER, BUSINESS, PLATFORM, PROTOCOL, SPONSOR_OR_GRANTOR, MARKET_COUNTERPARTY, MIXED]
    required: true
    consumer: [FWK-20, FWK-10, CAP-16]
  - name: operator_supplies
    type: enum
    allowed: [LABOR, CAPITAL, ASSET, DATA, ATTENTION, MIXED]
    required: true
    consumer: [FWK-20, FWK-10]
  - name: payment_rail
    type: text
    required: true
    consumer: [FWK-20, FWK-04]
  - name: settlement_mechanism
    type: enum
    allowed: [DIRECT_PROCESSOR, PLATFORM_PAYOUT, EXCHANGE_OR_BROKER, ON_CHAIN, BANK_TRANSFER, MIXED]
    required: true
    consumer: [FWK-20, FWK-10, CAP-16]
  - name: platform_dependency_class
    type: enum
    allowed: [NONE, SINGLE_PLATFORM, MULTI_PLATFORM, CUSTODIAL]
    required: true
    consumer: [FWK-20, FWK-43, FWK-13]
  - name: capital_role
    type: enum
    allowed: [NONE, WORKING_CAPITAL, AT_RISK_CAPITAL]
    required: true
    consumer: [FWK-10, CAP-16]
  - name: horizon_class
    type: enum
    allowed: [H30, H90, H365, H_OPEN]
    required: true
    consumer: [FWK-15, FWK-10]
  - name: primary_family
    type: enum
    allowed: [F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15, F16]
    required: true
    consumer: [FWK-21, SYS-06]
  - name: secondary_families
    type: list
    required: false
    consumer: [FWK-21]
  - name: track
    type: enum
    allowed: [T1, T2, T3, T4, T5]
    required: true
    consumer: [FWK-10, FWK-45]
  - name: variants
    type: list
    required: false
    consumer: [FWK-20]
  - name: opp_ids
    type: list
    required: true
    consumer: [FWK-20, FWK-21]
  - name: near_duplicate_of
    type: id
    required: false
    consumer: [FWK-20]
  - name: first_seen
    type: date
    required: true
    consumer: [SYS-06]
  - name: last_seen
    type: date
    required: true
    consumer: [SYS-06]
  - name: sweep_ids
    type: list
    required: true
    consumer: [SYS-06, FWK-21]
---

# Mechanism registry (one row per unique signature)

Signature equality across value_delivered, payer_type, operator_supplies, payment_rail, settlement_mechanism, and platform_dependency_class means one mechanism (FWK-20). Coverage (FWK-21) and saturation (SYS-06) count rows here, never sightings.
