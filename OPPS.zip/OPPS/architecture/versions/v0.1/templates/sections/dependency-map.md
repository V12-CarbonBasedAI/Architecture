---
template: dependency-map
version: "1.0"
owner_control: FWK-37
fields:
  - name: dependency_type
    type: enum
    allowed: [HUMAN_NAMED, HUMAN_ROLE, PLATFORM_APPROVAL, KYC_IDENTITY, PAYMENT_PROCESSOR, SUPPLIER_FULFILMENT, SUPPORT_BURDEN, ACCOUNT_LIMIT, TOOLING, OPERATOR_COMPANY]
    required: true
    consumer: [FWK-37, FWK-06, FWK-50, FWK-43]
  - name: description
    type: text
    required: true
    consumer: [admin]
    justification: human-readable label; evaluation uses dependency_type and the fields below
  - name: blocks_cash
    type: bool
    required: true
    consumer: [FWK-37, FWK-06, FWK-50]
  - name: availability_evidence_source_id
    type: id
    required: true
    consumer: [FWK-37, EVD-03]
  - name: availability_status
    type: enum
    allowed: [AVAILABLE, UNAVAILABLE, UNKNOWN]
    required: true
    consumer: [FWK-37, FWK-11, FWK-50]
  - name: failure_impact
    type: enum
    allowed: [BLOCKS_CASH, DELAYS_CASH, REDUCES_CASH, NONE]
    required: true
    consumer: [FWK-37, FWK-13]
  - name: requires_bespoke_approval
    type: bool
    required: true
    consumer: [FWK-06]
  - name: shared_with_opp_ids
    type: list
    required: false
    consumer: [FWK-50]
  - name: open_tbd_subtype
    type: enum
    allowed: [OPERATOR_INPUT_REQUIRED, FURTHER_RESEARCH_REQUIRED, PLATFORM_CONFIRMATION_REQUIRED, PROFESSIONAL_LEGAL_REVIEW_REQUIRED, PROFESSIONAL_TAX_REVIEW_REQUIRED, EVIDENCE_UNAVAILABLE, NONE]
    required: true
    consumer: [STR-05, SYS-10]
---

# Dependency map section (one row per dependency)

Any HUMAN_NAMED row, or any row with requires_bespoke_approval true and blocks_cash true, fails G5 (FWK-06). Any blocks_cash row at UNKNOWN availability keeps C2 open (FWK-11).
