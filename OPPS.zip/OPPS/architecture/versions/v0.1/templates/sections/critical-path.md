---
template: critical-path
version: "1.0"
owner_control: FWK-30
fields:
  - name: day_zero
    type: date
    required: true
    consumer: [FWK-30, FWK-14]
  - name: stage_id
    type: enum
    allowed: [S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11]
    required: true
    consumer: [FWK-30, FWK-04]
  - name: elapsed_days_conservative
    type: range
    unit: days
    required: true
    consumer: [FWK-30, FWK-14, FWK-41, FWK-42, FWK-43]
  - name: elapsed_days_base
    type: range
    unit: days
    required: true
    consumer: [FWK-30, FWK-14, FWK-15]
  - name: elapsed_days_best
    type: range
    unit: days
    required: true
    consumer: [FWK-30, FWK-14, FWK-04]
  - name: timing_tag
    type: enum
    allowed: [CALENDAR_FIXED, EFFORT_DRIVEN]
    required: true
    consumer: [FWK-30]
  - name: sequence_tag
    type: enum
    allowed: [SEQUENTIAL, PARALLEL]
    required: true
    consumer: [FWK-30]
  - name: overlaps_stage
    type: id
    required: false
    consumer: [FWK-30]
  - name: effort_hours
    type: range
    unit: hours
    required: true
    consumer: [FWK-38]
  - name: payout_threshold_attainable_by_day30
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    consumer: [FWK-04, FWK-30]
  - name: stage_source_id
    type: id
    required: true
    consumer: [FWK-60, SYS-09]
  - name: provenance_class
    type: enum
    allowed: [MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN]
    required: true
    consumer: [FWK-63, STR-11]
---

# Critical-path section (one row per stage S01 to S11)

Ends only at S11, usable operator-controlled cash. Day of usable cash per case equals day_zero plus the sequential sum of elapsed days, with PARALLEL stages overlapping the stage named in overlaps_stage. Any stage with UNKNOWN provenance makes the case UNKNOWN (FWK-30).
