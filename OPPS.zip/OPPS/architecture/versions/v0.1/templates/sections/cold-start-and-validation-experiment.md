---
template: cold-start-and-validation-experiment
version: "1.0"
owner_control: FWK-36
fields:
  - name: channel_name
    type: text
    required: true
    consumer: [admin]
    justification: label only; evaluation uses the fields below
  - name: requires_existing_audience
    type: bool
    required: true
    consumer: [FWK-36]
  - name: channel_available_to_cold_start_source_id
    type: id
    required: true
    consumer: [FWK-36, EVD-10]
  - name: cold_start_performance_claim_id
    type: id
    required: true
    consumer: [FWK-36, EVD-03, EVD-07]
  - name: demand_claim_id
    type: id
    required: true
    consumer: [FWK-36, EVD-03]
  - name: assumed_distribution_flag
    type: bool
    required: true
    consumer: [FWK-36, FWK-11]
  - name: exp_id
    type: id
    required: true
    consumer: [SYS-14, STR-02]
  - name: exp_claim_tested
    type: id
    required: true
    consumer: [FWK-35, SYS-14]
  - name: exp_cost_cap
    type: range
    unit: AED
    required: true
    consumer: [FWK-35, FWK-43]
  - name: exp_budget_status
    type: enum
    allowed: [SET, OPERATOR_INPUT_REQUIRED]
    required: true
    consumer: [FWK-35, STR-05]
  - name: exp_reversible
    type: enum
    allowed: [REVERSIBLE, BOUNDED_DOWNSIDE, IRREVERSIBLE]
    required: true
    consumer: [FWK-35, FWK-43]
  - name: exp_no_misleading_claims
    type: bool
    required: true
    consumer: [FWK-35]
  - name: exp_no_preselling_undeliverable
    type: bool
    required: true
    consumer: [FWK-35]
  - name: exp_compliance_checked
    type: bool
    required: true
    consumer: [FWK-35, FWK-07, FWK-02]
  - name: exp_stop_condition
    type: text
    required: true
    consumer: [FWK-35, SYS-14]
  - name: exp_result
    type: enum
    allowed: [NOT_RUN, POSITIVE, NEGATIVE, AMBIGUOUS, VOID]
    required: true
    consumer: [SYS-14, STR-04, FWK-65]
---

# Cold-start distribution and validation experiment section

Cold-start part completes at L2 and closes C1 when requires_existing_audience is false, both source and claim ids point to admissible evidence meeting EVD-10, and assumed_distribution_flag is false. Experiment part completes at L3 and closes C6 when every FWK-35 constraint field is satisfied; an experiment with exp_budget_status OPERATOR_INPUT_REQUIRED is designed but cannot run.
