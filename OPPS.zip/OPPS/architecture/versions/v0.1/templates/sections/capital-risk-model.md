---
template: capital-risk-model
version: "1.0"
owner_control: CAP-02
fields:
  - name: mechanism_kind
    type: enum
    allowed: [INVESTMENT, SPECULATION, TRADING, ARBITRAGE, YIELD, INCENTIVE_CAPTURE, EARNED]
    required: true
    consumer: [CAP-11, FWK-45]
  - name: starting_capital_required
    type: range
    unit: AED
    required: true
    consumer: [CAP-02, FWK-50]
  - name: capital_deployed
    type: range
    unit: AED
    required: true
    consumer: [CAP-02, CAP-12, FWK-32]
  - name: capital_at_risk
    type: range
    unit: AED
    required: true
    consumer: [CAP-02, FWK-13]
  - name: contractual_max_loss
    type: range
    unit: AED
    required: true
    consumer: [CAP-02, CAP-04]
  - name: contractual_max_loss_unlimited
    type: bool
    required: true
    consumer: [CAP-02, CAP-04]
  - name: plausible_max_loss
    type: range
    unit: AED
    required: true
    consumer: [CAP-02, FWK-13, FWK-41, CAP-14]
  - name: max_drawdown
    type: range
    unit: fraction
    required: true
    consumer: [CAP-03]
  - name: volatility_measure
    type: text
    required: true
    consumer: [CAP-03]
  - name: liquidity_exit_one_day
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    consumer: [CAP-03]
  - name: leverage_ratio
    type: range
    unit: ratio
    required: true
    consumer: [CAP-04, FWK-13]
  - name: liquidation_trigger_move
    type: range
    unit: fraction
    required: true
    consumer: [CAP-04]
  - name: custody_model
    type: enum
    allowed: [SELF, EXCHANGE, BROKER, PROTOCOL_CONTRACT, OTHER, UNKNOWN]
    required: true
    consumer: [CAP-05, FWK-13]
  - name: counterparty_regulatory_status
    type: enum
    allowed: [LICENSED_FOR_UAE, NOT_LICENSED, UNVERIFIABLE, UNKNOWN]
    required: true
    consumer: [CAP-05, FWK-61]
  - name: fees_spread_financing_slippage
    type: range
    unit: AED
    required: true
    consumer: [CAP-06, FWK-31]
  - name: settlement_stage_ids
    type: list
    required: true
    consumer: [CAP-07, FWK-04]
  - name: regime_span
    type: enum
    allowed: [SINGLE_REGIME, MULTI_REGIME, UNKNOWN]
    required: true
    consumer: [CAP-08]
  - name: edge_out_of_sample
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    consumer: [CAP-09]
  - name: edge_net_of_costs
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    consumer: [CAP-09]
  - name: edge_sample_size
    type: range
    unit: observations
    required: true
    consumer: [CAP-09]
  - name: edge_trials_count
    type: range
    unit: trials
    required: true
    consumer: [CAP-09, CAP-10]
  - name: edge_status
    type: enum
    allowed: [VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, HYPOTHESIS, UNKNOWN]
    required: true
    consumer: [CAP-09, CAP-14, FWK-12]
  - name: backtest_valid
    type: enum
    allowed: [YES, NO, NOT_USED]
    required: true
    consumer: [CAP-10]
  - name: repeatability_evidence
    type: enum
    allowed: [MULTI_PERIOD_NET, SINGLE_OUTCOME, NONE, UNKNOWN]
    required: true
    consumer: [CAP-11]
  - name: prob_impairment_30d
    type: range
    unit: fraction
    required: true
    consumer: [CAP-12, CAP-14]
  - name: prob_ruin
    type: range
    unit: fraction
    required: true
    consumer: [CAP-12, CAP-14]
  - name: prob_inputs_credible
    type: bool
    required: true
    consumer: [CAP-12]
  - name: expected_return
    type: range
    unit: AED
    required: true
    consumer: [CAP-14]
  - name: reg_ids
    type: list
    required: true
    consumer: [CAP-13, FWK-61]
  - name: provenance_class
    type: enum
    allowed: [MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN]
    required: true
    consumer: [FWK-63, STR-11]
---

# Capital-risk model section (T2 and T5 records)

Required in full before conditional gate C5 closes (CAP-01). expected_return must be UNKNOWN whenever edge_status is UNKNOWN or HYPOTHESIS (CAP-14). prob fields must be UNKNOWN when prob_inputs_credible is false (CAP-12).
