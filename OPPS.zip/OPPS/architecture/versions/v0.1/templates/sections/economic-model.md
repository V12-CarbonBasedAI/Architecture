---
template: economic-model
version: "1.0"
owner_control: FWK-31
fields:
  - name: case
    type: enum
    allowed: [CONSERVATIVE, BASE, BEST]
    required: true
    consumer: [FWK-31, FWK-14]
  - name: receipts_realized_by_day30
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: platform_fees
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: processing_fees
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: direct_costs_by_day30
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: refunds_realized_by_day30
    type: range
    unit: AED
    required: true
    consumer: [FWK-31]
  - name: reserve_rate
    type: range
    unit: fraction
    required: true
    consumer: [FWK-33]
  - name: refund_rate_documented
    type: range
    unit: fraction
    required: true
    consumer: [FWK-33]
  - name: refund_tail_days
    type: range
    unit: days
    required: true
    consumer: [FWK-33, STR-09]
  - name: reserve_haircut
    type: range
    unit: AED
    required: true
    consumer: [FWK-31, FWK-33]
  - name: withdrawal_and_fx_costs
    type: range
    unit: AED
    required: true
    consumer: [FWK-31, FWK-34]
  - name: tax_provision
    type: range
    unit: AED
    required: true
    consumer: [FWK-31, FWK-34]
  - name: tax_provision_status
    type: enum
    allowed: [RESOLVED, PROFESSIONAL_TAX_REVIEW_REQUIRED]
    required: true
    consumer: [FWK-34, STR-05]
  - name: recovered_principal
    type: range
    unit: AED
    required: true
    consumer: [FWK-32, FWK-31, STR-09, CAP-14]
  - name: realized_return
    type: range
    unit: AED
    required: true
    consumer: [FWK-32, CAP-14]
  - name: net_collectible_cash
    type: range
    unit: AED
    required: true
    consumer: [FWK-31, FWK-14, FWK-41, FWK-42, STR-09]
  - name: contingent_liability_after_day30
    type: range
    unit: AED
    required: true
    consumer: [FWK-33, STR-09]
  - name: provenance_class
    type: enum
    allowed: [MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN]
    required: true
    consumer: [FWK-63, STR-11]
  - name: original_currency
    type: text
    required: true
    consumer: [STR-11, FWK-34]
---

# Economic model section (one row per case)

net_collectible_cash is computed by the FWK-31 formula and nothing else. recovered_principal is subtracted from receipts and shown separately; it is never income (FWK-32). Any UNKNOWN required input makes the case UNKNOWN.
