---
template: rejection-log
version: "1.0"
owner_control: STR-04
fields:
  - name: rej_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: opp_id
    type: id
    required: true
    consumer: [STR-04, SYS-17]
  - name: resulting_state
    type: enum
    allowed: [REJECTED, PROHIBITED]
    required: true
    consumer: [STR-04, STR-09]
  - name: failed_gate
    type: enum
    allowed: [G1, G2, G3, G4, G5, G6, G7, C5_TRACK_GATE, PORTFOLIO_ONLY]
    required: true
    consumer: [FWK-09, STR-09]
  - name: evidence_source_ids
    type: list
    required: true
    consumer: [FWK-01, EVD-03]
  - name: evaluation_step
    type: int
    required: true
    consumer: [SYS-07, FWK-65]
  - name: reopen_condition
    type: text
    required: true
    consumer: [FWK-65]
  - name: decision_date
    type: date
    required: true
    consumer: [FWK-60, FWK-65]
---

# Rejection log

A rejection requires admissible evidence of the fail condition (FWK-01). A rejection never rests on an UNKNOWN. reopen_condition names the evidence that would reopen the record (FWK-65).
