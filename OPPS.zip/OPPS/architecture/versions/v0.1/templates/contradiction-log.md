---
template: contradiction-log
version: "1.0"
owner_control: EVD-09
fields:
  - name: con_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: opp_id
    type: id
    required: false
    consumer: [FWK-65]
  - name: claim_ids
    type: list
    required: true
    consumer: [EVD-06, FWK-12]
  - name: search_type
    type: enum
    allowed: [NEGATIVE_EVIDENCE, POLICY_REVERSAL, REGULATORY_ACTION, FAILURE_ACCOUNT, SOURCE_DISAGREEMENT]
    required: true
    consumer: [EVD-09, SYS-04]
  - name: queries_run
    type: text
    required: true
    consumer: [EVD-09]
  - name: search_date
    type: date
    required: true
    consumer: [EVD-09, FWK-60]
  - name: result
    type: enum
    allowed: [NONE_FOUND, FOUND_MATERIAL, FOUND_IMMATERIAL]
    required: true
    consumer: [EVD-09, EVD-06, FWK-65]
  - name: source_ids
    type: list
    required: false
    consumer: [EVD-04]
  - name: adjudication
    type: enum
    allowed: [UNRESOLVED, RESOLVED_FOR_CLAIM, RESOLVED_AGAINST_CLAIM]
    required: true
    consumer: [EVD-06, FWK-12, FWK-65]
  - name: reopened_opp
    type: bool
    required: true
    consumer: [FWK-65, SYS-09]
---

# Contradiction log

Every EVD-09 minimum search is logged here even when the result is NONE_FOUND. FOUND_MATERIAL with UNRESOLVED adjudication sets affected claims to CONTRADICTION and reopens the record (FWK-65).
