---
template: portfolio-feasibility
version: "1.0"
owner_control: FWK-50
fields:
  - name: por_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: member_opp_ids
    type: list
    required: true
    consumer: [FWK-50, SYS-15]
  - name: aggregate_setup_hours
    type: range
    unit: hours
    required: true
    consumer: [FWK-50]
  - name: peak_week_recurring_hours
    type: range
    unit: hours
    required: true
    consumer: [FWK-50]
  - name: operator_hours_limit
    type: range
    unit: hours
    required: true
    consumer: [FWK-50, FWK-44]
  - name: peak_simultaneous_capital
    type: range
    unit: AED
    required: true
    consumer: [FWK-50]
  - name: operator_capital_limit
    type: range
    unit: AED
    required: true
    consumer: [FWK-50, FWK-44]
  - name: aggregate_max_plausible_loss
    type: range
    unit: AED
    required: true
    consumer: [FWK-50]
  - name: operator_loss_limit
    type: range
    unit: AED
    required: true
    consumer: [FWK-50, FWK-44]
  - name: shared_dependencies
    type: list
    required: true
    consumer: [FWK-50]
  - name: shared_limit_exceeded
    type: enum
    allowed: [YES, NO, UNKNOWN]
    required: true
    consumer: [FWK-50]
  - name: aggregate_support_burden_hours
    type: range
    unit: hours
    required: true
    consumer: [FWK-50]
  - name: correlated_risks
    type: list
    required: true
    consumer: [FWK-50]
  - name: correlation_unknown_on_cash_blocking
    type: bool
    required: true
    consumer: [FWK-50]
  - name: limits_status
    type: enum
    allowed: [ALL_SET, OPERATOR_INPUT_REQUIRED]
    required: true
    consumer: [FWK-50, STR-05]
  - name: breakpoints
    type: text
    required: true
    consumer: [FWK-50, SYS-15]
  - name: result
    type: enum
    allowed: [FEASIBLE, INFEASIBLE, CONDITIONAL, BLOCKED_UNKNOWN]
    required: true
    consumer: [FWK-50, STR-09, SYS-15]
---

# Portfolio feasibility record

Individual feasibility never establishes portfolio feasibility. result is computed by FWK-50 only.
