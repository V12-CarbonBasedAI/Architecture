---
template: regulatory-verification-log
version: "1.0"
owner_control: FWK-61
fields:
  - name: reg_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: opp_id
    type: id
    required: true
    consumer: [FWK-02, CAP-13]
  - name: activity_class
    type: enum
    allowed: [A1, A2, A3, A4, A5, A6, A7, A8, A9, A10]
    required: true
    consumer: [FWK-61, FWK-62]
  - name: jurisdiction_role
    type: enum
    allowed: [OPERATOR_RESIDENCE, COMPANY_JURISDICTION, CUSTOMER_LOCATION, PLATFORM_JURISDICTION]
    required: true
    consumer: [FWK-61, FWK-02]
  - name: jurisdiction
    type: text
    required: true
    consumer: [FWK-61, EVD-13]
  - name: question
    type: text
    required: true
    consumer: [FWK-61]
  - name: authority_class
    type: text
    required: true
    consumer: [FWK-61]
  - name: source_id
    type: id
    required: true
    consumer: [EVD-13, FWK-02]
  - name: legal_source_class
    type: enum
    allowed: [BINDING_LAW, OFFICIAL_GUIDANCE, PLATFORM_POLICY, PROFESSIONAL_COMMENTARY, RESEARCHER_INTERPRETATION]
    required: true
    consumer: [EVD-13, FWK-02]
  - name: effective_date
    type: date
    required: false
    consumer: [EVD-13]
  - name: access_date
    type: date
    required: true
    consumer: [FWK-60, EVD-11]
  - name: applicability
    type: enum
    allowed: [APPLIES, DOES_NOT_APPLY, UNCERTAIN]
    required: true
    consumer: [FWK-02, FWK-62]
  - name: finding
    type: enum
    allowed: [NO_RESTRICTION_FOUND, RESTRICTION_FOUND, LICENSE_REQUIRED, UNRESOLVED]
    required: true
    consumer: [FWK-02, FWK-09]
  - name: professional_review_required
    type: bool
    required: true
    consumer: [FWK-62, FWK-09]
  - name: uncertainty_note
    type: text
    required: true
    consumer: [FWK-62, STR-05]
---

# Regulatory verification log

One row per jurisdiction-role, activity-class question. RESEARCHER_INTERPRETATION or PROFESSIONAL_COMMENTARY never closes G1 (EVD-13). UNRESOLVED with applicability APPLIES or UNCERTAIN sets material_unresolved_legal_question on the record (FWK-09).
