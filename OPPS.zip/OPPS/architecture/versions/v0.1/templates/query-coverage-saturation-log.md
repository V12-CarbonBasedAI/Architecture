---
template: query-coverage-saturation-log
version: "1.0"
owner_control: SYS-03
fields:
  - name: sweep_id
    type: id
    required: true
    consumer: [SYS-03, SYS-06]
  - name: sweep_status
    type: enum
    allowed: [COMPLETE, PARTIAL]
    required: true
    consumer: [SYS-03, SYS-06, FWK-21]
  - name: family
    type: enum
    allowed: [F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15, F16]
    required: true
    consumer: [SYS-03, FWK-21, SYS-06]
  - name: lens
    type: enum
    allowed: [MECHANISM_PAYER, ADJACENT_EMERGING, CONTRARY_FAILURE]
    required: true
    consumer: [SYS-04, SYS-03]
  - name: query_text
    type: text
    required: true
    consumer: [SYS-03, EVD-09]
  - name: query_class
    type: enum
    allowed: [MECHANISM, PAYER, PLATFORM_POLICY, NEGATIVE_EVIDENCE, RECENCY_LIMITED]
    required: true
    consumer: [SYS-03, SYS-04]
  - name: query_date
    type: date
    required: true
    consumer: [SYS-03]
  - name: sightings_new
    type: int
    required: true
    consumer: [FWK-21]
  - name: mechanisms_new_after_dedup
    type: int
    required: true
    consumer: [SYS-06, FWK-21]
  - name: taxonomy_extensions
    type: int
    required: true
    consumer: [SYS-06]
  - name: family_saturation_status
    type: enum
    allowed: [SATURATED, UNSATURATED]
    required: true
    consumer: [SYS-06, FWK-21, STR-10]
  - name: coverage_status
    type: enum
    allowed: [COVERAGE_COMPLETE, COVERAGE_INCOMPLETE]
    required: true
    consumer: [FWK-21, SYS-05, STR-10]
  - name: bias_review_familiarity
    type: text
    required: true
    consumer: [SYS-05, FWK-21]
  - name: bias_review_popularity
    type: text
    required: true
    consumer: [SYS-05, FWK-21]
  - name: emerging_gap_review
    type: text
    required: true
    consumer: [SYS-05, FWK-21]
  - name: languages_markets_not_searched
    type: text
    required: true
    consumer: [FWK-21]
---

# Query, coverage, and saturation log

Query rows are one per query. Coverage and saturation rows are one per family per sweep. Saturation is per family and never a claim of exhaustive discovery (SYS-06).
