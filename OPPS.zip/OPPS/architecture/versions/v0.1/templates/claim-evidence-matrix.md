---
template: claim-evidence-matrix
version: "1.0"
owner_control: STR-08
fields:
  - name: clm_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key
  - name: opp_id
    type: id
    required: true
    consumer: [FWK-12, SYS-08]
  - name: claim_class
    type: enum
    allowed: [LEGALITY, PLATFORM_ELIGIBILITY, PAYOUT_PATH, FEES_AND_COSTS, DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, FINANCIAL_EDGE, DEPENDENCY_AVAILABILITY]
    required: true
    consumer: [EVD-03, FWK-12, EVD-07]
  - name: claim_text
    type: text
    required: true
    consumer: [admin]
    justification: the claim as stated for human review; status is decided from the fields below
  - name: decision_critical
    type: bool
    required: true
    consumer: [FWK-12, SYS-07]
  - name: source_ids
    type: list
    required: true
    consumer: [EVD-03, EVD-04, EVD-06]
  - name: highest_admissible_tier
    type: int
    required: true
    consumer: [EVD-03, EVD-06]
  - name: class_a_count
    type: int
    required: true
    consumer: [EVD-04, EVD-06, FWK-12]
  - name: claim_source_fit
    type: enum
    allowed: [FIT, NOT_APPLICABLE]
    required: true
    consumer: [EVD-10, EVD-06]
  - name: denominator
    type: text
    required: true
    consumer: [EVD-07]
  - name: denominator_known
    type: bool
    required: true
    consumer: [EVD-07]
  - name: failure_base_rate_search
    type: enum
    allowed: [DONE_FOUND, DONE_NONE, NOT_DONE]
    required: true
    consumer: [EVD-07, EVD-09]
  - name: contradiction_ids
    type: list
    required: false
    consumer: [EVD-06, FWK-65]
  - name: status
    type: enum
    allowed: [VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, INFERENCE, ASSUMPTION, HYPOTHESIS, CONTRADICTION, UNKNOWN, OUTDATED]
    required: true
    consumer: [EVD-06, FWK-12, FWK-01]
  - name: within_freshness
    type: bool
    required: true
    consumer: [FWK-60, EVD-06]
  - name: last_verified
    type: date
    required: true
    consumer: [FWK-60, SYS-09]
---

# Claim-evidence matrix (one row per claim)

Status is assigned by EVD-06 from tier, class A count, fit, denominator, contradictions, and freshness. Claim class, status, and the record's confidence band are three separate things and are never merged.
