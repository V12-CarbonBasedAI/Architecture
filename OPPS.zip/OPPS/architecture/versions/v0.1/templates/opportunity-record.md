---
template: opportunity-record
version: "1.0"
owner_control: STR-03
fields:
  - name: opp_id
    type: id
    required: true
    consumer: [admin]
    justification: identity key for the record; consumed by every register through linkage
  - name: sweep_id
    type: id
    required: true
    consumer: [SYS-03, FWK-21]
  - name: depth
    type: enum
    allowed: [L0, L1, L2, L3]
    required: true
    consumer: [STR-03, FWK-47]
  - name: state
    type: enum
    allowed: [DISCOVERED, MERGED, SCREENED, PROHIBITED, REJECTED, QUARANTINED, CONDITIONAL, ELIGIBLE, VALIDATION_PENDING, VALIDATED, INVALIDATED]
    required: true
    consumer: [STR-04, FWK-47, SYS-15]
  - name: primary_family
    type: enum
    allowed: [F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15, F16]
    required: true
    consumer: [STR-01, FWK-21, SYS-06]
  - name: secondary_families
    type: list
    required: false
    consumer: [FWK-21]
  - name: mechanism_description
    type: text
    required: true
    consumer: [admin]
    justification: free text for human reading; excluded from all evaluation by FWK-64
  - name: source_pointer
    type: id
    required: true
    consumer: [SYS-08]
  - name: first_seen
    type: date
    required: true
    consumer: [FWK-21]
  - name: mec_id
    type: id
    required_at: L1
    consumer: [FWK-20, STR-13]
  - name: dedup_result
    type: enum
    allowed: [UNIQUE, MERGED, NEAR_DUPLICATE]
    required_at: L1
    consumer: [FWK-20, FWK-21]
  - name: track
    type: enum
    allowed: [T1, T2, T3, T4, T5]
    required_at: L1
    consumer: [FWK-10, FWK-45, CAP-01, FWK-11]
  - name: track_rule_step
    type: enum
    allowed: [1, 2, 3, 4]
    required_at: L1
    consumer: [FWK-10]
  - name: capital_role
    type: enum
    allowed: [NONE, WORKING_CAPITAL, AT_RISK_CAPITAL]
    required_at: L1
    consumer: [FWK-10, CAP-16, CAP-01]
  - name: cash_depends_on_price_or_counterparty
    type: bool
    required_at: L1
    consumer: [FWK-10, CAP-16]
  - name: gate_G1
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-02, FWK-09, FWK-47, STR-09]
  - name: gate_G2
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-03, FWK-47, STR-09]
  - name: gate_G2_signup
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-03]
  - name: gate_G2_monetize
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-03]
  - name: gate_G2_withdraw
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-03]
  - name: gate_G3
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L2
    consumer: [FWK-04, FWK-47, STR-09]
  - name: gate_G4
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-05, FWK-47, STR-09]
  - name: gate_G5
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-06, FWK-47, STR-09]
  - name: gate_G6
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-07, FWK-47, STR-09]
  - name: gate_G7
    type: enum
    allowed: [PASS, FAIL, UNKNOWN]
    required_at: L1
    consumer: [FWK-08, FWK-09, FWK-47, STR-09]
  - name: material_unresolved_legal_question
    type: bool
    required_at: L2
    consumer: [FWK-09, FWK-62]
  - name: open_tbd_subtype
    type: enum
    allowed: [OPERATOR_INPUT_REQUIRED, FURTHER_RESEARCH_REQUIRED, PLATFORM_CONFIRMATION_REQUIRED, PROFESSIONAL_LEGAL_REVIEW_REQUIRED, PROFESSIONAL_TAX_REVIEW_REQUIRED, EVIDENCE_UNAVAILABLE, NONE]
    required_at: L1
    consumer: [STR-05, SYS-10, FWK-66]
  - name: blocking_item
    type: text
    required_at: L1
    consumer: [SYS-10, FWK-66, STR-09]
  - name: claim_ids
    type: list
    required_at: L2
    consumer: [FWK-12, SYS-08]
  - name: conditional_C1
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L2
    consumer: [FWK-11, FWK-36]
  - name: conditional_C2
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L2
    consumer: [FWK-11, FWK-37]
  - name: conditional_C3
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L3
    consumer: [FWK-11, FWK-31]
  - name: conditional_C4
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L3
    consumer: [FWK-11, FWK-30]
  - name: conditional_C5
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L3
    consumer: [FWK-11, CAP-01]
  - name: conditional_C6
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L3
    consumer: [FWK-11, FWK-35]
  - name: conditional_C7
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L2
    consumer: [FWK-11, FWK-60]
  - name: conditional_C8
    type: enum
    allowed: [OPEN, CLOSED]
    required_at: L2
    consumer: [FWK-11, EVD-09]
  - name: assumed_distribution
    type: bool
    required_at: L2
    consumer: [FWK-36]
  - name: setup_hours
    type: range
    unit: hours
    required_at: L2
    consumer: [FWK-38, FWK-50]
  - name: recurring_hours_per_week
    type: range
    unit: hours
    required_at: L2
    consumer: [FWK-38, FWK-41, FWK-42, FWK-43, FWK-50]
  - name: required_skills
    type: list
    required_at: L2
    consumer: [FWK-38]
  - name: setup_capital
    type: range
    unit: AED
    required_at: L2
    consumer: [FWK-38, FWK-50]
  - name: working_capital
    type: range
    unit: AED
    required_at: L2
    consumer: [FWK-38, FWK-41, FWK-50]
  - name: at_risk_capital
    type: range
    unit: AED
    required_at: L2
    consumer: [FWK-38, FWK-41, FWK-50, CAP-02]
  - name: max_plausible_loss
    type: range
    unit: AED
    required_at: L3
    consumer: [FWK-13, FWK-41, FWK-42, FWK-43, FWK-50, CAP-02]
  - name: risk_types
    type: list
    required_at: L3
    consumer: [FWK-13, FWK-50]
  - name: risk_class
    type: enum
    allowed: [R0, R1, R2, R3]
    required_at: L3
    consumer: [FWK-13, FWK-40, STR-09]
  - name: confidence_band
    type: enum
    allowed: [HIGH, MODERATE, LOW, UNRESOLVED]
    required_at: L3
    consumer: [FWK-12, FWK-40, STR-09]
  - name: cash_band
    type: enum
    allowed: [CASH_A, CASH_B, CASH_C, CASH_D, CASH_U]
    required_at: L3
    consumer: [FWK-14, FWK-40, FWK-47, STR-09]
  - name: horizon_class
    type: enum
    allowed: [H30, H90, H365, H_OPEN]
    required_at: L3
    consumer: [FWK-15, FWK-10]
  - name: scalability_note
    type: text
    required: false
    consumer: [STR-10]
  - name: prioritization_result
    type: text
    required_at: L3
    consumer: [FWK-40, STR-10]
  - name: reverification_triggers
    type: list
    required_at: L3
    consumer: [SYS-09, FWK-65]
  - name: platform_concentration
    type: int
    required_at: L3
    consumer: [FWK-43]
  - name: sources_within_freshness
    type: bool
    required_at: L2
    consumer: [FWK-60, FWK-47, FWK-11]
---

# Opportunity record template

One file per candidate. Fill depths in order. Section fragments in `templates/sections/` are embedded at the depth shown. Free text never changes an evaluation output (FWK-64). Fixture identifiers and STIPULATED provenance are prohibited here (STR-14).

## L0 Sighting
opp_id, sweep_id, primary_family, mechanism_description, source_pointer, first_seen.

## L1 Preliminary screen
Signature fields (copied to the mechanism registry), mec_id, dedup_result, track, track_rule_step, capital_role, cash_depends_on_price_or_counterparty, gate values G1, G2 (with three sub-checks), G4, G5, G6, G7 where determinable, open_tbd_subtype, blocking_item.

## L2 Investigation record
claim_ids, gate_G3, material_unresolved_legal_question, embedded `sections/dependency-map.md`, embedded `sections/cold-start-and-validation-experiment.md` (cold-start part), feasibility fields, conditional gates C1, C2, C7, C8, sources_within_freshness, jurisdiction routing output as REG ids.

## L3 Decision record
Embedded `sections/critical-path.md`, `sections/economic-model.md`, `sections/capital-risk-model.md` (T2 and T5), validation experiment design, gate summary, state, confidence_band, risk_class, cash_band, horizon_class, conditional gates C3 to C6, max_plausible_loss, risk_types, platform_concentration, prioritization_result, reverification_triggers, scalability_note.
