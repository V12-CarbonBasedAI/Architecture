# 07 Quality and release audit

Owner layer: System (SYS-12, SYS-13 govern the process). This file states the release conditions, the mechanical checks that verify them, the five-way validation status, and the supplementary quality scores. Results per version are in `tests/results.md`.

## Release conditions

V1.0 is RELEASED only when every row below reads PASS in `tests/results.md` for label V1.0. Supplementary quality scores never substitute for a failed condition.

| Condition | Verified by |
|---|---|
| Every requirement has a stable ID and owning control | T-07 |
| Every control has exactly one authoritative location and is indexed | T-01, T-02 |
| Every decision-relevant template field has a documented consumer | T-04 |
| Every fatal gate has a mechanical test at PASS, FAIL, and UNKNOWN | T-12 |
| All fixtures reproduce preregistered outcomes | run_fixtures FIXTURES row |
| Deduplication precedes coverage counting | T-13 |
| Track assignment precedes track-specific evaluation | T-14 |
| Unknown fatal conditions cause quarantine | T-20 |
| Returned principal is never classified as income | T-16 |
| Day-30 qualification ends at usable operator-controlled cash | T-17 |
| Financial and crypto mechanisms cannot evade capital-risk controls through wording | T-11, T-24 |
| Portfolio feasibility is tested | T-18 |
| The V0.1 manifest validates | T-10 |
| Links, anchors, schemas, identifiers, state transitions, and traceability validate | T-03, T-04, T-05, T-09, T-07 |
| No unfinished placeholder or unsubtyped unknown | T-06 |
| No critical or high-severity defect remains open | T-38 and `tests/red-team-findings.md` |
| Blinded repeatability reproduced | T-37 |
| Limitations, unvalidated items, and operator inputs stay visible | T-39, `08-handoff-contract.md` |
| Design parameters recorded | T-40 |
| Non-exhaustiveness stated | T-41 |

## Five-way validation status

### Logically validated

Verified by the fixture engine and structural validator for the current version: gate semantics and order (FWK-01 to FWK-09), track assignment (FWK-10), conditional gates (FWK-11), bands (FWK-12 to FWK-14), scalability isolation (FWK-15), deduplication (FWK-20), timing and net-cash formulas (FWK-30 to FWK-34), principal separation (FWK-32), dominance, lexicographic fallback, and tie preservation (FWK-41 to FWK-46), portfolio aggregation (FWK-50), freshness expiry effect (FWK-60), reopening (FWK-65), claim status and corroboration counting (EVD-04 to EVD-07, EVD-12), label evasion (CAP-16), state machine closure (STR-04), schema consumers (STR-12), and fixture isolation (STR-14). Validation means the rules behave as written on stipulated inputs. It does not mean the rules are complete for every real case.

### Externally grounded methodology

The references in EVD-14 informed the claim-status hierarchy, the decision not to use a composite score, the critical-path discipline, and the backtest standards. Each is an adaptation with the stated limits. None validates this architecture as a whole, and the references were not fetched during construction; their availability is FURTHER_RESEARCH_REQUIRED at first use.

### Unvalidated until real research

Nothing in this architecture establishes: demand for any mechanism; earnings, conversion, or margins; distribution performance for a cold-start operator; which payout paths actually work for a UAE account; the existence of any financial edge; the real-world ranking of any opportunity; the adequacy of the 16 families against the real universe; the sufficiency of the freshness limits; or the practicality of the record depths under real research load. Fixture outcomes carry no information about any of these.

### Operator input required

Budget and experiment cost cap; capital available and loss limits (also the class thresholds in FWK-44); weekly hours; skills beyond ordinary laptop literacy and marketing experience; account type (personal or company) and existing platform or bank accounts; free-zone license activity scope; emirate and residency status; payment and withdrawal rails already accessible; preferences over risk types; target cash amount; execution circumstances. Until supplied, risk class is R0, portfolio results are CONDITIONAL, scenario orderings are unpublished, and the affected gates may be UNKNOWN.

### Professional review required

Any interpretation of binding law or official guidance against the operator's facts; activity classes A3, A4, A5, A6 (financial promotion, securities and derivatives, virtual assets, payments); tax treatment including VAT and corporate tax; license-scope questions; and any capital-risk mechanism's regulatory status. The architecture routes these and never resolves them.

## Supplementary quality scores

Twenty dimensions, each scored 0 to 10 as five checks of 0 to 2: explicit rule, operational instructions, ordinary-case behavior, adverse-case behavior, traceability. Scores are self-assessed by the integrator and independently re-scored by the red-team reviewer; both are recorded in `tests/results.md`. A score never overrides a failed release condition. Threshold for release support: at least 8 per dimension and no zero-valued check.

| # | Dimension | Primary controls |
|---|---|---|
| 1 | Layer separation | README ownership rule, STR-12 |
| 2 | Discovery breadth | STR-01, SYS-03, SYS-05 |
| 3 | Taxonomy blind-spot resistance | STR-01, FWK-21 |
| 4 | Deduplication | FWK-20, STR-13 |
| 5 | Source controls | EVD-01 to EVD-13 |
| 6 | Fatal-gate precedence | FWK-01, FWK-09, FWK-47 |
| 7 | Unknown handling | FWK-01, SYS-10, FWK-66, STR-05 |
| 8 | Time-to-cash separation | FWK-30, FWK-04 |
| 9 | Cold-start verification | FWK-36, EVD-10 |
| 10 | Dependency exposure | FWK-37, FWK-06 |
| 11 | Track separation | FWK-10, CAP-01 to CAP-16 |
| 12 | Speculation not income | FWK-45, CAP-14, FWK-32 |
| 13 | Jurisdiction without false certainty | FWK-61, FWK-62, EVD-13 |
| 14 | Scalability containment | FWK-15 |
| 15 | Visible unknowns | STR-05, SYS-17 |
| 16 | Precision discipline | FWK-63, STR-11 |
| 17 | Operational prioritization | FWK-40 to FWK-47 |
| 18 | Portfolio feasibility | FWK-50, SYS-15 |
| 19 | Fixture integrity | SYS-16, STR-14, tests |
| 20 | Skill convertibility | STR-12, README index, tests scripts |
