# 06 Capital-risk protocol (Framework module)

Owner layer: Framework module. This file owns every control that applies to capital-risk (T2) and hybrid (T5) records and to any record that places capital at risk. Field shapes are in `templates/sections/capital-risk-model.md` and `templates/capital-risk-dashboard.md`. Jurisdiction routing is FWK-61.

### CAP-01 Applicability

The full protocol applies to every T2 record, every T5 record with a capital-risk component, and any record where FWK-10 step 1 fires. Conditional gate C5 is closed only when CAP-02 to CAP-14 are complete. No candidate may opt out by describing itself as low risk, hedged, risk-free, or guaranteed.

### CAP-02 Capital fields

Required ranges with provenance: starting capital required; capital deployed; capital at risk; contractual maximum loss (the loss cap written into the instrument or venue terms, or NONE if unlimited); plausible maximum loss (the loss under documented adverse conditions including gap, liquidation, or counterparty failure). Where contractual maximum loss is unlimited, plausible maximum loss must exceed capital deployed and the risk type LEVERAGE is set.

### CAP-03 Drawdown, volatility, and liquidity

Record the documented or measured maximum drawdown of the strategy or asset over the evidence period, the volatility measure used with its window, and liquidity in terms of documented ability to exit the full position within one day without material slippage. Undocumented values are UNKNOWN and make the plausible maximum loss UNKNOWN.

### CAP-04 Leverage and liquidation

Record leverage ratio, margin requirements, liquidation mechanics, and the price move that would trigger liquidation. Any leverage above 1 requires the LEVERAGE risk type and a plausible maximum loss that includes liquidation costs.

### CAP-05 Counterparty and custody

Record who holds the capital at each stage, the custody model (self, exchange, broker, protocol contract, other), the counterparty's regulatory status for UAE residents (routed through FWK-61 class A4 or A5), and documented failure or freeze events. Unlicensed or unverifiable custodians set the COUNTERPARTY risk exposure to UNKNOWN.

### CAP-06 Fees, spread, financing, and slippage

Record trading fees, spread, financing or funding costs, borrow costs, withdrawal fees, and expected slippage, each documented. Net return after all of these is the only return figure used anywhere.

### CAP-07 Settlement and withdrawal

Map the settlement cycle and withdrawal path through S05 to S11 (FWK-30), including exchange or broker withdrawal limits, on-chain confirmation, fiat off-ramp availability for the UAE, and bank acceptance of the inbound transfer. Any undocumented stage makes G3 UNKNOWN.

### CAP-08 Market-regime dependency

State the market conditions under which the mechanism's evidence was generated and whether the evidence spans more than one regime. Evidence from a single regime caps FINANCIAL_EDGE claims at DIRECTIONAL.

### CAP-09 Evidence of persistent edge

A FINANCIAL_EDGE claim is VERIFIED_FACT or STRONGLY_SUPPORTED only with: out-of-sample results separate from any fitting period; results net of all CAP-06 costs; a stated sample size and period; a stated number of strategy variants tried, so that overfitting probability can be assessed; and class A sourcing. Absent any of these, edge is UNKNOWN. Edge is never inferred from a single profitable outcome, a backtest alone, or a promoter's claim.

### CAP-10 Backtest validity

Any backtest used as evidence records: data source and survivorship treatment; look-ahead controls; transaction-cost model; number of trials; and an overfitting assessment referencing the method in EVD-14. A backtest failing any item supports at most HYPOTHESIS.

### CAP-11 Repeatability after costs

A profitable outcome is never classified as a repeatable income mechanism. Repeatability requires evidence that the net-of-cost result recurred across independent periods or instances under CAP-08 and CAP-09. Investment, speculation, trading, arbitrage, yield, incentive capture, and earned income are recorded under distinct `mechanism_kind` values and are never merged.

### CAP-12 Probability of impairment and ruin

Where credible inputs exist (documented return distribution, position sizing, and loss limits), record the probability of capital impairment over 30 days and the probability of ruin for the deployed capital, with method and inputs. Where inputs are not credible, both are UNKNOWN and are shown as UNKNOWN, never as zero or as a favorable placeholder.

### CAP-13 Regulatory and tax routing

Every T2 or capital-risk T5 record is routed through FWK-61 classes A3, A4, A5, or A6 as applicable and through FWK-62. Tax treatment is PROFESSIONAL_TAX_REVIEW_REQUIRED by default.

### CAP-14 Reporting of capital-risk outcomes

Capital-risk records report: realized return range net of costs; recovered principal in its own field (FWK-32); expected return, which is UNKNOWN whenever edge is UNKNOWN; plausible maximum loss; and the probability fields of CAP-12. They appear in the T2 ordering and the cross-track table only, never in any income ordering (FWK-45). A capital-risk record's contribution to a 30-day band is limited to realized return net of costs under the conservative case.

### CAP-15 Capital-risk dashboard

D5 (STR-09) is built from `templates/capital-risk-dashboard.md` and lists every T2 and T5 record with the CAP-02, CAP-03, CAP-04, CAP-05, CAP-09, CAP-12, and CAP-14 fields. Any UNKNOWN is displayed as UNKNOWN.

### CAP-16 Wording cannot evade the protocol

Track assignment (FWK-10) and CAP-01 applicability are decided by the structured fields `capital_role`, `payer_type`, `settlement_mechanism`, and the dependency of cash on price movement, counterparty, or protocol incentives. Terms such as arbitrage, yield, staking, market-neutral, risk-free, passive, guaranteed, or spread capture have no effect on assignment. Any record with `capital_role: AT_RISK_CAPITAL` is T2 or T5 regardless of description, and this is tested (T-11).
