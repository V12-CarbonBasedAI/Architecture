# 03 Structure: the information architecture

Owner layer: Structure. This file owns taxonomies, identifiers, record depths, states, registers, dashboards, report organization, units, and schema conventions. Field-level schemas live in `templates/`. Process is in [02-system.md](02-system.md). Decision rules are in [04-framework.md](04-framework.md).

## Universe taxonomy

### STR-01 Discovery families and secondary dimensions

Sixteen discovery families define the search territory. They are exploration buckets, not endorsements and not survival quotas. Every L0 sighting carries exactly one primary family; a mechanism may additionally carry secondary families.

| ID | Family | Scope note |
|---|---|---|
| F01 | Digital products | Standardized digital goods sold to unknown buyers |
| F02 | Marketplaces and platform-native economies | Value exchanged inside a platform's own market and rules |
| F03 | Media and attention | Cash derived from audience attention via platform programs or sponsors |
| F04 | Marketing and distribution | Cash for delivering demand, traffic, or conversions to others |
| F05 | Software and automation | Tools, no-code products, bots, APIs, automations sold or metered |
| F06 | Data and research | Datasets, monitoring, curation, and research products |
| F07 | Licensing and intellectual property | Rights-based cash from digital IP |
| F08 | Digitally fulfilled commerce | Physical or hybrid goods with fulfilment executed by third parties |
| F09 | Referrals, incentives, and partner programs | Cash from referring, onboarding, or partner rewards |
| F10 | Online properties and digital assets | Websites, domains, accounts, and other transferable digital properties |
| F11 | Competitions, grants, and bounties | Prize, grant, and bounty cash |
| F12 | Regulated financial markets | Stocks, ETFs, currencies, derivatives, and other regulated instruments |
| F13 | Crypto and digital-asset systems | Digital assets, staking, protocol incentives, and related mechanisms |
| F14 | Pricing and market inefficiencies | Legal arbitrage, spread capture, and inefficiency exploitation |
| F15 | Hybrid opportunities | Mechanisms combining two or more families |
| F16 | Emerging or uncategorized opportunities | Mandatory catch-all; every entry here is reviewed for a possible new family |

Secondary dimensions are recorded on every mechanism record (STR-13) and drive track assignment (FWK-10), deduplication (FWK-20), and risk typing (FWK-13):

| Dimension | Allowed values |
|---|---|
| payer_type | CONSUMER, BUSINESS, PLATFORM, PROTOCOL, SPONSOR_OR_GRANTOR, MARKET_COUNTERPARTY, MIXED |
| operator_supplies | LABOR, CAPITAL, ASSET, DATA, ATTENTION, MIXED |
| capital_role | NONE, WORKING_CAPITAL, AT_RISK_CAPITAL |
| platform_dependency_class | NONE, SINGLE_PLATFORM, MULTI_PLATFORM, CUSTODIAL |
| settlement_mechanism | DIRECT_PROCESSOR, PLATFORM_PAYOUT, EXCHANGE_OR_BROKER, ON_CHAIN, BANK_TRANSFER, MIXED |
| horizon_class | H30, H90, H365, H_OPEN |

### STR-02 Identifier scheme

Identifiers are immutable once issued, zero-padded, and never reused after merge or rejection.

| Prefix | Record | Notes |
|---|---|---|
| SWP-nnn | Discovery sweep | One per complete or partial sweep |
| OPP-nnnn | Opportunity candidate record | One per candidate at any depth L0 to L3 |
| MEC-nnnn | Mechanism record | Deduplication unit; one per unique signature |
| CLM-nnnnn | Claim | Row in the claim-evidence matrix |
| SO-nnnnn | Source | Row in the source register |
| ASM-nnnn | Assumption | Assumption register |
| CON-nnnn | Contradiction | Contradiction log |
| UNC-nnnn | Uncertainty | Uncertainty register |
| REJ-nnnn | Rejection | Rejection log |
| QUA-nnnn | Quarantine | Quarantine log |
| REG-nnnn | Regulatory verification | Regulatory verification log |
| DEC-nnnn | Decision | Decision log |
| EXP-nnnn | Validation experiment | Embedded in L3 record and decision log |
| POR-nnn | Portfolio | Portfolio feasibility record |
| FIX-nnn | Controlled hypothetical architecture fixture | `tests/` only (STR-14) |

### STR-03 Research depths

Four depths. A record may only deepen after the prior depth's required fields are complete. Fields are defined in `templates/opportunity-record.md`.

| Depth | Name | Purpose | Required content |
|---|---|---|---|
| L0 | Sighting | Capture breadth cheaply | OPP id, sweep id, primary family, one-line mechanism description, source pointer, date |
| L1 | Preliminary screen | Cheap elimination | Mechanism signature (STR-13), MEC link, dedup result, track assignment, obvious prohibition and ethical check, basic availability, laptop/solo/people-dependency check, early gate values for G1 to G7 where determinable |
| L2 | Investigation record | Resolve every applicable fatal gate | Claim-evidence matrix rows for every decision-critical claim, payment and settlement path, cold-start and demand evidence, feasibility fields, jurisdiction routing output, dependency map, evidence-sufficiency review, freshness status |
| L3 | Decision record | Decide and prepare for prioritization | Gate results, decision state, confidence band, risk class, 30-day cash compatibility band, timing model, economic model, capital-risk model where applicable, validation experiment design, prioritization result, reverification triggers |

L2 exists to resolve fatal gates; a record is not blocked from L2 by an UNKNOWN gate. Only records with every applicable fatal gate at PASS may reach prioritization (FWK-47).

### STR-04 Decision state machine

| State | Meaning |
|---|---|
| DISCOVERED | L0 exists |
| MERGED | Duplicate of another MEC; terminal, points to survivor |
| SCREENED | L1 complete, no stop condition triggered |
| PROHIBITED | Verified legal prohibition (G1 FAIL) or ethical exclusion (G7 FAIL); terminal for current evidence |
| REJECTED | Any other fatal gate FAIL, or track-specific gate FAIL, or portfolio-only rejection noted on POR |
| QUARANTINED | Any fatal gate or decision-critical claim UNKNOWN; carries Open/TBD subtype (STR-05) |
| CONDITIONAL | All fatal gates PASS, one or more conditional gates open |
| ELIGIBLE | All fatal gates PASS, all conditional gates closed, L3 complete |
| VALIDATION_PENDING | Validation experiment designed or running |
| VALIDATED | Experiment supported the tested claim |
| INVALIDATED | Experiment contradicted the tested claim |

Transitions and triggers:

| From | To | Trigger |
|---|---|---|
| DISCOVERED | MERGED | FWK-20 signature equality |
| DISCOVERED | SCREENED | L1 complete, no stop |
| DISCOVERED or SCREENED | PROHIBITED | G1 or G7 FAIL verified |
| SCREENED | REJECTED | G2, G4, G5, G6 FAIL at L1 |
| SCREENED | QUARANTINED | Any gate UNKNOWN at end of L1 or L2 |
| SCREENED | CONDITIONAL | L2 and L3 complete, all fatal PASS, conditional open |
| SCREENED | ELIGIBLE | L2 and L3 complete, all fatal PASS, all conditional closed |
| QUARANTINED | SCREENED | Blocking item resolved per FWK-66; resume at the producing step |
| QUARANTINED | REJECTED or PROHIBITED | Blocking item resolved to FAIL |
| CONDITIONAL | ELIGIBLE | Last conditional gate closed |
| CONDITIONAL or ELIGIBLE | QUARANTINED | Freshness expiry (FWK-60) or contradiction reopening (FWK-65) turns a gate UNKNOWN |
| ELIGIBLE | VALIDATION_PENDING | Experiment designed per FWK-35 |
| VALIDATION_PENDING | VALIDATED or INVALIDATED | Experiment result recorded |
| Any non-terminal | REJECTED | Track-specific gate FAIL at L3 |
| REJECTED or PROHIBITED | SCREENED | Reopened per FWK-65 with new admissible evidence; prior decision preserved |

Every transition writes a DEC record.

### STR-05 Open/TBD status taxonomy

Open/TBD is a controlled status, never a placeholder. Each Open/TBD item carries exactly one subtype:

| Subtype | Meaning | Resolver |
|---|---|---|
| OPERATOR_INPUT_REQUIRED | Depends on an operator fact not supplied | Operator |
| FURTHER_RESEARCH_REQUIRED | Admissible evidence likely exists and has not been gathered | Researcher |
| PLATFORM_CONFIRMATION_REQUIRED | Only the platform can confirm (eligibility, limits, approval) | Platform |
| PROFESSIONAL_LEGAL_REVIEW_REQUIRED | Needs qualified legal interpretation for the operator's facts | Professional |
| PROFESSIONAL_TAX_REVIEW_REQUIRED | Needs qualified tax interpretation | Professional |
| EVIDENCE_UNAVAILABLE | Credible evidence does not exist or cannot be accessed | None; stays unknown |

A released architecture contains no Open/TBD item without a subtype, and no unfinished placeholder text.

### STR-06 Analytical tracks

| Track | Name | Cash arises from |
|---|---|---|
| T1 | Earned digital income | Delivering value to a payer in a standardized transaction |
| T2 | Capital-risk returns | Placing capital at risk of loss beyond fees; investment, speculation, trading, arbitrage with capital exposure, yield |
| T3 | Rewards and incentive income | Referral, reward, grant, bounty, competition, or protocol incentive paid by a sponsor or platform |
| T4 | Longer-horizon asset creation | Building an asset whose cash arrives beyond the 30-day horizon by design |
| T5 | Hybrid | Two or more of the above; inherits every component track's controls |

Track assignment is a Framework rule (FWK-10). Tracks are compared only within themselves for ordering (FWK-45).

### STR-07 Project-level registers

Registers are kept once per research project, not per candidate. Each has a template with a schema.

| Register | Template |
|---|---|
| Mechanism registry | `templates/mechanism-registry.md` |
| Claim-evidence matrix | `templates/claim-evidence-matrix.md` |
| Source register (includes freshness fields) | `templates/source-register.md` |
| Query, coverage, and saturation log | `templates/query-coverage-saturation-log.md` |
| Assumption register | `templates/assumption-register.md` |
| Contradiction log | `templates/contradiction-log.md` |
| Uncertainty register (includes research limitations) | `templates/uncertainty-register.md` |
| Rejection log | `templates/rejection-log.md` |
| Quarantine log | `templates/quarantine-log.md` |
| Regulatory verification log | `templates/regulatory-verification-log.md` |
| Decision log | `templates/decision-log.md` |
| Capital-risk dashboard | `templates/capital-risk-dashboard.md` |
| Portfolio feasibility | `templates/portfolio-feasibility.md` |

Per-candidate content lives in one file per candidate built from `templates/opportunity-record.md` and its section fragments.

### STR-08 Claim status vocabulary

Every material claim carries exactly one status. Assignment rules are EVD-06.

VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, INFERENCE, ASSUMPTION, HYPOTHESIS, CONTRADICTION, UNKNOWN, OUTDATED.

Decision-critical claim classes (used by FWK-12 and EVD-03): LEGALITY, PLATFORM_ELIGIBILITY, PAYOUT_PATH, FEES_AND_COSTS, DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, FINANCIAL_EDGE, DEPENDENCY_AVAILABILITY.

### STR-09 Dashboards

Five dashboards are produced from registers. None ranks across tracks.

| Dashboard | Rows | Columns |
|---|---|---|
| D1 Gate status | Every OPP | State, G1 to G7 values, blocking item and Open/TBD subtype |
| D2 Evidence confidence | Every OPP at L2 or deeper | Band (FWK-12), decision-critical claims by status, independent corroboration count |
| D3 Risk | Every OPP at L3 | Risk class (FWK-13), risk types present, max plausible loss range, exposure versus limit |
| D4 30-day cash | Every OPP at L3 | Band (FWK-14), conservative, base, best day of usable cash, conservative net collectible cash range, recovered principal shown separately |
| D5 Capital-risk dashboard | Every T2 and T5 OPP | Fields of `templates/capital-risk-dashboard.md` |

Quarantined and rejected records appear on D1 with reasons. The portfolio view is a section of D4 built from POR records.

### STR-10 Report organization

A research report follows this order and omits nothing: scope and Day 0; coverage audit and saturation status per family; five dashboards; per-track orderings and bounded scenario tables; cross-track disclosure table; quarantine list with subtypes; rejection and prohibition list; assumption, contradiction, and uncertainty summaries; source freshness status; validation experiments and results; portfolio results; five-way validation status; limitations including the non-exhaustiveness statement (SYS-06) and any scalability notes, which are reported here only and never consumed by any ordering rule (FWK-15).

### STR-11 Units, currencies, dates, and numeric provenance

- Money is stored with an ISO 4217 code and reported in AED with the conversion source and date. Original currency is retained.
- Dates are ISO 8601. Elapsed time is in calendar days. Effort is in hours and is a separate field from elapsed time.
- Every quantitative field is a range `{low, high}` with a `provenance_class` from: MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN. STIPULATED is legal only inside `tests/`.
- Reports show at most two significant figures (FWK-63).

### STR-12 Template schema convention

Every template begins with YAML front matter containing `template`, `version`, `owner_control`, and a `fields` list. Each field has `name`, `type`, `required`, and `consumer`. `consumer` lists the control IDs that read the field. A field with no decision consumer must declare `consumer: [admin]` and a `justification`. Allowed values and units are declared where applicable. The structural validator (`tests/validate.py`) checks every consumer ID exists and every admin field has a justification.

### STR-13 Mechanism record structure

A mechanism record holds the signature that identifies it and the variants that share it.

Signature fields: `value_delivered` (free text normalized to a controlled phrase), `payer_type`, `operator_supplies`, `payment_rail`, `settlement_mechanism`, `platform_dependency_class`. Two records with equal signatures are the same mechanism (FWK-20). Variant fields, which do not affect identity: platform name, geography, format, pricing model, tooling. Each MEC also carries: primary family, secondary families, track, list of OPP ids, sighting count, first and last seen dates, saturation contribution.

### STR-14 Fixture namespace isolation

Fixture identifiers use `FIX-` followed by three digits and exist only in `tests/`. Fixture records use `provenance_class: STIPULATED`. No real-research register may contain the string pattern `FIX-` followed by three digits, and no real record may carry STIPULATED provenance. The validator enforces both.
