# 02 System: the operating process

Owner layer: System. This file owns process only. Data shapes are in [03-structure.md](03-structure.md). Decision rules are in [04-framework.md](04-framework.md), [05-source-governance.md](05-source-governance.md), and [06-capital-risk-protocol.md](06-capital-risk-protocol.md). Where a step below applies a rule, it cites the rule ID and does not restate it.

## Stage overview

### SYS-01 Operating stages

Each stage has a purpose, inputs, actions, required evidence, outputs, responsible perspective (SYS-02), pass/conditional/fail conditions, and rework rule. Stages run in this order for a research cycle. A later stage may send a record back to an earlier one; it may never skip forward.

| # | Stage | Purpose | Inputs | Outputs | Pass | Conditional | Fail and rework |
|---|---|---|---|---|---|---|---|
| 1 | Discovery sweep | Populate the universe broadly | 16 families (STR-01), lenses (SYS-04), query log | L0 sightings | Sweep complete per SYS-03 | Budget exhausted before completion: mark COVERAGE_INCOMPLETE | Missing family or lens: repeat sweep for the gap |
| 2 | Discovery freeze | Stop discovery before filtering | L0 sightings | Mechanism records (MEC), coverage audit | Dedup (FWK-20) and coverage audit (FWK-21) complete | Family below saturation (SYS-06): note and continue | Dedup skipped: return to stage 2 |
| 3 | Preliminary screen (L1) | Cheap elimination of obvious prohibition or infeasibility | MEC records | L1 records with early gate values | Steps 1 to 5 of SYS-07 done for every MEC | Any UNKNOWN: quarantine per SYS-10 | Verified prohibition: PROHIBITED, stop |
| 4 | Investigation (L2) | Resolve all applicable fatal gates | L1 records not prohibited | L2 records, claim-evidence matrix rows, sources | Steps 6 to 10 of SYS-07 done | Remaining UNKNOWN: quarantine with resolver class | Evidence insufficient: return to verification (SYS-08) |
| 5 | Decision (L3) | Produce decision state and prioritization inputs | L2 records with all gates valued | L3 records, decision log | Steps 11 to 13 of SYS-07 done | Conditional gates open: CONDITIONAL | Any fatal FAIL: REJECTED or PROHIBITED |
| 6 | Prioritization | Order eligible candidates without composite scoring | L3 ELIGIBLE records | Per-track orderings, scenario tables (FWK-40) | Every eligible record placed or marked incomparable | Operator inputs missing: scenario-dependent output only | Ineligible record found in ordering: remove and log |
| 7 | Validation | Run minimum legal validation experiments | Eligible records with designed experiments | Experiment results, updated claims | Experiment meets FWK-35 | Result ambiguous: VALIDATION-PENDING | Experiment violates FWK-35: void result |
| 8 | Portfolio assembly | Test combinations | ELIGIBLE or VALIDATED records | Portfolio record (POR) | FWK-50 passes | Operator limits OPERATOR_INPUT_REQUIRED: CONDITIONAL with breakpoints | FWK-50 fails: portfolio rejected |
| 9 | Review and red team | Independent challenge | Frozen baseline | Findings register | All findings dispositioned | Medium or low findings deferred with owner | Critical or high open: no release |
| 10 | Reporting | Publish state | All registers | Dashboards (STR-09), report (STR-10), five-way status | Every unknown visible | | Unknown hidden or defaulted: defect |

### SYS-02 Roles and perspectives

Six perspectives exist. One agent may hold several, but the adversary and the blinded evaluator must not have authored the material they review.

| Perspective | Responsibility |
|---|---|
| Discoverer | Runs sweeps, writes L0 and L1, proposes mechanism signatures. |
| Verifier | Extracts claims, classifies sources, runs contradiction searches, assigns claim status per EVD-06. |
| Jurisdiction reviewer | Runs the FWK-61 question matrix, files regulatory verification log entries, flags professional-review items per FWK-62. |
| Capital-risk reviewer | Applies the full CAP protocol to every T2 and T5 record and to any record flagged by CAP-16. |
| Adversary | Attempts to falsify approvals and rejections, searches for negative evidence, runs the wording test (FWK-64). |
| Integrator | Owns record integrity, state transitions (STR-04), registers, versioning (SYS-13). |

Agreement among perspectives is an internal consistency check and never counts as evidence (EVD-05).

## Discovery

### SYS-03 Discovery sweep definition

A sweep is complete only when all of the following are logged in the query and coverage log:

1. Every one of the 16 families in STR-01 has been searched under every one of the three lenses in SYS-04.
2. Each family-lens cell records at least the minimum query set: one mechanism query, one payer query, one platform-policy query, one negative-evidence query (SYS-04), and one recency-limited query. Query wording is logged verbatim with the date.
3. Every sighting is recorded as an L0 record (STR-03) with its family and a provisional mechanism description.
4. The sweep identifier, start date, end date, and researcher perspective are recorded.

A sweep that stops early is logged as PARTIAL and cannot count toward saturation (SYS-06).

### SYS-04 Search lenses and negative-evidence query classes

Three lenses are mandatory in every family:

- **Mechanism and payer lens.** Who pays, for what, through which rail, and what the operator must supply.
- **Adjacent and emerging lens.** Neighbouring mechanisms, new platform programs, recently changed policies, and mechanisms named differently in other markets or languages.
- **Contrary and failure lens.** Evidence of bans, payout holds, account closures, regional unavailability, policy reversals, fraud, lawsuits, and operator failure accounts.

The negative-evidence query class is: mechanism or family term combined with at least two of: failed, banned, suspended, payout hold, account closed, not available, UAE, scam, refund, chargeback, lawsuit, regulator. Results feed the contradiction log and EVD-09.

### SYS-05 Discovery freeze checkpoint

No screening, scoring, or filtering of any kind starts until:

1. Every L0 sighting has been assigned to a mechanism record or explicitly logged as a duplicate under FWK-20.
2. The category coverage audit (FWK-21) has been completed and its output recorded.
3. Researcher-familiarity bias, search-popularity bias, and emerging-mechanism gaps have been reviewed and logged as findings or as "none found" with the reviewer perspective named.

The freeze is recorded in the decision log as DEC record type DISCOVERY_FREEZE with the sweep identifiers it covers.

### SYS-06 Research saturation and stopping rule

Saturation is judged per family, not globally. A family is SATURATED when two consecutive complete sweeps (SYS-03) produce zero new mechanism records after deduplication (FWK-20) and zero taxonomy extensions in that family. A family that has not met this test is UNSATURATED. If the research budget is exhausted before every family is saturated, the coverage audit records COVERAGE_INCOMPLETE with the list of unsaturated families and the reason. Saturation is a stopping rule for a bounded research cycle. It never supports a claim of exhaustive discovery, and every report must say so in the limitations section.

## Evaluation

### SYS-07 Evaluation sequence

Every mechanism record is evaluated in this fixed order. The depth column names the research depth (STR-03) at which the step is normally completed. A step may not be skipped. Rules applied at each step are cited.

| Step | Action | Depth | Rules applied | Stop condition |
|---|---|---|---|---|
| 1 | Mechanism identity and deduplication | L1 | FWK-20, STR-13 | Duplicate: merge and stop |
| 2 | Analytical-track assignment | L1 | FWK-10, CAP-01, CAP-16 | None |
| 3 | Obvious prohibition and ethical exclusion | L1 | FWK-02, FWK-08, FWK-09 | Verified prohibition: PROHIBITED, evaluation ends |
| 4 | Basic UAE, platform, account, monetization, withdrawal availability | L1 | FWK-03 | FAIL: REJECTED |
| 5 | Laptop-only, solo, and people-dependency eligibility | L1 | FWK-05, FWK-06 | FAIL: REJECTED |
| 6 | Payment, settlement, and withdrawal path | L2 | FWK-04, FWK-30 | FAIL: REJECTED |
| 7 | Cold-start distribution and demand evidence | L2 | FWK-36, EVD-10 | None (feeds conditional gates) |
| 8 | Time, capital, skill, and workload feasibility | L2 | FWK-38, FWK-37 | None (feeds feasibility and risk) |
| 9 | Detailed jurisdiction and regulatory verification | L2 | FWK-61, FWK-62, EVD-13 | Material unresolved legal question: QUARANTINED with subtype PROFESSIONAL_LEGAL_REVIEW_REQUIRED, overrides everything |
| 10 | Evidence-sufficiency review | L2 | EVD-03, EVD-06, EVD-07, EVD-09, FWK-60 | Decision-critical claim UNKNOWN: QUARANTINED |
| 11 | 30-day collectible-cash determination | L3 | FWK-30, FWK-31, FWK-32, FWK-33, FWK-34, FWK-14 | None |
| 12 | Track-specific gates | L3 | FWK-11 and, for T2 and T5, CAP-02 to CAP-14 | Track gate FAIL: REJECTED |
| 13 | Prioritization eligibility | L3 | FWK-47 | Not eligible: stays CONDITIONAL or QUARANTINED |

Track assignment (step 2) always precedes track-specific evaluation (step 12). A step 3 stop is final for the current evidence; reopening follows FWK-65.

### SYS-08 Verification procedure

For every record at L2 or deeper:

1. Extract each decision-relevant claim into the claim-evidence matrix with its claim class (EVD-03).
2. Register each supporting source in the source register with tier (EVD-01), independence class (EVD-04), publisher incentive, upstream origin, and dates.
3. Run the minimum contradiction search (EVD-09) and log results in the contradiction log, including "none found" with queries used.
4. Check claim-source fit (EVD-10). A source that cannot support the claim class is recorded but marked NOT_APPLICABLE for that claim.
5. Assign the claim status per EVD-06. A performance claim without a denominator is capped per EVD-07.
6. Record any assumption in the assumption register and any unresolved item in the uncertainty register with its Open/TBD subtype (STR-05).

### SYS-09 Reverification procedure

Before any transition into ELIGIBLE, VALIDATED, or into a published ordering, the integrator checks every platform and regulatory source against its freshness limit (FWK-60). Expired sources are re-fetched and re-dated. If a re-fetch is impossible, the claim status becomes OUTDATED and the affected gate returns UNKNOWN. Reverification triggers are also raised by: a contradiction log entry, a platform policy change notice, a regulatory change notice, a validation experiment result, or an operator input change.

### SYS-10 Escalation and quarantine handling

When a gate or decision-critical claim is UNKNOWN, the integrator files a quarantine log entry naming: the missing item, the Open/TBD subtype (STR-05), the resolver class (research, platform confirmation, operator, professional legal, professional tax, or unavailable evidence), the recheck date, and the exit condition (FWK-66). Quarantined records appear on every dashboard with their blocking item. They never enter an ordering.

## Review, revision, versioning

### SYS-11 Review and red-team procedure

Each architecture version, and each completed research cycle, receives six bounded reviews against a frozen baseline (SYS-13): evidence governance; universe taxonomy and deduplication; financial-market and crypto risk; platform, payout, and UAE jurisdiction; operational feasibility and cold-start distribution; adversarial red team with blinded repeatability. Reviewers see only the frozen baseline. The blinded evaluator receives fixtures without expected outcomes. Each finding is logged with an RT identifier, severity (critical, high, medium, low), affected control ID, counterexample or evidence, proposed correction, and residual risk. Synthesis waits for every review. Reviewer agreement is recorded as consistency only (EVD-05).

### SYS-12 Revision and regression procedure

Corrections are applied to the working copy, never to the frozen baseline. After any correction the full fixture suite and the structural validator run again. Original results are preserved in the results file with their version label; corrected results are appended, never overwritten. A correction that changes a fixture's expected outcome requires a logged justification and a red-team re-review of that fixture.

### SYS-13 Versioning and freeze procedure

A version is frozen by mirroring the complete file set into `versions/<version>/` and writing a manifest of SHA-256 hashes for every file. The manifest is validated before reviews start and before release. The changelog records every version with the findings it addressed. Content inside a frozen mirror is never edited.

### SYS-14 Validation experiment procedure

A validation experiment is designed on the L3 record before it runs, using the constraints in FWK-35. The design records purpose, the specific claim it tests, cost cap, stop condition, reversibility, and compliance checks. Results update the claim-evidence matrix and may move the record between VALIDATION-PENDING, VALIDATED, and INVALIDATED (STR-04). An experiment result is evidence about the tested claim only.

### SYS-15 Portfolio assembly procedure

Portfolios are assembled only from ELIGIBLE or VALIDATED records. The integrator fills the portfolio feasibility template, applies FWK-50, and records the result as a POR record. Where operator limits are Open/TBD, the result is CONDITIONAL and reports the limit values at which the portfolio would fail.

### SYS-16 Fixture quarantine procedure

Fixtures exist only under `tests/`. No fixture identifier, stipulated fact, number, or outcome may be copied into any real-research record, register, dashboard, or report. The structural validator checks for fixture identifiers outside `tests/` and `versions/`. Any occurrence is a critical defect.

### SYS-17 Reporting procedure

Every published research output includes: the five dashboards (STR-09), the per-track orderings and scenario tables (FWK-40 to FWK-46), the complete quarantine and rejection lists, the unresolved-variables list by Open/TBD subtype, the source freshness status, the coverage audit with saturation status per family, and the five-way validation status (logically validated, externally grounded, unvalidated until real research, operator input required, professional review required). No output omits unknowns.
