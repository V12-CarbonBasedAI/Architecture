# 05 Source governance (Framework module)

Owner layer: Framework module. This file owns evidence admissibility, claim status, corroboration, survivorship, contradiction search, claim-source fit, legal-source classification, and methodological grounding. Field shapes are in `templates/source-register.md` and `templates/claim-evidence-matrix.md`. Process steps are in [02-system.md](02-system.md) (SYS-08, SYS-09).

### EVD-01 Source hierarchy and permitted uses

| Tier | Source type | Permitted use |
|---|---|---|
| 1 | Binding laws and regulations | Any claim class; required for LEGALITY |
| 2 | Official regulatory guidance | Any claim class; required for LEGALITY where tier 1 is silent |
| 3 | Current platform policies, terms, fees, eligibility, settlement, and payout documentation | PLATFORM_ELIGIBILITY, PAYOUT_PATH, FEES_AND_COSTS, DEPENDENCY_AVAILABILITY; never for commercial results |
| 4 | Original datasets and transparent primary evidence | DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, FINANCIAL_EDGE |
| 5 | Strong independent research and reporting | Same as tier 4, with the upstream origin traced |
| 6 | Transparent practitioner evidence | Directional support only, and only when method, dates, costs, and denominator are disclosed |
| 7 | Community and social material | Discovery only; never supports a claim status above HYPOTHESIS |

### EVD-02 Rejected source types

The following are recorded in the source register with `admissible: false` and support no claim: affiliate pages presented as independent reviews; course, coaching, or funnel content; income screenshots without a verifiable ledger export; AI-generated content farms; circularly cited statistics whose origin cannot be traced; undated SEO listicles; untraceable earnings claims. Detection fields in the source register: `publisher_incentive`, `affiliate_links_present`, `sells_course_or_coaching`, `dated`, `upstream_source_id`.

### EVD-03 Claim class minimum admissible tier

| Claim class | Minimum tier | Additional requirement |
|---|---|---|
| LEGALITY | 1 or 2 | REG entry within freshness; professional review where FWK-62 applies |
| PLATFORM_ELIGIBILITY | 3 | Within 30-day freshness; account type stated |
| PAYOUT_PATH | 3 | Every stage S05 to S11 documented |
| FEES_AND_COSTS | 3 | Within freshness |
| DEMAND | 4 or 5 | Denominator stated (EVD-07) |
| EARNINGS_OR_CONVERSION | 4 or 5 | Denominator stated; costs and dates disclosed |
| DISTRIBUTION_PERFORMANCE | 4 or 5 | Cold-start condition satisfied (EVD-10) |
| FINANCIAL_EDGE | 4 | Out-of-sample evidence per CAP-09 |
| DEPENDENCY_AVAILABILITY | 3 | Or logged platform confirmation |

A claim supported only by sources below its minimum tier is UNKNOWN for gate purposes, whatever its apparent plausibility.

### EVD-04 Independence classification

Each source supporting a claim is classified:

- Class A: genuinely independent underlying source or dataset, with its own data collection or primary observation.
- Class B: publication repeating, summarizing, or interpreting the same original evidence as another registered source. Class B sources share an `upstream_source_id`.
- Class C: agreement between internal model, agent, or reviewer assessments.

Only class A sources count toward independent corroboration. Two class B sources with the same upstream count as one. Class C never counts. The register tracks shared datasets, ownership, citation origin, incentives, and methodological dependence.

### EVD-05 Internal agreement is not evidence

Agreement among subagents, reviewers, or repeated model passes is a consistency check on the architecture's application. It is recorded as class C and never raises a claim status, band, or gate value.

### EVD-06 Claim status assignment

| Status | Assign when |
|---|---|
| VERIFIED_FACT | Supported by a tier 1 to 3 source of the required class within freshness, with no unresolved contradiction |
| STRONGLY_SUPPORTED | Supported by at least two class A sources at or above the minimum tier, consistent with each other, no unresolved contradiction |
| DIRECTIONAL | Supported by one class A source at or above the minimum tier, or by tier 6 evidence meeting its disclosure requirement |
| INFERENCE | Derived by reasoning from verified or supported claims, with the reasoning logged |
| ASSUMPTION | Adopted without evidence; must have an ASM entry and can never be favorable to the candidate without a logged justification |
| HYPOTHESIS | Proposed for testing; no supporting evidence yet |
| CONTRADICTION | Admissible sources disagree materially; unresolved until adjudicated in the contradiction log |
| UNKNOWN | No admissible source at the required tier |
| OUTDATED | Supporting sources exceed their freshness limit (FWK-60) |

Claim type, evidence status, and confidence band are separate fields and never merged.

### EVD-07 Survivorship and denominator control

Every DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, and FINANCIAL_EDGE claim records a `denominator` (the population from which the reported outcomes were drawn) and a `failure_base_rate_search` result. If the denominator is unknown the claim carries DENOMINATOR_UNKNOWN and its status is capped at DIRECTIONAL. A claim drawn only from successful cases with no failure search is capped at HYPOTHESIS.

### EVD-08 Screenshots and earnings claims

A screenshot or self-reported figure carries zero evidential weight unless accompanied by a verifiable ledger export, platform statement, or dataset that can be traced. Even then it is tier 6 and cannot exceed DIRECTIONAL.

### EVD-09 Contradiction and negative-evidence search minimum

For every record at L2, the verifier runs and logs at least: the SYS-04 negative-evidence query class for the mechanism; a search for policy reversals or regional restrictions for each platform dependency; a search for regulatory actions in each applicable jurisdiction; and a search for operator failure accounts. Each search is logged with queries, dates, and result, including "none found". Conditional gate C8 stays open until this is logged.

### EVD-10 Claim-source fit

A source supports only the claim classes its tier permits (EVD-01). Official policy documentation establishes eligibility, fees, and timing, never typical commercial results. Evidence from operators with a pre-existing audience, brand, network, or capital advantage does not support DISTRIBUTION_PERFORMANCE or DEMAND claims for a cold-start operator. Evidence from a different jurisdiction does not support PLATFORM_ELIGIBILITY or LEGALITY for the UAE. Mismatched sources are recorded as NOT_APPLICABLE for that claim.

### EVD-11 Dating and recency

Every source records publication date, last-verified date, and access date. An undated source is tier 7 at most. Recency is judged against FWK-60 limits.

### EVD-12 Quantity is not quality

Source count, page count, document length, and research effort never raise a claim status, band, or gate. A claim with many sources of class B and none of class A is at most DIRECTIONAL. Completion is judged by coverage of decision-critical claims, claim-source fit, contradiction search, and recency, never by volume.

### EVD-13 Legal-source classification and non-inheritance

Every legal or compliance source is classified as one of: BINDING_LAW, OFFICIAL_GUIDANCE, PLATFORM_POLICY, PROFESSIONAL_COMMENTARY, RESEARCHER_INTERPRETATION, with issuing authority, jurisdiction, activity, effective date, access date, applicability, and uncertainty recorded. Commentary and interpretation never inherit the authority of binding law. Platform permission never establishes legality. Where an operator-specific interpretation is needed, FWK-62 applies.

### EVD-14 Methodological references and adaptation limits

The following external references informed design decisions. Each is an adaptation, not external validation of this architecture, and each must be re-accessed and dated when cited in a research cycle.

| Reference | Used for | Adaptation limit |
|---|---|---|
| Cochrane Handbook, evidence assessment guidance | Claim-status and corroboration concepts | Designed for clinical evidence; tiers here are an analogy |
| UK Government Analysis Function, introductory guide to multi-criteria decision analysis | Reasons for avoiding a composite score; dominance and lexicographic ordering | Applied to ordering without weights |
| US GAO Schedule Assessment Guide | Critical-path discipline for the timing model | Scaled down to an 11-stage model |
| Bailey, Borwein, López de Prado, Zhu, probability of backtest overfitting | CAP-09 and CAP-10 edge and backtest standards | Requires inputs that many candidates will lack; then edge is UNKNOWN |

Links were supplied in the planning stage and were not fetched during architecture construction; their availability is FURTHER_RESEARCH_REQUIRED at first use.
