# Changelog

## Design parameters (changed only by version)

| Parameter | Value | Rationale | Control |
|---|---|---|---|
| Risk near-limit threshold | 80 percent of an operator limit | Flags exposures approaching a limit before they exceed it | FWK-13 |
| Freshness limit, platform sources | 30 days | Platform terms change frequently and silently | FWK-60 |
| Freshness limit, regulatory sources | 90 days | Regulatory change follows announcement cycles | FWK-60 |
| Freshness limit, datasets and independent research | 365 days | Slower-moving evidence | FWK-60 |
| Freshness limit, practitioner and community material | 180 days | Discovery use only | FWK-60 |
| Maximum published scenarios per report | 8 | Bounds scenario explosion | FWK-44 |
| Saturation rule | Two consecutive complete sweeps with zero new mechanisms per family | Bounded stopping rule, not exhaustiveness | SYS-06 |
| Weekly hours classes | H1 under 10, H2 10 to 25, H3 over 25 | Coarse bands avoid false precision | FWK-44 |

## Versions

### V0.1 (2026-09-17)

Initial architecture built from the audited and corrected implementation plan with all 22 corrections and 11 clarifications applied. Frozen to `versions/v0.1/` with a SHA-256 manifest before review.

### V1.0

Pending: created only after six reviews, fixture and structural runs, red-team findings, corrections, full regression, and a passing release audit. Findings addressed are listed in `tests/red-team-findings.md`.
