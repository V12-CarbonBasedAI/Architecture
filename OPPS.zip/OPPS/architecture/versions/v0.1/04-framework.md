# 04 Framework: the decision rules

Owner layer: Framework. This file owns gates, track assignment, bands, deduplication, timing and cash models, feasibility, prioritization, portfolio feasibility, freshness, jurisdiction routing, precision, and reopening. Evidence admissibility rules are in [05-source-governance.md](05-source-governance.md) (EVD). Capital-risk rules are in [06-capital-risk-protocol.md](06-capital-risk-protocol.md) (CAP). Process is in [02-system.md](02-system.md). Field definitions are in [03-structure.md](03-structure.md) and `templates/`.

## Gate semantics

### FWK-01 Gate values and the unknown rule

Every gate takes exactly one of PASS, FAIL, UNKNOWN. A gate is PASS only when admissible evidence (EVD-03) within its freshness limit (FWK-60) satisfies the pass condition. FAIL requires admissible evidence of the fail condition. Everything else is UNKNOWN. UNKNOWN on any fatal gate places the record in QUARANTINED with an Open/TBD subtype (STR-05). UNKNOWN is never treated as PASS, never averaged, never offset by any band, score, or attractiveness. A fatal FAIL cannot be rescued by any other assessment.

Gates are evaluated cheapest-first in the order of SYS-07. Gates G1 to G7 are fatal. Conditional gates C1 to C8 (FWK-11) are not fatal but block ELIGIBLE.

### FWK-02 G1 Legality

Fatal. Applies to the activity in each applicable jurisdiction: operator residence, company jurisdiction, customer jurisdiction where the activity is regulated on the customer side, and platform jurisdiction where the platform imposes it.

- Evidence required: a REG entry per applicable jurisdiction citing a tier 1 or tier 2 source (EVD-01) within freshness, or a tier 1 or 2 source establishing that the activity is not restricted.
- PASS: no prohibition or licensing requirement found that the operator cannot meet, for every applicable jurisdiction, with each REG entry within freshness.
- FAIL: a binding prohibition, or a licensing requirement the operator verifiably does not hold, in any applicable jurisdiction. Result state PROHIBITED.
- UNKNOWN: any applicable jurisdiction unchecked, any material unresolved legal question (FWK-62), or any REG entry expired. Result state QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED or FURTHER_RESEARCH_REQUIRED.
- False positives: treating professional commentary or platform permission as legality (EVD-13); assuming free-zone license scope covers the activity when scope is Open/TBD.
- False negatives: rejecting on a foreign rule that does not apply, or on an outdated rule.
- Reverification triggers: REG expiry, regulatory change notice, change of operator residence or company facts.

### FWK-03 G2 Platform and account availability

Fatal. Three sub-checks, each valued separately: (a) sign-up available to a UAE resident or UAE entity; (b) the monetization program is available to that account; (c) withdrawal is available to a rail the operator can use from the UAE.

- Evidence required: tier 3 platform documentation within freshness for each sub-check, or platform confirmation logged as a source.
- PASS: all three PASS for the account type the operator will use.
- FAIL: any sub-check documented as unavailable for the UAE or for the account type. Result state REJECTED.
- UNKNOWN: any sub-check undocumented, or account type (personal versus company) is OPERATOR_INPUT_REQUIRED and availability differs by account type. Result QUARANTINED with PLATFORM_CONFIRMATION_REQUIRED or OPERATOR_INPUT_REQUIRED.
- False positives: a site being viewable from the UAE; sign-up being possible while monetization is region-locked; withdrawal being possible only to unsupported rails.
- False negatives: an outdated regional-availability list.
- Reverification triggers: platform policy source expiry, any contradiction log entry mentioning regional availability.

### FWK-04 G3 Payout path to usable operator-controlled cash

Fatal. A documented path must exist from payment capture to an operator-controlled account from which money can be spent or transferred without further condition.

- Evidence required: documented values for stages S05 to S11 (FWK-30) with sources, including thresholds, holds, cycles, and withdrawal rails.
- PASS: every stage documented and the best-case total from Day 0 to S11 is 30 calendar days or fewer, with any payout threshold attainable by Day 30 under at least one documented case.
- FAIL: no operator-controlled rail exists; or the best-case total exceeds 30 days; or a payout threshold or eligibility condition cannot be met by Day 30 under any case. Result REJECTED.
- UNKNOWN: any stage undocumented. Result QUARANTINED with PLATFORM_CONFIRMATION_REQUIRED or FURTHER_RESEARCH_REQUIRED.
- False positives: counting a pending platform balance as cash; ignoring reserve holds; counting a payout cycle that closes after Day 30.
- False negatives: assuming the longest documented hold applies when a documented shorter path exists for the operator's account type.
- Reverification triggers: fee or payout policy source expiry.

### FWK-05 G4 Laptop executability

Fatal. All core work must be executable through a laptop with an internet connection.

- PASS: no step requires physical presence, physical handling of goods by the operator, or hardware the operator is not documented to have.
- FAIL: any core step requires physical presence or physical labor by the operator. Result REJECTED.
- UNKNOWN: a core step depends on a tool whose laptop availability is undocumented (for example a mobile-only application). Result QUARANTINED with FURTHER_RESEARCH_REQUIRED.
- False positives: fulfilment described as digital while returns or inspection require physical handling.

### FWK-06 G5 No bespoke-selling or named-individual dependency

Fatal. Cash must not depend on individualized sales calls, proposals, negotiation, networking, bespoke approvals, or any named individual.

- PASS: cash arrives through standardized self-service transactions with unknown buyers or through standardized program payouts.
- FAIL: any dependency in the dependency map (FWK-37) of type HUMAN_NAMED, or a cash-blocking dependency requiring individualized negotiation or bespoke approval. Result REJECTED.
- UNKNOWN: the sales mechanism is undocumented.
- Note: standardized platform approvals and KYC are dependencies, not bespoke approvals, unless they require sponsorship by a named person.

### FWK-07 G6 Platform-policy compliance

Fatal. The mechanism must not require violating the terms of any platform it depends on.

- PASS: tier 3 policy sources within freshness show the mechanism as permitted, or contain no prohibition of its required actions.
- FAIL: the mechanism requires multi-accounting, incentive abuse, misrepresentation, automation prohibited by the platform, geographic evasion, or any action the policy prohibits. Result REJECTED.
- UNKNOWN: policy not checked or expired. Result QUARANTINED.

### FWK-08 G7 Ethical exclusion

Fatal. The mechanism must not depend on deceiving buyers or payers, harming third parties, exploiting vulnerable users, or producing content or conduct that is fraudulent.

- PASS: none of the above is required by the mechanism.
- FAIL: any of the above is required. Result PROHIBITED.
- UNKNOWN: the mechanism's required conduct is undocumented.

### FWK-09 Gate order, stop rules, and overrides

Gates run in the SYS-07 order. A verified G1 or G7 FAIL ends evaluation; no further field is filled and no band is assigned. A material unresolved legal question (FWK-62) produces QUARANTINED with subtype PROFESSIONAL_LEGAL_REVIEW_REQUIRED and overrides every band, class, ordering, or experiment result. No gate value may be inferred from a band, from another candidate, or from the persuasiveness of a description (FWK-64).

## Tracks and conditional gates

### FWK-10 Track assignment decision tree

Applied at SYS-07 step 2, before any track-specific evaluation. Labels, names, and marketing terms never determine the track (CAP-16).

1. If any cash depends on price movement of an asset, on counterparty solvency or custody, on protocol token incentives, or on capital placed at risk of loss beyond fees and direct costs, the record is T2. If it also has an earned or reward component, it is T5 and inherits T2 controls.
2. Otherwise, if cash comes from a sponsor, platform, or protocol as a referral, reward, grant, prize, bounty, or incentive rather than from a buyer of delivered value, the record is T3.
3. Otherwise, if under the conservative and base cases usable cash cannot arrive by Day 30 because an asset must be built first, the record is T4. A T4 record with a separate component that can produce cash by Day 30 is T5.
4. Otherwise the record is T1.

Any T5 record inherits the full control set of every component track. The assignment is recorded with the reason and the rule step that fired.

### FWK-11 Conditional gates

Not fatal. Any open conditional gate keeps the record in CONDITIONAL. Conditional gates cannot be traded against each other or against bands.

| Gate | Closed when |
|---|---|
| C1 Cold-start distribution | FWK-36 satisfied |
| C2 Dependency map | FWK-37 complete with no cash-blocking dependency at UNKNOWN availability |
| C3 Economic model | FWK-31 complete for all three cases with no UNKNOWN required input |
| C4 Timing model | FWK-30 complete for all three cases |
| C5 Capital-risk protocol | CAP-02 to CAP-14 complete (T2 and T5 only; closed by default for T1, T3, T4) |
| C6 Validation experiment | Designed per FWK-35 |
| C7 Freshness | Every platform and regulatory source within FWK-60 limits |
| C8 Contradiction search | EVD-09 minimum completed and logged |

## Bands and classes

### FWK-12 Evidence-confidence bands

Assigned from the claim-evidence matrix over decision-critical claims (STR-08), citing the claim IDs that determined the band.

| Band | Condition |
|---|---|
| HIGH | Every decision-critical claim is VERIFIED_FACT or STRONGLY_SUPPORTED, and every DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, and FINANCIAL_EDGE claim has at least one independent corroboration of class A (EVD-04) |
| MODERATE | Every decision-critical claim is at least DIRECTIONAL and none is UNKNOWN, OUTDATED, or an unresolved CONTRADICTION |
| LOW | Any decision-critical claim is INFERENCE, ASSUMPTION, or HYPOTHESIS, and none is UNKNOWN, OUTDATED, or an unresolved CONTRADICTION |
| UNRESOLVED | Any decision-critical claim is UNKNOWN, OUTDATED, or an unresolved CONTRADICTION |

Volume of sources does not move a band (EVD-12).

### FWK-13 Risk classification

Risk types recorded: capital loss, platform account or payout, counterparty or custody, regulatory, refund or chargeback, operational or time overrun, reputational, concentration. For each record the maximum plausible loss range and the exposure of each type are compared with operator limits.

| Class | Condition |
|---|---|
| R1 Within limits | Every exposure is below 80 percent of the operator's stated limit for that type |
| R2 Near limits | Any exposure is between 80 and 100 percent of a limit |
| R3 Beyond limits | Any exposure exceeds a limit |
| R0 Not assessable | Any operator limit is OPERATOR_INPUT_REQUIRED or any exposure is UNKNOWN |

R0 is the default until operator limits are supplied. The 80 percent threshold is a design parameter recorded in the changelog and may be changed only by version.

### FWK-14 30-day cash compatibility bands

Computed from the timing model (FWK-30) and economic model (FWK-31) per case. A case supports the horizon when its S11 date is on or before Day 30 and its net collectible cash range has a low bound greater than zero.

| Band | Condition |
|---|---|
| CASH_A | Conservative case supports |
| CASH_B | Base case supports, conservative does not |
| CASH_C | Best case supports only |
| CASH_D | No case supports; outside the horizon |
| CASH_U | Any required timing or economic input is UNKNOWN |

### FWK-15 Horizon classes and the scalability rule

`horizon_class` is H30 when the base case reaches S11 by Day 30, H90 or H365 for later, H_OPEN when undefined. Long-term scalability, asset value, or growth potential is recorded only in the free-text `scalability_note` field, whose sole consumer is the report limitations section (STR-10). No gate, band, class, dominance comparison, tie-breaker, or scenario ordering may read it. A CASH_D record never appears in a 30-day ordering regardless of scalability.

## Deduplication and coverage

### FWK-20 Mechanism deduplication

Two candidates whose signature fields (STR-13) are all equal are the same mechanism. The later record becomes MERGED and points to the survivor; its operational differences are stored as a variant. Deduplication runs before coverage counting and before any screening. Candidates with equal `value_delivered`, `payer_type`, and `settlement_mechanism` but differing rail or dependency class are flagged NEAR_DUPLICATE for reviewer decision, logged either way. Every merge writes a DEC record with both identifiers.

### FWK-21 Category coverage audit

Before any screening, and again before any report, the coverage audit records for every family: sweeps completed, sightings, unique mechanisms after deduplication, near-duplicate flags, saturation status (SYS-06), and negative-evidence queries run. It also records findings for: families with zero mechanisms after a complete sweep (must be stated, not hidden), researcher-familiarity bias, search-popularity bias, emerging-mechanism gaps, and languages or markets not searched. A coverage audit with any family lacking a complete sweep is COVERAGE_INCOMPLETE.

## Timing and cash models

### FWK-30 Thirty-day timing model

Day 0 is the calendar date on which the decision to execute is recorded in the decision log, not the date of first sale. Days are calendar days. Eleven stages are modelled, each with an elapsed-days range per case, a tag `CALENDAR_FIXED` or `EFFORT_DRIVEN`, and a tag `SEQUENTIAL` or `PARALLEL` with the stage it can overlap.

| Stage | Meaning |
|---|---|
| S01 | Setup and account creation |
| S02 | KYC, identity, or program approval |
| S03 | Distribution start |
| S04 | First sale or qualifying event |
| S05 | Payment capture |
| S06 | Hold or reserve period |
| S07 | Payout eligibility reached (threshold and cycle) |
| S08 | Payout request |
| S09 | Payout processing |
| S10 | Receipt into intermediary account (processor, wallet, exchange) |
| S11 | Withdrawal into operator-controlled usable account |

Cases: conservative uses the documented maximum for every CALENDAR_FIXED stage, the high estimate for every EFFORT_DRIVEN stage, and treats thresholds as unmet until documented attainability; base uses documented typical values; best uses documented minimums. Effort hours are recorded separately and never substitute for elapsed days. A stage with no documented value is UNKNOWN and forces CASH_U. Withdrawal eligibility is not receipt; only S11 ends the model.

### FWK-31 Net collectible cash model

For each case:

```
NCC = receipts realized at S11 on or before Day 30
    - platform fees
    - payment processing fees
    - direct costs incurred on or before Day 30 (tools, advertising, fulfilment, fixtures)
    - refunds and chargebacks realized on or before Day 30
    - reserve haircut (FWK-33)
    - withdrawal and currency conversion costs (FWK-34)
    - tax provision (FWK-34)
    - recovered principal (FWK-32)
```

Costs count when incurred even if the related revenue never arrives. The following never count as receipts: views, followers, leads, trial users, monetization eligibility, pending marketplace balances, balances below payout thresholds, unrealized gains, returned investment principal, sales that cannot pay out by Day 30, and theoretical asset value. Any required input at UNKNOWN makes the case UNKNOWN.

### FWK-32 Recovered principal and realized return

Any return of capital that was deployed is recovered principal. It is recorded in its own field, reported separately on every dashboard, and is never classified as income, receipts, or return in any field or ordering. Realized return is the amount received above recovered principal after all costs. Unrealized gains are excluded entirely. A capital-risk record's cash contribution to any 30-day band is its realized return net of costs only.

### FWK-33 Reserve, refund, and chargeback tail

Each record documents `refund_tail_days` (the window in which refunds or chargebacks can still be raised) and `reserve_rate` (documented platform or processor reserve). The reserve haircut equals receipts multiplied by the greater of the documented reserve rate and the documented refund rate for the mechanism. If neither is documented, the conservative case is UNKNOWN. Any tail extending past Day 30 is recorded as a contingent liability on the economic model and disclosed on D4.

### FWK-34 Currency conversion and tax provision

Conversion costs are documented per rail and included in NCC. Tax provision defaults to Open/TBD with subtype PROFESSIONAL_TAX_REVIEW_REQUIRED, and NCC is labelled "before tax provision" until it is resolved. The account type the operator will use (personal or company) is OPERATOR_INPUT_REQUIRED and feeds G2. No favorable tax, license-scope, or account assumption may be entered to close these items.

## Feasibility, validation, distribution, dependencies

### FWK-35 Validation experiment constraints

A minimum legal validation experiment must: test one named claim; have a cost cap not exceeding the operator's stated experiment budget, which is OPERATOR_INPUT_REQUIRED until supplied; be reversible or have a bounded, disclosed downside; make no misleading claim to any buyer or platform; never pre-sell anything the operator cannot deliver; comply with applicable consumer and platform rules per G6 and G1; define its stop condition in advance; and record its result whether positive, negative, or ambiguous. A result is evidence about the tested claim only.

### FWK-36 Cold-start distribution verification

Each record names at least one distribution channel that requires no pre-existing audience, brand, network, or personal reputation, with evidence that the channel is available to such an operator and evidence of what reach or conversion it produced for operators in the same position. Evidence from practitioners who had an audience fails claim-source fit for this purpose (EVD-10). A record whose distribution is described but not evidenced carries the flag ASSUMED_DISTRIBUTION and C1 stays open. Demand evidence follows the DEMAND claim class minimums in EVD-03.

### FWK-37 Dependency mapping

Every L2 record lists each dependency with type, whether it blocks cash, availability evidence, and failure impact. Types: HUMAN_NAMED, HUMAN_ROLE, PLATFORM_APPROVAL, KYC_IDENTITY, PAYMENT_PROCESSOR, SUPPLIER_FULFILMENT, SUPPORT_BURDEN, ACCOUNT_LIMIT, TOOLING, OPERATOR_COMPANY. Any HUMAN_NAMED dependency fails G5 (FWK-06). Any cash-blocking dependency with UNKNOWN availability keeps C2 open. Dependencies on the operator's company or license scope are OPERATOR_INPUT_REQUIRED until confirmed.

### FWK-38 Time, capital, skill, and workload feasibility

Each L2 record states setup hours, recurring weekly hours, required skills, setup capital, working capital, and at-risk capital, all as ranges with provenance. Skills beyond ordinary laptop literacy and the operator's stated marketing experience are recorded as requirements, never assumed. Feasibility compares each against operator inputs; where those are OPERATOR_INPUT_REQUIRED the comparison is deferred and risk class is R0. Effort and elapsed time are never interchanged.

## Prioritization

### FWK-40 Prioritization sequence

There is no composite score. Ordering proceeds in this fixed sequence, within one track at a time:

1. Fatal-gate status: only records satisfying FWK-47 enter.
2. 30-day cash compatibility band (FWK-14).
3. Evidence-confidence band (FWK-12).
4. Risk class (FWK-13).
5. Within-track non-dominance grouping (FWK-41).
6. Lexicographic fallback inside each non-dominated front (FWK-42).
7. Explicit tie-breakers (FWK-43).
8. Bounded scenario-dependent ordering where operator inputs change the result (FWK-44).

Steps 2 to 4 partition records into groups; ordering between groups follows the band and class order (CASH_A before CASH_B before CASH_C; HIGH before MODERATE before LOW; R1 before R2; R0 records are reported in a separate unassessed group and never interleaved).

### FWK-41 Within-track non-dominance

Inside a group, record A dominates record B when A is at least as good on every dimension and strictly better on at least one: higher conservative NCC low bound, earlier conservative S11 day, fewer recurring hours, lower total capital required, lower maximum plausible loss. Ranges are compared by their bounds; overlapping ranges are not strictly better. The non-dominated set is the front; dominated records are ordered behind the front and their dominators are named.

### FWK-42 Lexicographic fallback

Inside a front, records are ordered lexicographically by: conservative NCC low bound (higher first), conservative S11 day (earlier first), maximum plausible loss high bound (lower first), recurring hours high bound (lower first). This is declared as lexicographic ordering, not a composite, and each output states the level at which the order was decided.

### FWK-43 Tie-breakers

Applied only when every prior level is equal or ranges overlap. In order: lower maximum plausible loss high bound; earlier conservative S11; lower recurring hours; cheaper and more reversible validation experiment; lower platform concentration (fewer SINGLE_PLATFORM or CUSTODIAL dependencies). If ranges still overlap or provenance classes differ, the tie is preserved (FWK-46).

### FWK-44 Bounded scenario-dependent ordering

Scenario variables are limited to: capital available class (C0 none, C1 low, C2 moderate, C3 high, with the class thresholds OPERATOR_INPUT_REQUIRED), loss tolerance class (same four classes), weekly hours class (H1 under 10, H2 10 to 25, H3 over 25), and account access set (personal, company, both). A report publishes at most eight named scenarios, each fully specified. No probability is assigned to any scenario. A scenario whose inputs are unspecified is not published.

### FWK-45 Cross-track reporting

Each track is ordered separately. A cross-track table lists each record's track, cash band, confidence band, risk class, conservative NCC range in AED, conservative S11 day, hours, and capital, with units normalized and differences disclosed. It carries no rank column. T2 and T5 records never appear in an "income" ordering; T4 records never appear in a 30-day ordering. Realized return and recovered principal are shown as separate columns.

### FWK-46 Ties and incomparability

Genuine ties and incomparable pairs are preserved and labelled as such. No rule may force a total order.

### FWK-47 Prioritization eligibility

A record enters ordering only when: state is ELIGIBLE or VALIDATED; L3 is complete; every fatal gate is PASS; every conditional gate is closed; cash band is not CASH_U or CASH_D; every platform and regulatory source is within freshness. Any other record is listed outside the ordering with its state and blocking item.

## Portfolio

### FWK-50 Portfolio feasibility gate

A portfolio of individually eligible records is feasible only when all of the following hold: aggregate setup hours and peak-week recurring hours, computed with concurrency, are within the operator's hours limit; peak simultaneous capital, computed as the sum of working and at-risk capital over overlapping windows, is within the capital limit; aggregate maximum plausible loss is within the loss limit; shared platforms, processors, accounts, approvals, or limits are listed and no shared limit is exceeded; support burden is summed; correlated platform, counterparty, regulatory, and market risks are identified. Any limit that is OPERATOR_INPUT_REQUIRED makes the result CONDITIONAL with the breakpoint value at which the portfolio would fail. Any UNKNOWN correlation or shared limit on a cash-blocking dependency blocks approval. Individual feasibility never establishes portfolio feasibility.

## Freshness, jurisdiction, precision, reopening

### FWK-60 Source freshness limits

| Source class | Freshness limit | Rationale |
|---|---|---|
| Platform policy, fees, eligibility, payout, settlement | 30 days | Changes frequently and without notice |
| Regulatory sources (tier 1 and 2) | 90 days | Changes on announcement cycles |
| Datasets and independent research (tier 4 and 5) | 365 days | Slower-moving; still dated |
| Practitioner and community material (tier 6 and 7) | 180 days | Discovery use only |

A source older than its limit is OUTDATED, and every gate it supports becomes UNKNOWN until reverified. Limits are design parameters recorded in the changelog and changed only by version.

### FWK-61 Jurisdiction routing question matrix

Routing separates five facts: operator residence (UAE-linked; exact emirate and residency status OPERATOR_INPUT_REQUIRED), company jurisdiction (registered free-zone company; licensed activity scope OPERATOR_INPUT_REQUIRED), customer location, platform jurisdiction, and activity class. For each activity class the matrix lists the questions to verify and the authority classes to consult. Authority names below are verification targets whose existence and remit must be confirmed at the check date. Nothing in this matrix is a legal conclusion.

| Activity class | Questions to verify | Authority classes and verification targets |
|---|---|---|
| A1 Sale of digital goods or services | Is the activity within the company's licensed scope? Is a personal sale permitted for the operator? Consumer-protection and e-commerce rules? | Free-zone authority; federal economy ministry; consumer-protection body |
| A2 Advertising, affiliate, marketing services | Advertising standards, disclosure, influencer or advertiser licensing or permits? | Media regulator; free-zone authority |
| A3 Financial promotion or advice | Does any content constitute regulated financial promotion or advice? | Federal securities regulator (SCA); financial-free-zone regulators (DFSA, FSRA) where relevant |
| A4 Securities, derivatives, FX trading | Is the venue licensed for UAE residents? Leverage or product restrictions? Tax treatment? | SCA; central bank (CBUAE); DFSA; FSRA; tax authority (FTA) |
| A5 Virtual assets | Is the activity, venue, or service permitted or licensed for UAE residents? Does the operator's activity itself require a license? | Emirate virtual-asset regulator (VARA in Dubai); SCA; CBUAE; FSRA; DFSA |
| A6 Payments, transfers, money-transmission-like activity | Does handling others' funds or facilitating payments require authorization? | CBUAE |
| A7 Data collection, monitoring, personal data | Data-protection obligations for collected or resold data? | Federal data-protection authority; free-zone data regimes |
| A8 Competitions, prizes, bounties | Are prize or promotion rules or permits engaged? | Emirate economic department; platform rules |
| A9 IP licensing | Ownership, rights clearance, and platform IP policies? | IP office; platform policy |
| A10 Consumer sales and VAT-relevant commerce | VAT registration thresholds, corporate tax, invoicing rules? | FTA; free-zone authority |

Every routing output is logged as one or more REG entries with source tier, issuing authority, jurisdiction, activity class, effective date, access date, applicability, and uncertainty.

### FWK-62 Professional verification rule

Professional review is mandatory, and the matching Open/TBD subtype is set, whenever: the activity class is A3, A4, A5, or A6; a tax question arises; the company's license scope is engaged; or any binding law or official guidance must be interpreted against the operator's specific facts. Researcher interpretation cannot close such an item, and a material unresolved legal question produces QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED (FWK-09).

### FWK-63 Precision and numeric provenance

Every quantity is a range with a provenance class (STR-11). Derived quantities inherit the worst provenance class among their inputs. Reports show at most two significant figures. No probability is stated without a documented basis and its source. Point estimates for demand, earnings, conversion, or edge are permitted only with MEASURED or DOCUMENTED provenance. ESTIMATED values must name the estimator's basis in the assumption register.

### FWK-64 Wording invariance

Gates, bands, classes, and orderings consume only structured fields. Free-text descriptions, persuasive language, source volume, and presentation never change any output. Two records with identical structured fields must produce identical outputs, and this is tested (T-24).

### FWK-65 Reopening on new evidence

A new admissible source, a contradiction log entry, a platform or regulatory change, a freshness expiry, or a validation result reopens the record at the earliest SYS-07 step it affects. Prior gate values, bands, and decisions are preserved in the decision log. A record may move in either direction, including from REJECTED or PROHIBITED back to SCREENED and from ELIGIBLE to QUARANTINED.

### FWK-66 Quarantine exit

A QUARANTINED record exits only when the named blocking item is resolved by an admissible source of the required tier (EVD-03), a logged operator input, a logged platform confirmation, or a logged professional opinion, matching the Open/TBD subtype. Evaluation then resumes at the step that produced the UNKNOWN. If the recheck date passes unresolved, the record stays QUARANTINED and is flagged STALE on D1.
