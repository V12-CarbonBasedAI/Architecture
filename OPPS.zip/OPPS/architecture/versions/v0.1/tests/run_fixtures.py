#!/usr/bin/env python3
"""Fixture engine: applies the Framework rules (04, 05, 06) to controlled hypothetical
architecture fixtures and compares results with preregistered expected outcomes.

Everything here is STIPULATED. Nothing is evidence about any real opportunity.
Usage: python3 run_fixtures.py [--label V0.1] [--blind]
"""
import copy, json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
MIN_TIER = {"LEGALITY": 2, "PLATFORM_ELIGIBILITY": 3, "PAYOUT_PATH": 3, "FEES_AND_COSTS": 3,
            "DEMAND": 5, "EARNINGS_OR_CONVERSION": 5, "DISTRIBUTION_PERFORMANCE": 5,
            "FINANCIAL_EDGE": 4, "DEPENDENCY_AVAILABILITY": 3}
PERF = {"DEMAND", "EARNINGS_OR_CONVERSION", "DISTRIBUTION_PERFORMANCE", "FINANCIAL_EDGE"}
RANK = ["VERIFIED_FACT", "STRONGLY_SUPPORTED", "DIRECTIONAL", "INFERENCE", "ASSUMPTION", "HYPOTHESIS"]
UNRES = {"CONTRADICTION", "UNKNOWN", "OUTDATED"}
CASH_ORDER = ["CASH_A", "CASH_B", "CASH_C", "CASH_D", "CASH_U"]
CONF_ORDER = ["HIGH", "MODERATE", "LOW", "UNRESOLVED"]
RISK_ORDER = ["R1", "R2", "R3", "R0"]

# ---------- patching ----------
def apply_patch(rec, patch):
    rec = copy.deepcopy(rec)
    for path, val in patch.items():
        parts = path.split(".")
        node = rec
        for p in parts[:-1]:
            node = _step(node, p)
        last = parts[-1]
        if last == "+":
            node.append(copy.deepcopy(val))
        elif isinstance(node, list):
            for i, item in enumerate(node):
                if isinstance(item, dict) and item.get("id") == last:
                    node[i] = copy.deepcopy(val)
        else:
            node[last] = copy.deepcopy(val)
    return rec

def _step(node, p):
    if isinstance(node, list):
        for item in node:
            if isinstance(item, dict) and item.get("id") == p:
                return item
        raise KeyError(p)
    return node[p]

# ---------- EVD-06 claim status ----------
def claim_status(claim):
    cls = claim["class"]
    adm = [s for s in claim["sources"] if s.get("fit", True) and s["indep"] != "C" and s["tier"] <= MIN_TIER[cls]]
    if not adm:
        return "UNKNOWN", 0
    fresh = [s for s in adm if s.get("fresh", True)]
    if not fresh:
        return "OUTDATED", 0
    if claim.get("contradiction") == "UNRESOLVED":
        return "CONTRADICTION", 0
    class_a = len({s["upstream"] for s in fresh if s["indep"] == "A"})
    if any(s["tier"] <= 3 for s in fresh) and MIN_TIER[cls] <= 3:
        status = "VERIFIED_FACT"
    elif class_a >= 2:
        status = "STRONGLY_SUPPORTED"
    elif class_a == 1:
        status = "DIRECTIONAL"
    else:
        status = "DIRECTIONAL"  # class B only: at most DIRECTIONAL (EVD-12)
    if cls in PERF:
        if not claim.get("denominator_known", False):
            status = _cap(status, "DIRECTIONAL")
        if claim.get("failure_search") == "NOT_DONE":
            status = _cap(status, "HYPOTHESIS")
    return status, class_a

def _cap(status, cap):
    return status if RANK.index(status) >= RANK.index(cap) else cap

def confidence_band(claims):
    crit = [c for c in claims if c.get("critical")]
    statuses = {c["id"]: claim_status(c) for c in crit}
    if any(s in UNRES for s, _ in statuses.values()):
        return "UNRESOLVED"
    if all(s in ("VERIFIED_FACT", "STRONGLY_SUPPORTED") for s, _ in statuses.values()) and \
       all(a >= 1 for c in crit for s, a in [statuses[c["id"]]] if c["class"] in PERF):
        return "HIGH"
    if all(RANK.index(s) <= RANK.index("DIRECTIONAL") for s, _ in statuses.values()):
        return "MODERATE"
    return "LOW"

# ---------- gates ----------
def gate_g1(g):
    if g.get("material_unresolved_legal"):
        return "UNKNOWN"
    if g["legal_source_class"] not in ("BINDING_LAW", "OFFICIAL_GUIDANCE"):
        return "UNKNOWN"
    if not g["fresh"]:
        return "UNKNOWN"
    if g["finding"] in ("RESTRICTION_FOUND", "LICENSE_REQUIRED"):
        return "FAIL"
    if g["finding"] == "UNRESOLVED":
        return "UNKNOWN"
    return "PASS"

def gate_g2(g):
    vals = [g["signup"], g["monetize"], g["withdraw"]]
    if "FAIL" in vals:
        return "FAIL"
    if not g.get("source_fresh", True) or "UNKNOWN" in vals:
        return "UNKNOWN"
    return "PASS"

def gate_g3(t):
    cases = t["cases"]
    if any(c.get("unknown_stage") for c in cases.values()) or not t.get("platform_source_fresh", True):
        return "UNKNOWN"
    if not t.get("rail_exists", True) or t["threshold_attainable"] == "NO" or cases["best"]["s11_day"] > 30:
        return "FAIL"
    if t["threshold_attainable"] == "UNKNOWN":
        return "UNKNOWN"
    return "PASS"

def gate_g5(rec):
    for d in rec["dependencies"]:
        if d["type"] == "HUMAN_NAMED" or (d.get("bespoke") and d.get("blocks_cash")):
            return "FAIL"
    if not rec.get("sales_mechanism_documented", True):
        return "UNKNOWN"
    return "PASS"

# ---------- track (FWK-10) ----------
def assign_track(rec):
    if rec["capital_role"] == "AT_RISK_CAPITAL" or rec.get("cash_depends_on_price_or_counterparty"):
        return "T5" if (rec.get("reward_not_sale") or rec.get("has_earned_component")) else "T2"
    if rec.get("reward_not_sale"):
        return "T3"
    if rec.get("asset_build_first"):
        return "T4"
    return "T1"

# ---------- cash (FWK-30, 31, 14) ----------
def ncc(case):
    if case.get("unknown"):
        return None
    lo = case["receipts"][0] - sum(case[k][1] for k in ("platform_fees", "processing_fees", "direct_costs", "refunds", "reserve_haircut", "fx", "tax", "recovered_principal"))
    hi = case["receipts"][1] - sum(case[k][0] for k in ("platform_fees", "processing_fees", "direct_costs", "refunds", "reserve_haircut", "fx", "tax", "recovered_principal"))
    return [lo, hi]

def case_supports(t, e):
    if t.get("unknown_stage") or e.get("unknown"):
        return None
    n = ncc(e)
    return t["s11_day"] <= 30 and n[0] > 0

def cash_band(rec):
    sup = {c: case_supports(rec["timing"]["cases"][c], rec["economics"]["cases"][c]) for c in ("conservative", "base", "best")}
    if any(v is None for v in sup.values()):
        return "CASH_U", sup
    if sup["conservative"]:
        return "CASH_A", sup
    if sup["base"]:
        return "CASH_B", sup
    if sup["best"]:
        return "CASH_C", sup
    return "CASH_D", sup

def horizon(rec):
    b = rec["timing"]["cases"]["base"]
    if b.get("unknown_stage"):
        return "H_OPEN"
    d = b["s11_day"]
    return "H30" if d <= 30 else "H90" if d <= 90 else "H365" if d <= 365 else "H_OPEN"

def risk_class(rec):
    lim = rec.get("operator_limits")
    if not lim:
        return "R0"
    ratios = [rec["max_plausible_loss"][1] / lim["loss"], rec["hours_per_week"][1] / lim["hours"], rec["capital_total"][1] / lim["capital"]]
    if any(r > 1.0 for r in ratios):
        return "R3"
    if any(r >= 0.8 for r in ratios):
        return "R2"
    return "R1"

# ---------- SYS-07 evaluation ----------
def evaluate(rec):
    out = {"gates": {}, "conditional": {}, "bands_assigned": False, "in_ordering": False, "in_income_ordering": False,
           "failed_gate": None, "subtype": None, "unknown_gate": None, "open_conditional": None, "cap_applied": False}
    out["track"] = assign_track(rec)                        # step 2
    g = out["gates"]
    g["G1"] = gate_g1(rec["g1"]); g["G7"] = rec["g7"]          # step 3
    if g["G1"] == "FAIL":
        out.update(state="PROHIBITED", failed_gate="G1"); return out
    if g["G7"] == "FAIL":
        out.update(state="PROHIBITED", failed_gate="G7"); return out
    g["G2"] = gate_g2(rec["g2"])                              # step 4
    if g["G2"] == "FAIL":
        out.update(state="REJECTED", failed_gate="G2"); return out
    g["G4"] = rec["g4"]; g["G5"] = gate_g5(rec); g["G6"] = rec["g6"]   # step 5
    for k in ("G4", "G5", "G6"):
        if g[k] == "FAIL":
            out.update(state="REJECTED", failed_gate=k); return out
    g["G3"] = gate_g3(rec["timing"])                          # step 6
    if g["G3"] == "FAIL":
        out.update(state="REJECTED", failed_gate="G3"); return out
    c = out["conditional"]                                    # steps 7-8
    cs = rec["cold_start"]
    c["C1"] = "CLOSED" if (not cs["requires_existing_audience"] and cs["evidence_fit"] and not cs["assumed"]) else "OPEN"
    c["C2"] = "CLOSED" if not any(d["blocks_cash"] and d["availability"] == "UNKNOWN" for d in rec["dependencies"]) else "OPEN"
    quarantine = []                                           # step 9 legal
    if rec["g1"].get("material_unresolved_legal"):
        quarantine.append(("G1", "PROFESSIONAL_LEGAL_REVIEW_REQUIRED"))
    elif g["G1"] == "UNKNOWN":
        quarantine.append(("G1", "FURTHER_RESEARCH_REQUIRED"))
    sub_for = {"G2": "PLATFORM_CONFIRMATION_REQUIRED", "G3": "PLATFORM_CONFIRMATION_REQUIRED", "G4": "FURTHER_RESEARCH_REQUIRED",
               "G5": "FURTHER_RESEARCH_REQUIRED", "G6": "PLATFORM_CONFIRMATION_REQUIRED", "G7": "FURTHER_RESEARCH_REQUIRED"}
    for k in ("G2", "G3", "G4", "G5", "G6", "G7"):
        if g[k] == "UNKNOWN":
            quarantine.append((k, sub_for[k]))
    out["confidence"] = confidence_band(rec["claims"])          # step 10
    for cl in rec["claims"]:
        if cl.get("critical") and claim_status(cl)[0] in UNRES:
            quarantine.append(("DECISION_CRITICAL_CLAIM", cl.get("unknown_subtype", "FURTHER_RESEARCH_REQUIRED")))
    c["C7"] = "CLOSED" if (rec["g1"]["fresh"] and rec["g2"].get("source_fresh", True) and rec["timing"].get("platform_source_fresh", True)) else "OPEN"
    c["C8"] = "CLOSED" if rec.get("contradiction_search_done") else "OPEN"
    out["cash_band"], out["supports"] = cash_band(rec)         # step 11
    out["ncc"] = {k: ncc(v) for k, v in rec["economics"]["cases"].items()}
    out["recovered_principal"] = rec["economics"]["cases"]["conservative"]["recovered_principal"]
    out["horizon_class"] = horizon(rec)
    c["C3"] = "CLOSED" if all(v is not None for v in out["ncc"].values()) else "OPEN"
    c["C4"] = "CLOSED" if not any(v.get("unknown_stage") for v in rec["timing"]["cases"].values()) else "OPEN"
    c["C6"] = "CLOSED" if rec["experiment"]["designed"] else "OPEN"
    if out["track"] in ("T2", "T5"):                          # step 12 track gates
        out["cap_applied"] = True
        cap = rec.get("cap") or {}
        c["C5"] = "CLOSED" if cap.get("complete") else "OPEN"
        out["expected_return"] = "UNKNOWN" if cap.get("edge_status") in (None, "UNKNOWN", "HYPOTHESIS") else cap.get("expected_return")
        if cap.get("track_gate_fail"):
            out.update(state="REJECTED", failed_gate="C5_TRACK_GATE"); return out
    else:
        c["C5"] = "CLOSED"
    out["risk_class"] = risk_class(rec)
    out["bands_assigned"] = True
    if quarantine:                                            # FWK-01, FWK-09
        legal = [q for q in quarantine if q[1] == "PROFESSIONAL_LEGAL_REVIEW_REQUIRED"]
        gate, sub = legal[0] if legal else quarantine[0]
        out.update(state="QUARANTINED", subtype=sub, unknown_gate=gate); return out
    open_c = [k for k, v in c.items() if v == "OPEN"]         # step 13
    if open_c:
        out.update(state="CONDITIONAL", open_conditional=sorted(open_c)[0]); return out
    out["state"] = "ELIGIBLE"
    out["in_ordering"] = out["cash_band"] in ("CASH_A", "CASH_B", "CASH_C")
    out["in_income_ordering"] = out["in_ordering"] and out["track"] in ("T1", "T3")
    return out

# ---------- dedup (FWK-20) ----------
def signature(rec):
    s = rec["signature"]
    return tuple(s[k] for k in ("value_delivered", "payer_type", "operator_supplies", "payment_rail", "settlement_mechanism", "platform_dependency_class"))

# ---------- ordering (FWK-41, 42, 43, 46) ----------
def dims(rec, out):
    return {"ncc": out["ncc"]["conservative"], "s11": [rec["timing"]["cases"]["conservative"]["s11_day"]] * 2,
            "hours": rec["hours_per_week"], "capital": rec["capital_total"], "loss": rec["max_plausible_loss"]}
HIGHER = {"ncc"}
def at_least(a, b, d):
    return (a[0] >= b[0] and a[1] >= b[1]) if d in HIGHER else (a[0] <= b[0] and a[1] <= b[1])
def strictly(a, b, d):
    return a[0] > b[1] if d in HIGHER else a[1] < b[0]
def dominates(da, db):
    return all(at_least(da[d], db[d], d) for d in da) and any(strictly(da[d], db[d], d) for d in da)

def order(items):
    """items: list of (id, rec, out). Returns front ids, dominated map, ties."""
    D = {i: dims(r, o) for i, r, o in items}
    dominated = {}
    for i in D:
        for j in D:
            if i != j and dominates(D[j], D[i]):
                dominated[i] = j
    front = [i for i in D if i not in dominated]
    ties = []
    for a in front:
        for b in front:
            if a < b and all(not strictly(D[a][d], D[b][d], d) and not strictly(D[b][d], D[a][d], d) for d in ("ncc", "s11", "loss", "hours")):
                ties.append((a, b))
    return front, dominated, ties

# ---------- portfolio (FWK-50) ----------
def portfolio(members, limits, shared_unknown, corr_unknown):
    hours = sum(m["hours_per_week"][1] for m in members)
    capital = sum(m["capital_total"][1] for m in members)
    loss = sum(m["max_plausible_loss"][1] for m in members)
    bp = {"hours": hours, "capital": capital, "loss": loss}
    if shared_unknown == "UNKNOWN" or corr_unknown:
        return "BLOCKED_UNKNOWN", bp
    if not limits:
        return "CONDITIONAL", bp
    if hours > limits["hours"] or capital > limits["capital"] or loss > limits["loss"] or shared_unknown == "YES":
        return "INFEASIBLE", bp
    return "FEASIBLE", bp

# ---------- test harness ----------
def check(expected, out):
    fails = []
    for k, v in expected.items():
        if k == "identical_to":
            continue
        if k == "ncc_conservative_low_at_or_below_zero":
            ok = out["ncc"]["conservative"][0] <= 0
        elif k == "base_supports":
            ok = out["supports"]["base"] == v
        elif k == "best_supports":
            ok = out["supports"]["best"] == v
        elif k == "scalability_independent":
            ok = True
        else:
            ok = out.get(k) == v
        if not ok:
            fails.append(f"{k}: expected {v!r}, observed {out.get(k)!r}")
    return fails

def main():
    label = sys.argv[sys.argv.index("--label") + 1] if "--label" in sys.argv else "unlabelled"
    blind = "--blind" in sys.argv
    fx = json.load(open(os.path.join(HERE, "fixtures.json")))
    base = fx["base_record"]
    rows, gate_seen = [], {f"G{i}": set() for i in range(1, 8)}
    outputs = {}
    results = {}

    def run(fid, rec, expected, note=""):
        out = evaluate(rec)
        outputs[fid] = (rec, out)
        for k, v in out["gates"].items():
            gate_seen[k].add(v)
        fails = [] if blind else check(expected, out)
        rows.append((fid, note, out.get("state"), out.get("track"), out.get("cash_band"), out.get("confidence"), out.get("subtype") or out.get("failed_gate") or out.get("open_conditional") or "", "PASS" if not fails else "FAIL: " + "; ".join(fails)))
        return out, fails

    all_ok = True
    dup_ids = fx["duplicates"]["ids"]; dup_sigs = {}
    for f in fx["records"]:
        rec = apply_patch(base, f["patch"])
        if f["id"] in dup_ids:                                # FWK-20 within the declared duplicate group
            sig = signature(rec)
            if sig in dup_sigs:
                out = {"dedup": "MERGED", "state": "MERGED", "merged_into": dup_sigs[sig], "gates": {}}
                outputs[f["id"]] = (rec, out); fails = check(f["expected"], out)
                rows.append((f["id"], f["label"], "MERGED", "", "", "", f"merged into {dup_sigs[sig]}", "PASS" if not fails else "FAIL: " + "; ".join(fails)))
                all_ok &= not fails; continue
            dup_sigs[sig] = f["id"]
        out, fails = run(f["id"], rec, f["expected"], f["label"])
        all_ok &= not fails
        for ph in f.get("phases", []):
            rec = apply_patch(rec, ph["patch"])
            out, fails = run(f["id"], rec, ph["expected"], ph["label"])
            all_ok &= not fails
    for f in fx["gate_matrix"]:
        rec = apply_patch(base, f["patch"])
        out, fails = run(f["id"], rec, f["expected"], "gate matrix variant")
        all_ok &= not fails

    # T-24 wording invariance
    a, b = outputs["FIX-013a"][1], outputs["FIX-013b"][1]
    results["T-24"] = a == b
    # T-11 / T-14 label evasion and track-before-track-gate
    results["T-11"] = outputs["FIX-014"][1]["track"] == "T2" and outputs["FIX-014"][1]["cap_applied"]
    results["T-14"] = outputs["FIX-001"][1]["cap_applied"] is False and outputs["FIX-005"][1]["cap_applied"] is True
    # T-13 dedup before coverage
    dup = fx["duplicates"]
    sigs = {signature(apply_patch(base, next(r for r in fx["records"] if r["id"] == i)["patch"])) for i in dup["ids"]}
    results["T-13"] = len(sigs) == dup["expected_mec_count"]
    rows.append(("FIX-008a/b", "dedup: unique signatures", str(len(sigs)), "", "", "", "", "PASS" if results["T-13"] else "FAIL"))
    # T-16 principal never income
    o5 = outputs["FIX-005"][1]
    results["T-16"] = o5["ncc"]["conservative"][0] <= 0 and o5["recovered_principal"] == [1000, 1000]
    # T-17 Day 30 ends at S11
    r9 = outputs["FIX-009"][0]
    results["T-17"] = r9["timing"]["cases"]["base"]["s10_day"] <= 30 and outputs["FIX-009"][1]["supports"]["base"] is False
    # T-34, T-35, T-36, T-33, T-29, T-30, T-20, T-19, T-21
    results["T-34"] = outputs["FIX-009"][1]["cash_band"] == "CASH_C"
    results["T-35"] = outputs["FIX-010"][1]["state"] == "REJECTED" and outputs["FIX-010"][1]["failed_gate"] == "G2"
    results["T-36"] = o5["expected_return"] == "UNKNOWN" and o5["confidence"] == "UNRESOLVED" and o5["state"] == "QUARANTINED" and not o5["in_income_ordering"]
    o11 = outputs["FIX-011"][1]
    alt = evaluate(apply_patch(outputs["FIX-011"][0], {"scalability_note": ""}))
    results["T-33"] = o11["cash_band"] == "CASH_D" and not o11["in_ordering"] and alt == o11
    results["T-29"] = outputs["FIX-006b"][1]["subtype"] == "PROFESSIONAL_LEGAL_REVIEW_REQUIRED" and outputs["FIX-014"][1]["subtype"] == "PROFESSIONAL_LEGAL_REVIEW_REQUIRED"
    results["T-30"] = outputs["FIX-006"][1]["state"] == "PROHIBITED" and not outputs["FIX-006"][1]["bands_assigned"]
    results["T-20"] = outputs["FIX-003"][1]["state"] == "QUARANTINED"
    # phases of FIX-007 are the last three FIX-007 rows
    ph = [r for r in rows if r[0] == "FIX-007"]
    results["T-19"] = ph[2][2] == "QUARANTINED"
    results["T-21"] = ph[0][2] == "QUARANTINED" and ph[1][2] == "ELIGIBLE" and ph[3][2] == "QUARANTINED"
    # T-26 monotonicity
    r1, o1 = outputs["FIX-001"]
    worse = apply_patch(r1, {"timing.cases.conservative.s11_day": 36, "timing.cases.base.s11_day": 28, "timing.cases.best.s11_day": 22})
    ow = evaluate(worse)
    costlier = apply_patch(r1, {"economics.cases.conservative.direct_costs": [300, 400]})
    oc = evaluate(costlier)
    results["T-26"] = CASH_ORDER.index(ow["cash_band"]) >= CASH_ORDER.index(o1["cash_band"]) and oc["ncc"]["conservative"][0] < o1["ncc"]["conservative"][0] and CASH_ORDER.index(oc["cash_band"]) >= CASH_ORDER.index(o1["cash_band"])
    # T-12 gate coverage
    results["T-12"] = all(gate_seen[g] >= {"PASS", "FAIL", "UNKNOWN"} for g in gate_seen)
    # claim tests
    ct = {}
    for t in fx["claim_tests"]:
        cl = {"class": t["class"], "sources": list(t["before"]), "denominator_known": True, "failure_search": "DONE_NONE", "contradiction": "NONE"}
        before, ca = claim_status(cl)
        if "add_repeated" in t:
            cl["sources"] += [t["add_repeated"]["source"]] * t["add_repeated"]["count"]
        else:
            cl["sources"] += t.get("add", [])
        after, ca2 = claim_status(cl)
        ok = True
        if "expected_before" in t: ok &= before == t["expected_before"]
        if "expected_after" in t: ok &= after == t["expected_after"]
        if "expected_class_a_count" in t: ok &= ca == t["expected_class_a_count"]
        ct[t["id"]] = ok
        rows.append((t["id"], t["label"], before, after, "", "", f"classA={ca}", "PASS" if ok else "FAIL"))
    results["T-23"], results["T-25"], results["T-28"] = ct["CT-01"], ct["CT-02"], ct["CT-03"]
    # ordering tests
    for t in fx["ordering_tests"]:
        items = []
        for r in t["records"]:
            rec = apply_patch(base, r["patch"]); out = evaluate(rec); items.append((r["id"], rec, out))
        front, dominated, ties = order(items)
        exp = t["expected"]; ok = True
        if "front" in exp: ok &= front == exp["front"]
        if "dominated" in exp: ok &= dominated == exp["dominated"]
        if "tie" in exp: ok &= (exp["tie"][0], exp["tie"][1]) in ties
        results[{"OT-02": "T-32", "OT-01": "T-31"}[t["id"]]] = ok
        rows.append((t["id"], t["label"], f"front={front}", f"dominated={dominated}", f"ties={ties}", "", "", "PASS" if ok else "FAIL"))
    # portfolio tests
    pf = {}
    for t in fx["portfolio"]:
        members = [apply_patch(base, t["member_patch"]) for _ in t["members"]]
        indiv = {risk_class(m) for m in members}
        res, bp = portfolio(members, t["limits"], t["shared_limit_exceeded"], t["correlation_unknown"])
        ok = res == t["expected"]["result"]
        if "members_individually" in t["expected"]: ok &= indiv == {t["expected"]["members_individually"]}
        if t["expected"].get("breakpoints_present"): ok &= bool(bp)
        pf[t["id"]] = ok
        rows.append((t["id"], t["label"], res, f"individually={sorted(indiv)}", f"breakpoints={bp}", "", "", "PASS" if ok else "FAIL"))
    results["T-18"] = all(pf.values())
    results["T-27"] = o1["risk_class"] == "R0" and pf["FIX-012b"]
    results["FIXTURES"] = all_ok

    print(f"## Fixture run: {label}{' (blind)' if blind else ''}\n")
    print("Controlled hypothetical architecture fixtures. Stipulated facts test framework logic only; never evidence, benchmarks, or ranking inputs.\n")
    print("| Fixture | Note | State | Track | Cash band | Confidence | Detail | Result |\n|---|---|---|---|---|---|---|---|")
    for r in rows:
        print("| " + " | ".join(str(x) for x in r) + " |")
    print("\n| Test | Result |\n|---|---|")
    for k in sorted(results):
        print(f"| {k} | {'PASS' if results[k] else 'FAIL'} |")
    print(f"\nGate coverage: " + ", ".join(f"{g}={sorted(v)}" for g, v in gate_seen.items()))
    json.dump({"label": label, "results": results}, open(os.path.join(HERE, f"results-{label}.json"), "w"), indent=1)
    sys.exit(0 if all(results.values()) else 1)

if __name__ == "__main__":
    main()
