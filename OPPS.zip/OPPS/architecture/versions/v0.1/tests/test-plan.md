# Test plan: architecture tests, adversarial themes, and edge conditions

Owner: SYS-11 and SYS-12 define the process; this file defines the tests. Structural tests run in `validate.py`. Logic tests run in `run_fixtures.py` against `fixtures.json`. Manual tests are recorded in `results.md` with the reviewer perspective. Every fixture in `fixtures.md` is a controlled hypothetical architecture fixture: stipulated facts test framework logic only and are never empirical evidence, commercial benchmarks, profitability validation, or inputs to later opportunity rankings.

## Structural tests (validate.py)

| ID | Test | Pass condition |
|---|---|---|
| T-01 | Control ID uniqueness and index | Every SYS, STR, FWK, EVD, CAP heading appears exactly once across rule files and in the README control index |
| T-02 | Control references resolve | Every control ID referenced anywhere exists |
| T-03 | Links and anchors | Every relative markdown link and heading anchor resolves |
| T-04 | Template schemas | Every template front matter parses; every field has a consumer; every consumer ID exists; admin fields have a justification; enum fields list allowed values |
| T-05 | Fixture isolation | No `FIX-` plus three digits outside `tests/` and `versions/` |
| T-06 | No placeholders | No TODO, TBC, XXX, FIXME, lorem, or "TBD" not immediately qualified by "Open/TBD" or a subtype, in any rule file or template |
| T-07 | Traceability | Every REQ names at least one existing control and one existing test; every FM names an existing control |
| T-08 | Test results recorded | Every T-id in this plan has a result row in `results.md` for the current version |
| T-09 | State machine closure | Every state in the STR-04 transition table is in the state list, every state appears in at least one transition, and terminal states leave only through reopening |
| T-10 | Manifest | `versions/v0.1/MANIFEST.sha256` matches the frozen files |
| T-15 | Scalability isolation | `scalability_note` lists STR-10 as its only consumer |
| T-22 | Provenance isolation | No `STIPULATED` provenance value appears outside `tests/` and `versions/` except in the allowed-value lists of schemas and the STR-11 definition |
| T-39 | Five-way status | `07-quality-and-release-audit.md` contains all five validation-status headings |
| T-40 | Design parameters | `CHANGELOG.md` records the 80 percent risk threshold and the four freshness limits |
| T-41 | Non-exhaustiveness | SYS-06 and STR-10 both state that saturation is not exhaustive discovery |
| T-12 | Gate coverage | Across fixtures, every gate G1 to G7 is exercised at PASS, FAIL, and UNKNOWN |

## Logic tests (run_fixtures.py)

| ID | Test | Pass condition |
|---|---|---|
| T-11 | Label evasion | A record with `capital_role` AT_RISK_CAPITAL and a description of risk-free arbitrage yield is T2 and CAP applies (FIX-014) |
| T-13 | Dedup before coverage | Two differently named records with equal signatures produce one mechanism and a coverage count of one (FIX-008) |
| T-14 | Track before track gates | Engine assigns track at step 2 and applies CAP only after assignment; a T1 record never receives CAP evaluation |
| T-16 | Principal never income | NCC excludes recovered principal; recovered principal is reported separately; a case whose only inflow is principal has NCC at or below zero (FIX-005) |
| T-17 | Day 30 ends at S11 | Usable-cash day equals S11 day; a case with S10 by Day 30 but S11 after Day 30 does not support the horizon (FIX-009) |
| T-18 | Portfolio aggregation | Three individually feasible members exceed hours and capital limits together and the portfolio is INFEASIBLE; with limits missing it is CONDITIONAL with breakpoints (FIX-012) |
| T-19 | Freshness expiry | An ELIGIBLE record whose platform source expires becomes QUARANTINED (FIX-007 phase 3) |
| T-20 | Unknown means quarantine | A record with one UNKNOWN fatal gate and everything else strong is QUARANTINED, not CONDITIONAL or ELIGIBLE (FIX-003) |
| T-21 | Reopen on evidence | A QUARANTINED record becomes ELIGIBLE after admissible evidence and returns to QUARANTINED after a material contradiction (FIX-007) |
| T-23 | Internal agreement not evidence | Adding class C sources never raises a claim status (claim test CT-01) |
| T-24 | Wording invariance | Two records with identical structured fields and different descriptions produce identical outputs (FIX-013a and FIX-013b) |
| T-25 | Volume not quality | Ten class B sources sharing one upstream give at most DIRECTIONAL (claim test CT-02) |
| T-26 | Monotonicity | Increasing hold days or costs never improves cash band or NCC (FIX-001 perturbation) |
| T-27 | No favorable defaults | Missing operator limits give R0 and a CONDITIONAL portfolio, never R1 or FEASIBLE (FIX-001, FIX-012b) |
| T-28 | Republication not corroboration | Two class B sources with the same upstream count as one independent source (claim test CT-03) |
| T-29 | Legal override | A record strong on every other dimension with a material unresolved legal question is QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED and has no ordering position (FIX-014 and FIX-006 variant) |
| T-30 | Prohibition stops | A G1 FAIL record is PROHIBITED with no bands assigned (FIX-006) |
| T-31 | Lexicographic fallback and ties | Records with overlapping ranges on every level are reported as a tie (ordering test OT-01) |
| T-32 | Non-dominance | A dominated record is placed behind its dominator and the dominator is named (ordering test OT-02) |
| T-33 | Scalable asset excluded | A CASH_D record with a large scalability note is absent from the 30-day ordering (FIX-011) |
| T-34 | Day-25 sale with 14-day payout | Base case S11 at day 39 does not support; best case at day 28 supports; band is CASH_C (FIX-009) |
| T-35 | Viewable not monetizable | G2 monetize FAIL gives REJECTED (FIX-010) |
| T-36 | Capital risk without edge | expected_return is UNKNOWN, confidence is UNRESOLVED, state is QUARANTINED, and the record is absent from any income ordering (FIX-005) |

## Manual tests

| ID | Test | Pass condition |
|---|---|---|
| T-37 | Blinded repeatability | An evaluator who did not see expected outcomes reproduces the state and band of every fixture |
| T-38 | Six reviews | All six SYS-11 reviews completed against the frozen V0.1, every finding dispositioned, no critical or high open |

## Adversarial themes and edge conditions

Each theme is covered by the tests named.

| Theme | Tests |
|---|---|
| Republication mistaken for corroboration | T-28 |
| Internal agreement mistaken for evidence | T-23 |
| Fixture contamination of rankings | T-05, T-22 |
| Volume masking missing critical claims | T-25 |
| Returned principal counted as earnings | T-16 |
| Operator scenarios becoming favorable defaults | T-27 |
| Individually feasible candidates forming an infeasible portfolio | T-18 |
| Persuasive wording changing outcomes | T-24, T-11 |
| Costs or delays rising while assessments improve | T-26 |
| New evidence reopening decisions | T-21 |
| Mislabelled capital-risk entering the earned track | T-11 |
| Synonym inflating coverage | T-13 |
| Expired source supporting approval | T-19 |
| Unknown gate treated as conditional pass | T-20 |
| Scalability leaking into 30-day ordering | T-15, T-33 |
| Legal unknown overridden by strength elsewhere | T-29 |
| Prohibition followed by scoring | T-30 |
| Ties forced into a total order | T-31 |
