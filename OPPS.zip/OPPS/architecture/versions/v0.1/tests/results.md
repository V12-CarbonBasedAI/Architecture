# Architecture test results

Original results are preserved per version label and never overwritten (SYS-12). Fixture rows are controlled hypothetical architecture fixtures: stipulated facts testing framework logic only, never evidence, benchmarks, or ranking inputs.

# Results V0.1

Pre-freeze build defects fixed before freezing: duplicate-group dedup not wired in the engine (FIX-008b), an unqualified 'limits TBD' phrase in SYS-01, and a missing red-team findings file. Recorded here for completeness; they are build defects, not review findings.

## Fixture run: V0.1

Controlled hypothetical architecture fixtures. Stipulated facts test framework logic only; never evidence, benchmarks, or ranking inputs.

| Fixture | Note | State | Track | Cash band | Confidence | Detail | Result |
|---|---|---|---|---|---|---|---|
| FIX-001 | Strong candidate that should pass | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-002 | Weak candidate that should fail: payout threshold unattainable by Day 30 | REJECTED | T1 | None | None | G3 | PASS |
| FIX-003 | Candidate requiring quarantine: withdrawal availability undocumented | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-004 | Longer-horizon candidate: best case beyond Day 30 | REJECTED | T4 | None | None | G3 | PASS |
| FIX-005 | Capital-risk candidate without verified edge | QUARANTINED | T2 | CASH_B | UNRESOLVED | EVIDENCE_UNAVAILABLE | PASS |
| FIX-006 | Legally prohibited candidate under stipulated hypothetical rule | PROHIBITED | T1 | None | None | G1 | PASS |
| FIX-006b | Strong candidate with a material unresolved legal question | QUARANTINED | T1 | CASH_A | HIGH | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | PASS |
| FIX-007 | Candidate whose status changes after new evidence | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-007 | Phase 2: platform documentation confirms monetization | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-007 | Phase 3: platform source exceeds freshness limit | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-007 | Phase 4: source reverified, then a material contradiction on demand | QUARANTINED | T1 | CASH_A | UNRESOLVED | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-008a | Duplicate pair, first name | ELIGIBLE | T1 | CASH_A | HIGH |  | PASS |
| FIX-008b | Duplicate pair, second name, same signature | MERGED |  |  |  | merged into FIX-008a | PASS |
| FIX-009 | Day-25 sale with 14-day payout delay | ELIGIBLE | T1 | CASH_C | HIGH |  | PASS |
| FIX-010 | Platform viewable but unavailable for UAE monetization | REJECTED | T1 | None | None | G2 | PASS |
| FIX-011 | Highly scalable asset with no Day-30 cash path | ELIGIBLE | T4 | CASH_D | HIGH |  | PASS |
| FIX-013a | Plain, unglamorous evidence that should pass (false-rejection check) | ELIGIBLE | T1 | CASH_A | MODERATE |  | PASS |
| FIX-013b | Same structured facts with persuasive wording | ELIGIBLE | T1 | CASH_A | MODERATE |  | PASS |
| FIX-014 | Label evasion: described as risk-free arbitrage yield | QUARANTINED | T2 | CASH_A | UNRESOLVED | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | PASS |
| FIX-001-G1U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G1C | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G2F | gate matrix variant | REJECTED | T1 | None | None | G2 | PASS |
| FIX-001-G3U | gate matrix variant | QUARANTINED | T1 | CASH_U | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-001-G3F | gate matrix variant | REJECTED | T1 | None | None | G3 | PASS |
| FIX-001-G4F | gate matrix variant | REJECTED | T1 | None | None | G4 | PASS |
| FIX-001-G4U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G5F | gate matrix variant | REJECTED | T1 | None | None | G5 | PASS |
| FIX-001-G5U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-G6F | gate matrix variant | REJECTED | T1 | None | None | G6 | PASS |
| FIX-001-G6U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | PLATFORM_CONFIRMATION_REQUIRED | PASS |
| FIX-001-G7F | gate matrix variant | PROHIBITED | T1 | None | None | G7 | PASS |
| FIX-001-G7U | gate matrix variant | QUARANTINED | T1 | CASH_A | HIGH | FURTHER_RESEARCH_REQUIRED | PASS |
| FIX-001-C1 | gate matrix variant | CONDITIONAL | T1 | CASH_A | HIGH | C1 | PASS |
| FIX-001-C2 | gate matrix variant | CONDITIONAL | T1 | CASH_A | HIGH | C2 | PASS |
| FIX-008a/b | dedup: unique signatures | 1 |  |  |  |  | PASS |
| CT-01 | Internal agreement never raises status | DIRECTIONAL | DIRECTIONAL |  |  | classA=1 | PASS |
| CT-02 | Ten republications of one upstream cap at DIRECTIONAL | UNKNOWN | DIRECTIONAL |  |  | classA=0 | PASS |
| CT-03 | Two class B with same upstream as one class A count as one independent source | DIRECTIONAL | DIRECTIONAL |  |  | classA=1 | PASS |
| OT-02 | Dominance | front=['FIX-OT2-A'] | dominated={'FIX-OT2-B': 'FIX-OT2-A'} | ties=[] |  |  | PASS |
| OT-01 | Tie preserved | front=['FIX-OT1-A', 'FIX-OT1-B'] | dominated={} | ties=[('FIX-OT1-A', 'FIX-OT1-B')] |  |  | PASS |
| FIX-012 | Three individually feasible members that are infeasible together | INFEASIBLE | individually=['R1'] | breakpoints={'hours': 45, 'capital': 9000, 'loss': 4500} |  |  | PASS |
| FIX-012b | Same members with operator limits missing | CONDITIONAL | individually=['R0'] | breakpoints={'hours': 45, 'capital': 9000, 'loss': 4500} |  |  | PASS |
| FIX-012c | Same members with an unknown shared account limit | BLOCKED_UNKNOWN | individually=['R1'] | breakpoints={'hours': 12, 'capital': 600, 'loss': 600} |  |  | PASS |

| Test | Result |
|---|---|
| FIXTURES | PASS |
| T-11 | PASS |
| T-12 | PASS |
| T-13 | PASS |
| T-14 | PASS |
| T-16 | PASS |
| T-17 | PASS |
| T-18 | PASS |
| T-19 | PASS |
| T-20 | PASS |
| T-21 | PASS |
| T-23 | PASS |
| T-24 | PASS |
| T-25 | PASS |
| T-26 | PASS |
| T-27 | PASS |
| T-28 | PASS |
| T-29 | PASS |
| T-30 | PASS |
| T-31 | PASS |
| T-32 | PASS |
| T-33 | PASS |
| T-34 | PASS |
| T-35 | PASS |
| T-36 | PASS |

Gate coverage: G1=['FAIL', 'PASS', 'UNKNOWN'], G2=['FAIL', 'PASS', 'UNKNOWN'], G3=['FAIL', 'PASS', 'UNKNOWN'], G4=['FAIL', 'PASS', 'UNKNOWN'], G5=['FAIL', 'PASS', 'UNKNOWN'], G6=['FAIL', 'PASS', 'UNKNOWN'], G7=['FAIL', 'PASS', 'UNKNOWN']

## Manual tests V0.1

| Test | Result | Note |
|---|---|---|
| T-37 | PENDING | Blinded repeatability runs after the V0.1 freeze |
| T-38 | PENDING | Six reviews run after the V0.1 freeze |

