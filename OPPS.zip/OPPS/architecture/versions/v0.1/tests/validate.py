#!/usr/bin/env python3
"""Structural validator for the architecture. Runs tests T-01..T-10, T-12 (from fixture results),
T-15, T-22, T-39, T-40, T-41; regenerates the README control index and tests/traceability.md.
Usage: python3 validate.py [--label V1.0] [--no-write]
"""
import hashlib, json, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RULE_FILES = ["02-system.md", "03-structure.md", "04-framework.md", "05-source-governance.md", "06-capital-risk-protocol.md"]
DOC_FILES = ["README.md", "01-requirements-and-failures.md", "07-quality-and-release-audit.md", "08-handoff-contract.md", "CHANGELOG.md"]
CTRL = re.compile(r"\b(SYS|STR|FWK|EVD|CAP)-\d{2}\b")
FIXID = re.compile(r"FIX-\d{3}")
label = sys.argv[sys.argv.index("--label") + 1] if "--label" in sys.argv else "unlabelled"
WRITE = "--no-write" not in sys.argv
res = {}
notes = {}

def read(p):
    return open(os.path.join(ROOT, p), encoding="utf-8").read()

def all_md():
    out = []
    for dp, dn, fn in os.walk(ROOT):
        if "versions" in dp.split(os.sep):
            continue
        for f in fn:
            if f.endswith(".md"):
                out.append(os.path.relpath(os.path.join(dp, f), ROOT))
    return sorted(out)

# ---- mini YAML front matter parser (restricted subset used by templates) ----
def parse_front_matter(text):
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    if not m:
        return None
    meta, fields, cur = {}, [], None
    for line in m.group(1).split("\n"):
        if not line.strip():
            continue
        if line.startswith("  - name:"):
            cur = {"name": line.split(":", 1)[1].strip()}
            fields.append(cur)
        elif line.startswith("    ") and cur is not None:
            k, v = line.strip().split(":", 1)
            cur[k.strip()] = parse_val(v.strip())
        elif line.startswith("fields:"):
            continue
        elif not line.startswith(" "):
            k, v = line.split(":", 1)
            meta[k.strip()] = parse_val(v.strip())
    meta["fields"] = fields
    return meta

def parse_val(v):
    v = v.strip()
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        return [x.strip().strip('"') for x in inner.split(",")] if inner else []
    if v in ("true", "false"):
        return v == "true"
    return v.strip('"')

# ---- T-01 / T-02 control definitions and references ----
defs = {}
for f in RULE_FILES:
    for line in read(f).split("\n"):
        mm = re.match(r"^### ((SYS|STR|FWK|EVD|CAP)-\d{2}) (.+)$", line)
        if mm:
            defs.setdefault(mm.group(1), []).append((f, mm.group(3)))
dupes = {k: v for k, v in defs.items() if len(v) > 1}
refs = set()
for f in all_md():
    refs |= set(CTRL.findall(read(f)) and [m.group(0) for m in CTRL.finditer(read(f))])
missing_refs = sorted(r for r in refs if r not in defs)
res["T-02"] = not missing_refs
notes["T-02"] = f"unresolved references: {missing_refs}" if missing_refs else f"{len(refs)} distinct control references resolve"

# ---- README control index regeneration ----
readme = read("README.md")
index_lines = ["| ID | File | Heading |", "|---|---|---|"]
for k in sorted(defs, key=lambda x: (["SYS", "STR", "FWK", "EVD", "CAP"].index(x[:3]), x)):
    f, h = defs[k][0]
    anchor = re.sub(r"[^a-z0-9 -]", "", (k + " " + h).lower()).replace(" ", "-")
    index_lines.append(f"| {k} | [{f}]({f}#{anchor}) | {h} |")
new_index = "<!-- CONTROL-INDEX-START -->\n" + "\n".join(index_lines) + "\n<!-- CONTROL-INDEX-END -->"
if WRITE:
    readme2 = re.sub(r"<!-- CONTROL-INDEX-START -->.*?<!-- CONTROL-INDEX-END -->", new_index, readme, flags=re.S)
    if readme2 != readme:
        open(os.path.join(ROOT, "README.md"), "w", encoding="utf-8").write(readme2)
    readme = readme2
indexed = set(re.findall(r"^\| ((?:SYS|STR|FWK|EVD|CAP)-\d{2}) \|", readme, re.M))
res["T-01"] = not dupes and indexed == set(defs)
notes["T-01"] = f"{len(defs)} controls defined once; duplicates={dupes}; index complete={indexed == set(defs)}"

# ---- T-03 links and anchors ----
def anchors_of(text):
    out = set()
    for line in text.split("\n"):
        mm = re.match(r"^#{1,6} (.+)$", line)
        if mm:
            out.add(re.sub(r"[^a-z0-9 -]", "", mm.group(1).lower()).replace(" ", "-"))
    return out
bad_links = []
for f in all_md():
    text = read(f)
    for mm in re.finditer(r"\[[^\]]*\]\(([^)]+)\)", text):
        target = mm.group(1)
        if target.startswith("http") or target.startswith("mailto:"):
            continue
        path, _, anchor = target.partition("#")
        tp = os.path.normpath(os.path.join(os.path.dirname(os.path.join(ROOT, f)), path)) if path else os.path.join(ROOT, f)
        if not os.path.exists(tp):
            bad_links.append((f, target)); continue
        if anchor and tp.endswith(".md") and anchor not in anchors_of(open(tp, encoding="utf-8").read()):
            bad_links.append((f, target))
res["T-03"] = not bad_links
notes["T-03"] = f"bad links: {bad_links}" if bad_links else "all relative links and anchors resolve"

# ---- T-04 template schemas, T-15 scalability isolation ----
tmpl_dir = os.path.join(ROOT, "templates")
schema_issues, field_count, scal_ok = [], 0, None
for dp, dn, fn in os.walk(tmpl_dir):
    for f in fn:
        if not f.endswith(".md"):
            continue
        rel = os.path.relpath(os.path.join(dp, f), ROOT)
        meta = parse_front_matter(open(os.path.join(dp, f), encoding="utf-8").read())
        if not meta:
            schema_issues.append((rel, "no front matter")); continue
        for k in ("template", "version", "owner_control"):
            if k not in meta:
                schema_issues.append((rel, f"missing {k}"))
        if meta.get("owner_control") not in defs:
            schema_issues.append((rel, f"owner_control {meta.get('owner_control')} undefined"))
        for fld in meta["fields"]:
            field_count += 1
            cons = fld.get("consumer")
            if not isinstance(cons, list) or not cons:
                schema_issues.append((rel, f"{fld['name']}: no consumer")); continue
            if "admin" in cons:
                if len(cons) != 1 or not fld.get("justification"):
                    schema_issues.append((rel, f"{fld['name']}: admin field needs sole consumer 'admin' and a justification"))
            else:
                for c in cons:
                    if c not in defs:
                        schema_issues.append((rel, f"{fld['name']}: consumer {c} undefined"))
            if fld.get("type") == "enum" and not fld.get("allowed"):
                schema_issues.append((rel, f"{fld['name']}: enum without allowed values"))
            if "type" not in fld:
                schema_issues.append((rel, f"{fld['name']}: no type"))
            if fld["name"] == "scalability_note":
                scal_ok = cons == ["STR-10"]
res["T-04"] = not schema_issues
notes["T-04"] = f"{field_count} fields checked; issues: {schema_issues}" if schema_issues else f"{field_count} fields, all with existing consumers"
res["T-15"] = bool(scal_ok)
notes["T-15"] = "scalability_note consumer is exactly [STR-10]" if scal_ok else "scalability_note consumer is not [STR-10]"

# ---- T-05 fixture isolation, T-22 provenance isolation ----
leaks, stip = [], []
for f in all_md() + ["tests/fixtures.json"]:
    if f.startswith("tests" + os.sep) or f.startswith("tests/"):
        continue
    text = read(f)
    if FIXID.search(text):
        leaks.append(f)
    for line in text.split("\n"):
        if "STIPULATED" in line and not (line.strip().startswith("allowed:") or "STR-11" in f and "provenance" in line.lower() or f.startswith("03-structure") or f.startswith("templates") and "allowed" in line):
            if not (f.startswith("templates") or f in ("03-structure.md", "07-quality-and-release-audit.md", "08-handoff-contract.md", "01-requirements-and-failures.md", "02-system.md", "README.md")):
                stip.append((f, line.strip()[:60]))
res["T-05"] = not leaks
notes["T-05"] = f"fixture ids outside tests/: {leaks}" if leaks else "no fixture identifiers outside tests/"
res["T-22"] = not stip
notes["T-22"] = f"STIPULATED outside allowed contexts: {stip}" if stip else "no STIPULATED provenance outside schemas and definitions"

# ---- T-06 placeholders ----
ph = []
for f in RULE_FILES + DOC_FILES + [p for p in all_md() if p.startswith("templates")]:
    for i, line in enumerate(read(f).split("\n"), 1):
        if re.search(r"\b(TODO|TBC|FIXME|XXX|lorem ipsum)\b", line):
            ph.append((f, i))
        for mm in re.finditer(r"\bTBD\b", line):
            ctx = line[max(0, mm.start() - 6):mm.end() + 40]
            if "Open/TBD" not in ctx and not re.search(r"TBD\W+(?:item|status|subtype|is|has|occurrences|remain|until|or)", ctx):
                ph.append((f, i, ctx))
res["T-06"] = not ph
notes["T-06"] = f"placeholders: {ph}" if ph else "no unqualified placeholders"

# ---- T-07 traceability from 01 ----
req_rows, fm_rows, trace_issues = [], [], []
test_ids = set(re.findall(r"^\| (T-\d{2}) \|", read("tests/test-plan.md"), re.M))
for line in read("01-requirements-and-failures.md").split("\n"):
    mm = re.match(r"^\| (REQ-\d{2}) \| (.+?) \| (.+?) \| (.+?) \|$", line)
    if mm:
        rid, txt, ctrls, tests = mm.groups()
        ctrls = [c.strip() for c in ctrls.split(",")]; tests = [t.strip() for t in tests.split(",")]
        for c in ctrls:
            if c not in defs: trace_issues.append((rid, "control", c))
        for t in tests:
            if t not in test_ids: trace_issues.append((rid, "test", t))
        req_rows.append((rid, txt, ctrls, tests))
    mm = re.match(r"^\| (FM-\d{2}) \| (.+?) \| (.+?) \|$", line)
    if mm:
        fid, txt, ctrls = mm.groups()
        for c in [c.strip() for c in ctrls.split(",")]:
            if c not in defs: trace_issues.append((fid, "control", c))
        fm_rows.append((fid, txt, ctrls))
res["T-07"] = not trace_issues and len(req_rows) > 0
notes["T-07"] = f"issues: {trace_issues}" if trace_issues else f"{len(req_rows)} requirements and {len(fm_rows)} failure modes trace to existing controls and tests"
if WRITE:
    tr = ["# Requirements-to-tests traceability", "", "Generated by `validate.py` from `01-requirements-and-failures.md`. Do not edit by hand.", "",
          "| Requirement | Controls | Tests |", "|---|---|---|"]
    tr += [f"| {r[0]}: {r[1]} | {', '.join(r[2])} | {', '.join(r[3])} |" for r in req_rows]
    tr += ["", "| Failure mode | Control |", "|---|---|"] + [f"| {r[0]}: {r[1]} | {r[2]} |" for r in fm_rows]
    covered = sorted({t for r in req_rows for t in r[3]})
    tr += ["", f"Tests referenced by requirements: {len(covered)} of {len(test_ids)} defined tests.", "Tests not referenced by any requirement: " + (", ".join(sorted(test_ids - set(covered))) or "none") + "."]
    open(os.path.join(HERE, "traceability.md"), "w", encoding="utf-8").write("\n".join(tr) + "\n")

# ---- T-09 state machine closure ----
s = read("03-structure.md")
states = set(re.findall(r"^\| ([A-Z_]+) \| (?:L0 exists|Duplicate|L1 complete|Verified legal|Any other fatal|Any fatal gate or|All fatal gates PASS|Validation experiment|Experiment)", s, re.M))
trans = re.findall(r"^\| ([A-Z_ or]+) \| ([A-Z_ or]+) \| (.+?) \|$", s, re.M)
seen = set()
for frm, to, trig in trans:
    for x in re.split(r" or ", frm) + re.split(r" or ", to):
        x = x.strip()
        if x.isupper(): seen.add(x)
terminal = {"MERGED"}
sm_issues = [st for st in states if st not in seen and st not in terminal]
res["T-09"] = len(states) == 11 and not sm_issues
notes["T-09"] = f"{len(states)} states; unreferenced: {sm_issues}"

# ---- T-10 manifest ----
mpath = os.path.join(ROOT, "versions", "v0.1", "MANIFEST.sha256")
if os.path.exists(mpath):
    bad = []
    for line in open(mpath, encoding="utf-8"):
        h, _, rel = line.strip().partition("  ")
        p = os.path.join(ROOT, "versions", "v0.1", rel)
        if not os.path.exists(p) or hashlib.sha256(open(p, "rb").read()).hexdigest() != h:
            bad.append(rel)
    res["T-10"] = not bad
    notes["T-10"] = f"manifest mismatches: {bad}" if bad else "v0.1 manifest validates"
else:
    res["T-10"] = False
    notes["T-10"] = "no v0.1 manifest present"

# ---- T-12 from fixture results ----
fr = os.path.join(HERE, f"results-{label}.json")
if os.path.exists(fr):
    r = json.load(open(fr))["results"]
    res["T-12"] = r.get("T-12", False)
    notes["T-12"] = "fixture engine reports full PASS/FAIL/UNKNOWN coverage for G1..G7" if res["T-12"] else "gate coverage incomplete"
else:
    res["T-12"] = False; notes["T-12"] = f"no fixture results for label {label}"

# ---- T-39, T-40, T-41 ----
qa = read("07-quality-and-release-audit.md")
res["T-39"] = all(h in qa for h in ["## Logically validated", "## Externally grounded methodology", "## Unvalidated until real research", "## Operator input required", "## Professional review required"])
notes["T-39"] = "five validation-status headings present" if res["T-39"] else "missing validation-status heading"
cl = read("CHANGELOG.md")
res["T-40"] = "80 percent" in cl and "30 days" in cl and "90 days" in cl and "365 days" in cl and "180 days" in cl
notes["T-40"] = "design parameters recorded" if res["T-40"] else "design parameters missing from changelog"
sysm = read("02-system.md"); strm = read("03-structure.md")
res["T-41"] = "never supports a claim of exhaustive discovery" in sysm and "non-exhaustiveness statement" in strm
notes["T-41"] = "non-exhaustiveness stated in SYS-06 and STR-10" if res["T-41"] else "non-exhaustiveness statement missing"

# ---- T-08 results recorded (checked against results.md for this label) ----
rp = os.path.join(HERE, "results.md")
if os.path.exists(rp):
    rt = open(rp, encoding="utf-8").read()
    sec = rt.split(f"# Results {label}")
    recorded = set(re.findall(r"^\| (T-\d{2}) \|", sec[1] if len(sec) > 1 else "", re.M))
    missing = sorted(test_ids - recorded)
    res["T-08"] = not missing
    notes["T-08"] = f"tests without a result row for {label}: {missing}" if missing else f"all {len(test_ids)} tests have result rows for {label}"
else:
    res["T-08"] = False; notes["T-08"] = "results.md missing"

print(f"## Structural validation: {label}\n")
print("| Test | Result | Note |\n|---|---|---|")
for k in sorted(res):
    print(f"| {k} | {'PASS' if res[k] else 'FAIL'} | {notes[k]} |")
json.dump({"label": label, "results": res, "notes": notes}, open(os.path.join(HERE, f"structural-{label}.json"), "w"), indent=1)
sys.exit(0 if all(res.values()) else 1)
