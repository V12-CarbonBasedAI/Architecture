# Red-team and review findings

Findings from the six SYS-11 reviews against the frozen V0.1 baseline. Each finding carries an RT identifier, review, severity (critical, high, medium, low), affected control, evidence or counterexample, correction, disposition, and residual risk. Reviewer agreement is recorded as consistency only (EVD-05). Reviews are pending until the V0.1 freeze completes.

| RT | Review | Severity | Control | Finding | Correction | Disposition | Residual risk |
|---|---|---|---|---|---|---|---|
