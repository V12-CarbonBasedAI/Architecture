# Controlled hypothetical architecture fixtures

> Controlled hypothetical architecture fixture set. Stipulated facts test framework logic only. They are not empirical evidence, commercial benchmarks, profitability validation, or inputs to later opportunity rankings. Every value carries `provenance_class: STIPULATED`. Fixture identifiers never leave `tests/` (SYS-16, STR-14).

Machine-readable definitions and preregistered expected outcomes are in `fixtures.json`. `run_fixtures.py` evaluates them with the Framework rules and compares observed to expected. Expected outcomes were written before the first run and are changed only with a logged justification and a red-team re-review (SYS-12). All fixtures derive from one abstract base record (a standardized digital item sold to unknown consumers through a single platform payout) by patching structured fields; the base record has no real-world referent.

## The fourteen mandated fixtures and their preregistered outcomes

| Fixture | Mandated case | Stipulated change from base | Preregistered outcome | Tests |
|---|---|---|---|---|
| FIX-001 | Candidate that should pass | None | T1, ELIGIBLE, CASH_A, HIGH, R0 (operator limits absent), in ordering | T-12, T-26, T-27 |
| FIX-002 | Candidate that should fail | Payout threshold unattainable by Day 30 | REJECTED at G3, no bands assigned | T-12 |
| FIX-003 | Candidate requiring quarantine | Withdrawal availability undocumented | QUARANTINED, PLATFORM_CONFIRMATION_REQUIRED, unknown gate G2 | T-20 |
| FIX-004 | Longer-horizon candidate | Asset must be built first; best-case usable cash on day 40 | T4, REJECTED at G3 | T-12 |
| FIX-005 | Capital-risk candidate without verified edge | At-risk capital; edge evidence is a single undated-style practitioner source; conservative case returns only principal | T2, CAP applied, QUARANTINED (EVIDENCE_UNAVAILABLE), UNRESOLVED confidence, expected return UNKNOWN, conservative NCC at or below zero, principal reported separately, absent from income ordering | T-16, T-36 |
| FIX-006 | Legally prohibited candidate | Stipulated binding restriction found | PROHIBITED at G1, no bands assigned | T-30 |
| FIX-006b | Legal override variant | Material unresolved legal question, everything else strong | QUARANTINED, PROFESSIONAL_LEGAL_REVIEW_REQUIRED | T-29 |
| FIX-007 | Status changes after new evidence | Phase 1 monetization undocumented; phase 2 confirmed; phase 3 source expires; phase 4 material demand contradiction | QUARANTINED, then ELIGIBLE, then QUARANTINED, then QUARANTINED | T-19, T-21 |
| FIX-008a and FIX-008b | Duplicates sharing one mechanism | Different names and platform labels, identical signature | One mechanism record; second is MERGED; coverage counts one | T-13 |
| FIX-009 | Day-25 sale with 14-day payout delay | Base case first sale on day 25 and S11 on day 39; best case S11 on day 28 | ELIGIBLE, CASH_C; base case does not support although S10 falls on day 30 | T-17, T-34 |
| FIX-010 | Platform viewable but not monetizable in the UAE | Sign-up available, monetization program unavailable | REJECTED at G2 | T-35 |
| FIX-011 | Highly scalable asset with no Day-30 cash path | Receipts by Day 30 cannot exceed costs in any case; large scalability note | T4, ELIGIBLE on gates, CASH_D, absent from ordering, output unchanged when the note is removed | T-33, T-15 |
| FIX-012, FIX-012b, FIX-012c | Individually feasible candidates infeasible together | Three members each R1 alone; limits 30 hours, 8000 capital, 5000 loss; variants with limits missing and with an unknown shared account limit | INFEASIBLE; CONDITIONAL with breakpoints; BLOCKED_UNKNOWN | T-18, T-27 |
| FIX-013a and FIX-013b | False-rejection and wording pair | Plain description with modest single-source demand evidence; identical facts with persuasive wording | Both ELIGIBLE, MODERATE, CASH_A, byte-identical outputs | T-24 |
| FIX-014 | Label evasion | Described as risk-free arbitrage yield; at-risk capital; unresolved legal routing | T2, CAP applied, QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED, expected return UNKNOWN | T-11, T-29 |

## Gate-matrix variants of FIX-001

To satisfy T-12 (every fatal gate exercised at PASS, FAIL, and UNKNOWN), fifteen single-field variants of FIX-001 are defined in `fixtures.json` under `gate_matrix`, identified FIX-001-G1U through FIX-001-C2. Each changes exactly one gate input and preregisters REJECTED, PROHIBITED, QUARANTINED, or CONDITIONAL with the responsible gate.

## Claim-level and ordering tests

| Test | Stipulation | Preregistered outcome |
|---|---|---|
| CT-01 | One class A source, then two class C internal assessments added | DIRECTIONAL before and after |
| CT-02 | Ten class B republications of one upstream, no class A | DIRECTIONAL at most |
| CT-03 | One class A plus two class B sharing its upstream | One independent source; DIRECTIONAL |
| OT-02 | Record A better on every dimension without overlap | A is the front; B is dominated by A |
| OT-01 | Two records with overlapping conservative NCC and equal other levels | Reported as a tie |

## Blinded repeatability

`run_fixtures.py --blind` prints observed outcomes without comparing to expectations, for an evaluator who has not seen this file. The blinded run is recorded in `results.md` under T-37.
