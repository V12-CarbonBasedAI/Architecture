# 08 Handoff contract for later real research

Owner layer: System (SYS-17). This file binds any later mass-research cycle that uses this architecture. It lists obligations, the unresolved variables by Open/TBD subtype and timing group, and what the architecture does not establish.

## Obligations of any research cycle

1. Declare Day 0 in the decision log before any timing model is built (FWK-30).
2. Run complete sweeps across all 16 families and three lenses with a verbatim query log (SYS-03, SYS-04) before any screening (SYS-05).
3. Deduplicate into mechanism records and complete the coverage audit before counting coverage or screening (FWK-20, FWK-21).
4. Evaluate every mechanism in the fixed 13-step order (SYS-07). Never skip a step, never infer a gate from a band, never let wording change an output (FWK-64).
5. Treat every UNKNOWN fatal gate as quarantine with a subtype, resolver, and recheck date (FWK-01, SYS-10). Never invent a favorable operator, license, account, or tax assumption (FWK-34).
6. Route every candidate through the jurisdiction matrix (FWK-61) and set professional-review subtypes where FWK-62 applies. Never state a legal conclusion.
7. Apply the full capital-risk protocol to every T2 and T5 record (CAP-01). Report recovered principal separately (FWK-32). Report expected return as UNKNOWN when edge is unknown (CAP-14).
8. Verify every platform and regulatory source against freshness limits before any ELIGIBLE transition or ordering (FWK-60, SYS-09).
9. Publish orderings per track only, with dominance groups, lexicographic levels, tie-breakers, preserved ties, and at most eight named scenarios (FWK-40 to FWK-46). Never publish a composite score.
10. Test every proposed portfolio (FWK-50) and report CONDITIONAL with breakpoints where operator limits are missing.
11. Keep every register current and publish the five dashboards, the quarantine and rejection lists, the coverage audit with per-family saturation, and the five-way validation status (SYS-17).
12. Never import any fixture identifier, stipulated number, or fixture outcome into a real record, benchmark, or ranking (SYS-16). Never use a fixture as a template for expected real-world values.
13. Record every state transition, merge, freeze, reopening, and experiment result in the decision log with prior values preserved (STR-04, FWK-65).
14. State in every report that saturation is a stopping rule and not exhaustive discovery (SYS-06).

## Unresolved variables by timing group

| Timing group | Variable | Open/TBD subtype | Effect until resolved |
|---|---|---|---|
| Before discovery | Research budget and stopping budget per family | OPERATOR_INPUT_REQUIRED | Sweeps may end COVERAGE_INCOMPLETE |
| Before discovery | Languages and markets to search | OPERATOR_INPUT_REQUIRED | Coverage audit records them as not searched |
| Before screening | Account type: personal, company, or both | OPERATOR_INPUT_REQUIRED | G2 may be UNKNOWN where availability differs by account type |
| Before screening | Free-zone license activity scope | OPERATOR_INPUT_REQUIRED and PROFESSIONAL_LEGAL_REVIEW_REQUIRED | OPERATOR_COMPANY dependencies stay unresolved |
| Before screening | Emirate, residency status, existing bank and payment rails | OPERATOR_INPUT_REQUIRED | Jurisdiction routing and S11 rails incomplete |
| Before decision | Capital available, loss limit, weekly hours, and the class thresholds in FWK-44 | OPERATOR_INPUT_REQUIRED | Risk class R0; scenarios unpublished |
| Before decision | Experiment cost cap | OPERATOR_INPUT_REQUIRED | Experiments designed but not run |
| Before decision | Skills beyond laptop literacy and marketing experience | OPERATOR_INPUT_REQUIRED | Feasibility comparison deferred |
| Before decision | Tax treatment (VAT, corporate tax, personal) | PROFESSIONAL_TAX_REVIEW_REQUIRED | NCC labelled before tax provision |
| Before decision | Regulatory status of activity classes A3 to A6 for the operator | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | Affected records QUARANTINED |
| Before portfolio | Preferences over risk types and target cash amount | OPERATOR_INPUT_REQUIRED | Portfolio CONDITIONAL with breakpoints |
| Continuous | Platform policies, fees, payout, eligibility | PLATFORM_CONFIRMATION_REQUIRED | Reverified per FWK-60 |
| Continuous | Availability of the EVD-14 methodological references | FURTHER_RESEARCH_REQUIRED | Cite with access date at first use |

## What this architecture does not establish

It does not establish that any opportunity exists, is legal for the operator, is available from the UAE, will produce demand, will pay out, will be profitable, has a financial edge, or ranks above any other. It does not prove real-world income or investment performance. Fixture outcomes are logical tests only. Every such question is answered, if at all, by a later research cycle operating under this contract, and many will remain Open/TBD with a subtype.
