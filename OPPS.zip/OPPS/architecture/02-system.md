# 02 System: the operating process

Owner layer: System. This file owns process only. Data shapes are in [03-structure.md](03-structure.md). Decision rules are in [04-framework.md](04-framework.md), [05-source-governance.md](05-source-governance.md), and [06-capital-risk-protocol.md](06-capital-risk-protocol.md). Where a step applies a rule, it cites the rule ID and does not restate it.

## Stage overview

### SYS-00 Operator profile intake

Before discovery, the integrator opens one operator profile record (OPR, `templates/operator-profile.md`) and records every operator fact the Framework consumes: emirate and residency status, account types available, license scope status, capital available, loss limit, weekly hours, experiment budget and per-cycle experiment cap, skills held, rails available, tax status. Every unsupplied field carries its Open/TBD subtype once, on the profile. No candidate record may assert a profile fact (FWK-34). Profile changes are DEC records and reopen affected records (FWK-65).

### SYS-01 Operating stages

Each stage has a purpose, inputs, actions, required evidence, outputs, responsible perspective (SYS-02), pass/conditional/fail conditions, and rework rule. A later stage may send a record back; it may never skip forward.

| # | Stage | Purpose | Inputs | Outputs | Pass | Conditional | Fail and rework |
|---|---|---|---|---|---|---|---|
| 0 | Operator profile | Collect operator facts once | Operator | OPR record | Every field supplied | Fields with subtypes | Profile absent: research may run, ordering cannot be published |
| 1 | Discovery sweep | Populate the universe broadly | Families F01 to F14 (STR-01), lenses (SYS-04), query log | L0 sightings, family sweeps | Family sweep complete per SYS-03 | Budget exhausted: PARTIAL | Missing lens or query class: repeat for the gap |
| 2 | Discovery freeze | Identify and deduplicate before filtering | L0 sightings | MEC records, OPP variants, coverage audit | FWK-20 and FWK-21 complete, bias reviews done | COVERAGE_INCOMPLETE recorded with reason | Identity fields unresolved: return to stage 1 for that record |
| 3 | Preliminary screen (L1) | Cheap FAIL-only elimination | OPP records | L1 records with FAIL or DEFERRED gate values | Steps 2 to 5 of SYS-07 done | None | FAIL: PROHIBITED or REJECTED; everything else proceeds |
| 4 | Investigation (L2) | Resolve every applicable fatal gate | L1 records not stopped | L2 records, mandatory claim rows, sources, REG rows, dependency map | Steps 6 to 10 of SYS-07 done | Any UNKNOWN: QUARANTINED per SYS-10 | Evidence insufficient: return to verification (SYS-08) |
| 5 | Decision (L3) | Produce decision state and prioritization inputs | L2 records with all gates valued | L3 records, decision log | Steps 11 to 13 of SYS-07 done | Conditional gates open: CONDITIONAL | Any fatal FAIL: REJECTED or PROHIBITED |
| 6 | Prioritization | Order eligible candidates without composite scoring | L3 ELIGIBLE records, profile | Per-track orderings, scenario table, cross-track table, reason lists (FWK-40, FWK-47) | Every record placed, listed by reason, or marked incomparable | Profile absent: reason lists only, no ordering | Ineligible record in an ordering: remove and log |
| 7 | Validation | Run selected minimum legal experiments | Records selected under SYS-14 | Experiment results, updated claims | Experiment meets FWK-35 | Result AMBIGUOUS | Experiment violates FWK-35: VOID |
| 8 | Portfolio assembly | Test combinations | ELIGIBLE or VALIDATED records, profile | POR record | FWK-50 FEASIBLE | Limits missing: CONDITIONAL with breakpoints | INFEASIBLE or BLOCKED_UNKNOWN |
| 9 | Review and red team | Independent challenge | Frozen baseline | Findings register | All findings dispositioned | Medium or low deferred with owner | Critical or high open: no release |
| 10 | Reporting | Publish state | All registers | Dashboards (STR-09), report (STR-10), five-way status | Every unknown visible | | Unknown hidden or defaulted: defect |

### SYS-02 Roles and perspectives

Six perspectives exist. One agent may hold several, but the adversary, the dependency-map attester, the bias reviewer, and the blinded evaluator must not have authored the material they review.

| Perspective | Responsibility |
|---|---|
| Discoverer | Runs sweeps, writes L0 and identity fields, proposes signatures. |
| Verifier | Extracts claims, classifies sources, runs contradiction searches; claim status is computed per EVD-06. |
| Jurisdiction reviewer | Runs the FWK-61 matrix, files REG rows with `finding_basis`, maintains the authority register, routes professional-review items (FWK-62). |
| Capital-risk reviewer | Applies the full CAP protocol to every record with a T2 component. |
| Adversary | Attests dependency maps, performs the SYS-05 bias and F16 reviews, attempts to falsify approvals and rejections, runs the wording test (FWK-64). |
| Integrator | Owns the operator profile, record integrity, state transitions (STR-04), registers, versioning (SYS-13). |

Agreement among perspectives is an internal consistency check and never counts as evidence (EVD-05).

## Discovery

### SYS-03 Family sweep definition

The unit of discovery is the family sweep (SWP-nnn-Fnn). A family sweep of F01 to F14 is COMPLETE only when all of the following are logged:

1. Every one of the three lenses (SYS-04) has been searched for the family.
2. Each family-lens cell records at least the minimum query set: one mechanism query, one payer query, one platform-policy query, one negative-evidence query, one recency-limited query. Each query row logs verbatim wording, date, `search_surface`, `language`, `results_reviewed_n`, and `query_novelty` (whether the string is new versus the previous sweep of that family).
3. To count toward saturation (SYS-06), at least half the query strings per cell are new versus the previous sweep and at least one new search surface or language is used.
4. Every result that names a payer and an operator action is recorded as an L0 sighting with family, lens, query id, and source locator, even if not presented as an opportunity.
5. Sweep identifier, start and end dates, and Discoverer are recorded.

F15 and F16 are not swept; their coverage is the ADJACENT_EMERGING lens and RECENCY_LIMITED queries across F01 to F14. A sweep that stops early is PARTIAL.

### SYS-04 Search lenses and negative-evidence query classes

Three lenses are mandatory in every family:

- **Mechanism and payer lens.** Who pays, for what, through which rail, and what the operator must supply.
- **Adjacent and emerging lens.** Neighbouring mechanisms, new platform programs, recently changed policies, and mechanisms named differently in other markets or languages.
- **Contrary and failure lens.** Evidence of bans, payout holds, account closures, regional unavailability, policy reversals, fraud, lawsuits, and operator failure accounts.

The negative-evidence query class combines the mechanism or family term with at least two of: failed, banned, suspended, payout hold, account closed, not available, UAE, scam, refund, chargeback, lawsuit, regulator. Results feed the contradiction log and EVD-09.

### SYS-05 Discovery freeze checkpoint

No screening, scoring, or filtering starts until:

1. Every L0 sighting has resolved identity fields (STR-03) and is assigned to a MEC and an OPP per FWK-20, with merges, promotions, and near-duplicate decisions logged.
2. The coverage audit (FWK-21) is complete with its status and reason.
3. The three bias reviews are done by the Adversary, never by the Discoverer of that sweep, with structured results: familiarity (share of mechanisms first sighted from a source unknown before the sweep; a finding is raised below the familiarity floor), popularity (share of mechanisms first seen beyond result rank 10 or from non-search surfaces; a finding below the popularity floor), emerging (count of F16 sightings and of mechanisms with a source dated within 90 days; zero is a mandatory finding). Floors are design parameters (CHANGELOG).
4. The F16 review is done by the Adversary, producing a DEC record of type TAXONOMY_REVIEW with `new_family_proposed`; proposals become `taxonomy_extensions` for the next version.

The freeze is recorded as a DEC record of type DISCOVERY_FREEZE carrying coverage status, the unsaturated family list, and the sweep identifiers.

### SYS-06 Research saturation and stopping rule

Saturation is judged per family. A family F01 to F14 is SATURATED when two consecutive COMPLETE family sweeps that meet the novelty requirement (SYS-03) produce zero new MEC records after deduplication and zero taxonomy extensions; PARTIAL sweeps between them are ignored and do not reset the count. F15 and F16 are SATURATED when the SYS-05 review completes with no new family proposed. The research budget (queries and hours, from the profile) and consumption are logged; exhaustion before every family is saturated yields COVERAGE_INCOMPLETE per FWK-21. Saturation is a stopping rule for a bounded research cycle. It never supports a claim of exhaustive discovery, and every report must say so in the limitations section.

## Evaluation

### SYS-07 Evaluation sequence

Every OPP is evaluated in this fixed order. The depth column names where the step is completed. A step may not be skipped.

| Step | Action | Depth | Rules applied | Stop condition |
|---|---|---|---|---|
| 1 | Confirm identity and deduplication already resolved at the freeze | Identity | FWK-20, STR-13 | Unresolved: return to stage 2 |
| 2 | Component-track assignment from structured fields | L1 | FWK-10, CAP-01, CAP-16 | None |
| 3 | Obvious prohibition and ethical exclusion | L1 | FWK-02, FWK-08, FWK-09 | Verified FAIL: PROHIBITED, evaluation ends |
| 4 | Obvious platform, account, monetization, withdrawal unavailability | L1 | FWK-03 | FAIL: REJECTED |
| 5 | Obvious laptop, solo, and people-dependency failure | L1 | FWK-05, FWK-06 | FAIL: REJECTED |
| 6 | Payment, settlement, and withdrawal path | L2 | FWK-04, FWK-30, CAP-07 | FAIL: REJECTED |
| 7 | Cold-start distribution and demand evidence | L2 | FWK-36, EVD-10 | None |
| 8 | Time, capital, skill, and workload feasibility; dependency map attestation | L2 | FWK-38, FWK-37, FWK-06 | BLOCKING skill gap without substitute: REJECTED |
| 9 | Detailed jurisdiction and regulatory verification | L2 | FWK-61, FWK-62, EVD-13, CAP-13 | Material unresolved legal question: QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED, overrides everything |
| 10 | Evidence-sufficiency review: mandatory claim set, statuses, freshness, contradiction rows; all gates now PASS, FAIL, or UNKNOWN | L2 | EVD-03, EVD-06, EVD-07, EVD-09, FWK-60, FWK-01 | Any gate or mandatory claim UNKNOWN, OUTDATED, or unresolved CONTRADICTION: QUARANTINED |
| 11 | 30-day collectible-cash determination and band assignment | L3 | FWK-30 to FWK-34, FWK-14, FWK-12, FWK-13, FWK-15 | None |
| 12 | Track-specific gates | L3 | FWK-11 and, for a T2 component, CAP-02 to CAP-14 | Track gate FAIL: REJECTED |
| 13 | Prioritization eligibility | L3 | FWK-47 | Not eligible: listed by reason |

Track assignment (step 2) always precedes track-specific evaluation (step 12). A step 3 stop is final for the current evidence; reopening follows FWK-65.

### SYS-08 Verification procedure

For every record at L2 or deeper:

1. Create the mandatory claim rows (EVD-03) for the record's component tracks; link each to the gates it supports through `gate_ids`.
2. Register each supporting source with tier, `independence_class`, `origin_id`, `upstream_source_id`, `publisher_incentive`, `operator_position`, jurisdiction, and dates; `supportable_claim_classes` and freshness class are derived.
3. Record fit per claim-source pair (EVD-10).
4. Log the EVD-09 contradiction rows, including NONE_FOUND rows.
5. Compute claim status per EVD-06; record any assumption with an ASM row and any unresolved item in the uncertainty register with its subtype (STR-05).
6. Promote the L0 source locator to a registered SO row.

### SYS-09 Reverification procedure

Before any transition into ELIGIBLE, VALIDATED, or a published ordering, the integrator recomputes freshness for every supporting source (FWK-60). Expired sources are re-fetched and re-dated; a source that cannot be re-fetched leaves its claims OUTDATED and the linked gates UNKNOWN. Reverification is also triggered by a contradiction row, a platform or regulatory change notice, a validation result, or an operator profile change. A sample of source classifications is re-checked by the Adversary each cycle.

### SYS-10 Escalation and quarantine handling

When a gate or mandatory claim is UNKNOWN, OUTDATED, or in unresolved CONTRADICTION at the end of L2 or later, the integrator files a quarantine row naming the blocking item, the Open/TBD subtype (STR-05), the resolver, the producing step, the structured exit condition (FWK-66), and the recheck date. Quarantined records appear on D1 with their blocking item and never enter an ordering.

## Review, revision, versioning

### SYS-11 Review and red-team procedure

Each architecture version, and each completed research cycle, receives six bounded reviews against a frozen baseline (SYS-13): evidence governance; universe taxonomy and deduplication; financial-market and crypto risk; platform, payout, and UAE jurisdiction; operational feasibility and cold-start distribution; adversarial red team with blinded repeatability. Reviewers see only the frozen baseline. The blinded evaluator receives fixtures from `tests/blind/` without expected outcomes. Each finding carries an RT identifier, severity, affected control, evidence or counterexample, correction, disposition, and residual risk. Synthesis waits for every review. Reviewer agreement is recorded as consistency only (EVD-05).

### SYS-12 Revision and regression procedure

Corrections are applied to the working copy, never to a frozen baseline. After any correction the full fixture suite and the structural validator run again. Original results are preserved in the results file under their version label; corrected results are appended, never overwritten. A correction that changes a fixture's preregistered outcome requires a logged justification in the findings register.

### SYS-13 Versioning and freeze procedure

A version is frozen by mirroring the complete file set into `versions/<version>/` and writing a manifest of SHA-256 hashes for every file. The manifest is validated before reviews start and before release. The changelog records every version, its design parameters, and the findings it addressed. Content inside a frozen mirror is never edited.

### SYS-14 Validation experiment procedure

After stage 6, experiments are designed only for records on a front or, when the only open gate is C1b, for CONDITIONAL records the integrator selects, up to the profile's per-cycle cap. The design is preregistered on the L3 record per FWK-35. Results update the claim-evidence matrix and move the record between VALIDATION_PENDING, VALIDATED, and INVALIDATED (STR-04); a MEASURED cold-start result closes C1b. A result is evidence about the tested claim only.

### SYS-15 Portfolio assembly procedure

Portfolios are assembled only from ELIGIBLE or VALIDATED records. The integrator builds the weekly workload and capital profiles per FWK-50 from each member's critical path and dependency rows, applies FWK-50, and records the POR record. Where profile limits are missing the result is CONDITIONAL with breakpoints.

### SYS-16 Fixture quarantine procedure

Fixtures exist only under `tests/`, including blind packs under `tests/blind/`. No fixture identifier, stipulated fact, number, or outcome may be copied into any file under `research/`, any register, dashboard, or report. The structural validator scans every file type under `research/` and every markdown or JSON file elsewhere for fixture identifiers and STIPULATED provenance (STR-14). Any occurrence is a critical defect. Copying a fixture's numeric pattern by hand remains undetectable and is recorded as a residual risk.

### SYS-17 Reporting procedure

Every published research output includes the elements of STR-10 with reason lists, the per-family saturation status and any COVERAGE_INCOMPLETE header, the operator profile status, the source freshness status, and the five-way validation status (logically validated, externally grounded, unvalidated until real research, operator input required, professional review required). No output omits unknowns, and every cash figure is labelled pre-tax.
