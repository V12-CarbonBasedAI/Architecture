# 01 Requirements and failure register

Owner layer: cross-cutting index. This file assigns a stable ID to every requirement from the specification, the audit corrections, and the final clarifications, names the controls that own it, and names the tests that verify it. `tests/traceability.md` is generated from the table below by `tests/validate.py`; do not edit either by hand.

## Requirements

| ID | Requirement | Owning controls | Tests |
|---|---|---|---|
| REQ-01 | System, Structure, and Framework remain distinct with one authoritative location per rule | SYS-01, STR-12, FWK-01 | T-01, T-02 |
| REQ-02 | Discovery covers all 16 families before any filtering, with F15 and F16 as assignment classes | STR-01, SYS-03, SYS-05 | T-13, T-04 |
| REQ-03 | Taxonomy has a mandatory catch-all, secondary dimensions, and a coverage audit against blind spots | STR-01, FWK-21 | T-04, T-13 |
| REQ-04 | Differently named versions of one mechanism are deduplicated before coverage counting | FWK-20, STR-13 | T-13 |
| REQ-05 | Source controls resist hype, affiliates, screenshots, circular citation, and survivorship bias | EVD-02, EVD-07, EVD-08, EVD-04 | T-25, T-28, T-50 |
| REQ-06 | Fatal admissibility gates precede any scoring or prioritization and cannot be rescued | FWK-01, FWK-09, FWK-40, FWK-47 | T-12, T-30 |
| REQ-07 | Unknown fatal conditions and missing inputs produce quarantine, never favorable scores | FWK-01, SYS-10, FWK-66 | T-20, T-42 |
| REQ-08 | Time-to-sale is separated from settlement, payout, withdrawal, and usable cash | FWK-30, FWK-04 | T-17, T-34 |
| REQ-09 | Cold-start distribution is tested, not assumed | FWK-36, EVD-10, SYS-14 | T-04, T-12 |
| REQ-10 | Hidden customer, supplier, platform, support, approval, and operator dependencies are exposed, including bespoke selling | FWK-37, FWK-06 | T-43, T-04 |
| REQ-11 | Earned income and capital-risk returns receive different treatment, with tracks derived from structured fields | STR-06, FWK-10, CAP-01 | T-11, T-36, T-48 |
| REQ-12 | Speculation is never presented as dependable income | FWK-45, CAP-14, FWK-32 | T-16, T-36 |
| REQ-13 | UAE jurisdiction, financial promotion, crypto, platform eligibility, KYC, payment, and withdrawal handled without manufactured legal certainty | FWK-61, FWK-62, EVD-13, FWK-02, FWK-03 | T-29, T-35, T-44, T-49 |
| REQ-14 | Long-term scalability cannot overpower 30-day cash feasibility | FWK-15 | T-15, T-33 |
| REQ-15 | Missing information remains visibly unresolved | STR-05, SYS-17 | T-06 |
| REQ-16 | Scoring avoids false precision | FWK-63, STR-11 | T-04 |
| REQ-17 | Prioritization is operational without a composite score | FWK-40, FWK-41, FWK-42, FWK-43, FWK-44, FWK-45, FWK-46 | T-31, T-32, T-51, T-52 |
| REQ-18 | Aggregate portfolio time, capital, account, and risk requirements are tested | FWK-50, SYS-15 | T-18 |
| REQ-19 | Controlled fixtures test both false approval and false rejection | SYS-16, STR-14 | T-24, T-12 |
| REQ-20 | Deliverables are necessary, usable, nonduplicative, and skill-convertible | STR-12, STR-07 | T-04, T-03 |
| REQ-21 | Completion criteria are objectively verifiable | SYS-13, SYS-12 | T-08, T-39 |
| REQ-22 | Research saturation rule is defensible and never claims exhaustive discovery | SYS-06 | T-41 |
| REQ-23 | Architecture supports mass research efficiently through tiered depth | STR-03 | T-04 |
| REQ-24 | Claim-level evidence records exist | STR-08, EVD-06 | T-04 |
| REQ-25 | Assumption, contradiction, uncertainty, rejection, quarantine, regulatory, source, and change logs exist | STR-07, SYS-13 | T-04, T-40 |
| REQ-26 | A 30-day critical-path model ends at usable cash | FWK-30 | T-17 |
| REQ-27 | A complete economic model ends at pre-tax net collectible cash with reserves, refunds, withholding, FX, and tax treated explicitly | FWK-31, FWK-33, FWK-34 | T-16, T-47 |
| REQ-28 | Recovered principal and realized return are treated separately | FWK-32 | T-16 |
| REQ-29 | A capital-risk dashboard exists | CAP-15, STR-09 | T-04 |
| REQ-30 | Human and platform dependency mapping exists | FWK-37 | T-04 |
| REQ-31 | Negative-evidence and contradiction searches are mandatory | EVD-09, SYS-04 | T-04 |
| REQ-32 | Source-freshness and reverification rules exist and propagate to gates | FWK-60, SYS-09 | T-19, T-45 |
| REQ-33 | Category-coverage and research-saturation controls exist | FWK-21, SYS-06 | T-13, T-41 |
| REQ-34 | Minimum legal validation experiments are constrained | FWK-35, SYS-14 | T-04 |
| REQ-35 | Versioned V0.1, red-team findings, corrections, and V1.0 exist | SYS-11, SYS-12, SYS-13 | T-10, T-38 |
| REQ-36 | Requirements-to-tests traceability exists | SYS-12 | T-07 |
| REQ-37 | What remains unvalidated until real research is documented explicitly | SYS-17 | T-39 |
| REQ-38 | Four research depths L0 to L3 with L2 resolving gates rather than being blocked by them | STR-03 | T-04 |
| REQ-39 | Fixed 13-step evaluation sequence; verified prohibition stops evaluation; material unresolved legal question quarantines with professional subtype | SYS-07, FWK-09 | T-29, T-30, T-14 |
| REQ-40 | Open/TBD has six subtypes and V1.0 has no placeholders or silently favorable assumptions | STR-05, FWK-34 | T-06 |
| REQ-41 | Every decision-relevant template field has a documented consumer and every engine input exists on a template | STR-12 | T-04, T-54 |
| REQ-42 | Fixtures never enter real records, benchmarks, or rankings | SYS-16, STR-14 | T-05, T-22 |
| REQ-43 | Six bounded reviews run against the frozen baseline; subagent agreement is not corroboration | SYS-11, EVD-05 | T-38, T-23 |
| REQ-44 | Wording cannot change outcomes or evade capital-risk controls | FWK-64, CAP-16 | T-11, T-24 |
| REQ-45 | Rising costs or delays can never improve an assessment | FWK-14, FWK-31 | T-26 |
| REQ-46 | Operator scenarios never become favorable defaults; operator facts live only on the profile | FWK-13, FWK-44, FWK-50, SYS-00, FWK-34 | T-27, T-44, T-47 |
| REQ-47 | New evidence reopens and can change decisions in either direction | FWK-65 | T-21 |
| REQ-48 | Republication is not independent corroboration | EVD-04 | T-28 |
| REQ-49 | Research quantity never substitutes for quality | EVD-12 | T-25 |
| REQ-50 | Track assignment precedes track-specific evaluation | SYS-07, FWK-10 | T-14 |
| REQ-51 | Day-30 qualification ends at usable operator-controlled cash | FWK-04, FWK-30, FWK-31 | T-17 |
| REQ-52 | Design parameters are recorded in the changelog and changed only by version | FWK-60, FWK-13 | T-40 |
| REQ-53 | Every fatal gate has a mechanical test | FWK-02, FWK-03, FWK-04, FWK-05, FWK-06, FWK-07, FWK-08 | T-12 |
| REQ-54 | Every register has a template with schema and the source register carries freshness | STR-07, EVD-01 | T-04 |
| REQ-55 | The frozen V0.1 manifest validates | SYS-13 | T-10 |
| REQ-56 | Five-way validation status is reported | SYS-17 | T-39 |
| REQ-57 | Operator profile intake precedes discovery and holds every operator fact once | SYS-00 | T-04, T-27 |
| REQ-58 | Mandatory claim set per component track; absent claims quarantine | EVD-03, FWK-12 | T-42 |
| REQ-59 | Class B sources inherit upstream tier and admissibility; unregistered upstreams are circular | EVD-04, EVD-02 | T-25, T-50 |
| REQ-60 | Researcher readings never close legality; professional review derived from activity class | FWK-02, FWK-62, EVD-13 | T-29, T-49 |
| REQ-61 | L1 is a FAIL-only screen and quarantine is raised only from L2 | STR-03, FWK-01 | T-04 |
| REQ-62 | Capital component cases are built per CAP-14 and CASH_A is unreachable for capital | CAP-14, FWK-32 | T-16 |
| REQ-63 | LOW-confidence records are listed outside the ordering | FWK-47, FWK-12 | T-46 |
| REQ-64 | Lexicographic levels decide only on disjoint rounded ranges | FWK-42, FWK-43, FWK-63 | T-51, T-52 |
| REQ-65 | Portfolio workload is a weekly profile from critical paths and shared limits are computed by provider | FWK-50, FWK-37 | T-18 |

## Failure modes converted to controls

| ID | Failure mode | Control |
|---|---|---|
| FM-01 | Filtering starts before the universe is covered | SYS-05 |
| FM-02 | Synonyms inflate coverage and trigger false saturation | FWK-20, SYS-06 |
| FM-03 | An affiliate review or course funnel is treated as evidence | EVD-02 |
| FM-04 | Several articles citing one dataset count as multiple sources | EVD-04 |
| FM-05 | Subagents agreeing is mistaken for corroboration | EVD-05 |
| FM-06 | A screenshot establishes earnings | EVD-08 |
| FM-07 | Survivorship: only successes are visible | EVD-07 |
| FM-08 | High attractiveness rescues a fatal failure | FWK-01 |
| FM-09 | Unknown legality treated as probably fine | FWK-02, FWK-09, FWK-62 |
| FM-10 | A viewable site is assumed monetizable and withdrawable from the UAE | FWK-03 |
| FM-11 | A pending balance is counted as cash | FWK-31, FWK-04 |
| FM-12 | A Day-25 sale is counted as Day-30 cash despite a payout delay | FWK-30, FWK-14 |
| FM-13 | Distribution is assumed from an audience-holder's results | FWK-36, EVD-10 |
| FM-14 | A named contact or bespoke approval is hidden inside "partnerships" | FWK-37, FWK-06 |
| FM-15 | Trading labelled "arbitrage" escapes capital-risk controls | CAP-16, FWK-10 |
| FM-16 | A single profitable outcome is called a repeatable mechanism | CAP-11 |
| FM-17 | Returned principal is reported as income | FWK-32 |
| FM-18 | Scalability narrative lifts a 30-day ranking | FWK-15 |
| FM-19 | A composite score hides trade-offs and false precision | FWK-40, FWK-63 |
| FM-20 | Individually feasible candidates form an infeasible portfolio | FWK-50 |
| FM-21 | Operator limits silently assumed generous | FWK-13, FWK-44, FWK-50 |
| FM-22 | Persuasive wording changes a gate value | FWK-64 |
| FM-23 | A stale platform policy supports an approval | FWK-60, SYS-09 |
| FM-24 | Fixture numbers leak into real analysis | SYS-16, STR-14 |
| FM-25 | Placeholders left in a released rule | STR-05 |
| FM-26 | Effort hours confused with elapsed days | FWK-30, FWK-38 |
| FM-27 | Tax, FX, refund tail, and reserves omitted from net cash | FWK-31, FWK-33, FWK-34 |
| FM-28 | Company license scope or account type silently assumed | FWK-34, FWK-37 |
| FM-29 | A rejection based on an unknown rather than evidence | FWK-01 |
| FM-30 | A decision never reopened after contradicting evidence | FWK-65 |
| FM-31 | A missing claim or missing input silently passes | EVD-03, FWK-01 |
| FM-32 | Buyer-side proposal selling hidden because no named person appears | FWK-06 |
| FM-33 | A researcher's reading of a statute treated as legality | FWK-02, EVD-13 |
| FM-34 | Capital at risk assigned to the earned track by typed flags | FWK-10, CAP-16 |
| FM-35 | A class B republication admitted on its own tier | EVD-04 |
| FM-36 | Cold-start deadlock: the only closer of the distribution gate is an experiment the gate blocks | FWK-11, SYS-14 |
| FM-37 | Reserve and refunds double counted; tax provision silently zero | FWK-31, FWK-33, FWK-34 |
| FM-38 | Week-1 setup hours ignored in portfolio workload | FWK-50 |
