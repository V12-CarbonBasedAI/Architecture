# 04 Framework: the decision rules

Owner layer: Framework. This file owns gates, track assignment, bands, deduplication, timing and cash models, feasibility, prioritization, portfolio feasibility, freshness, jurisdiction routing, precision, and reopening. Evidence admissibility rules are in [05-source-governance.md](05-source-governance.md) (EVD). Capital-risk rules are in [06-capital-risk-protocol.md](06-capital-risk-protocol.md) (CAP). Process is in [02-system.md](02-system.md). Field definitions are in [03-structure.md](03-structure.md) and `templates/`.

## Gate semantics

### FWK-01 Gate values and the unknown rule

At L1 a fatal gate takes FAIL or DEFERRED. From L2 onward it takes exactly one of PASS, FAIL, UNKNOWN. A gate is PASS only when the claim rows that support it (EVD-03 mandatory set, linked through `gate_ids`) are VERIFIED_FACT or STRONGLY_SUPPORTED within freshness (FWK-60) and the pass condition holds. FAIL requires admissible evidence of the fail condition. Everything else, including any absent input, is UNKNOWN. UNKNOWN on any fatal gate at the end of L2 or later places the record in QUARANTINED with an Open/TBD subtype (STR-05). UNKNOWN is never treated as PASS, never averaged, never offset by any band, score, or attractiveness. A fatal FAIL cannot be rescued by any other assessment. No reference implementation may default an absent field to a favorable value; absent means UNKNOWN.

Gates are evaluated in the order of SYS-07. Gates G1 to G7 are fatal. Conditional gates C1a to C9 (FWK-11) are not fatal.

### FWK-02 G1 Legality

Fatal. Applies to the activity class in each applicable jurisdiction role: OPERATOR_RESIDENCE, COMPANY_JURISDICTION, CUSTOMER_LOCATION, PLATFORM_JURISDICTION (FWK-61). A jurisdiction whose identity depends on an unsupplied operator-profile input (emirate, residency status, license scope) is unchecked and G1 is UNKNOWN with OPERATOR_INPUT_REQUIRED.

- Evidence required: REG rows for every mandatory jurisdiction role of the activity class (FWK-61), each citing a tier 1 or 2 source within freshness, with `finding_basis`.
- PASS: every mandatory REG row reads NO_RESTRICTION_FOUND with `finding_basis` EXPLICIT_EXEMPTION_TEXT or PROFESSIONAL_OPINION and applicability APPLIES or DOES_NOT_APPLY, and no professional-review trigger (FWK-62) is open.
- FAIL: a REG row with applicability APPLIES reads RESTRICTION_FOUND, or reads LICENSE_REQUIRED with `operator_holds_licence` NO. Result state PROHIBITED.
- UNKNOWN: any mandatory REG row missing, UNRESOLVED, based on RESEARCHER_READING, expired, or with applicability UNCERTAIN; LICENSE_REQUIRED with `operator_holds_licence` OPERATOR_INPUT_REQUIRED; or any FWK-62 trigger open. Result QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED, FURTHER_RESEARCH_REQUIRED, or OPERATOR_INPUT_REQUIRED as the REG row states.
- False positives: a researcher's reading that a statute is silent (RESEARCHER_READING never supports PASS); professional commentary or platform permission treated as legality (EVD-13); license scope assumed.
- False negatives: a RESTRICTION_FOUND row whose applicability is DOES_NOT_APPLY; an outdated rule.
- Reverification triggers: REG expiry, regulatory change notice, operator profile change.

### FWK-03 G2 Platform and account availability

Fatal. Five sub-checks, each valued per account type the operator could use (PERSONAL, COMPANY): (a) sign-up available to a UAE resident or entity; (b) monetization program available; (c) withdrawal available to a rail, currency, and account type the operator can use from the UAE; (d) the platform accepts the operator's KYC document set; (e) any tax-form or taxpayer-identifier requirement is satisfiable by the operator.

- Evidence required: PLATFORM_ELIGIBILITY claim rows at tier 3 within freshness, or logged platform confirmation, for each sub-check and account type.
- PASS: all five sub-checks PASS for the operator's stated account type, or for every type when the profile states BOTH.
- FAIL: any sub-check documented as unavailable for every account type the operator could use. Result REJECTED.
- UNKNOWN: any sub-check undocumented or expired; or availability differs by account type and the profile's account type is OPERATOR_INPUT_REQUIRED. Result QUARANTINED with PLATFORM_CONFIRMATION_REQUIRED or OPERATOR_INPUT_REQUIRED.
- False positives: a viewable site; sign-up possible while monetization is region-locked; withdrawal to an unsupported rail; KYC accepted for identity but not for business verification.
- False negatives: rejecting on one account type when the other is available; an outdated regional list.
- Reverification triggers: PLATFORM_ELIGIBILITY claim expiry, contradiction log entry on regional availability, profile change.

### FWK-04 G3 Payout path to usable operator-controlled cash

Fatal. A documented path must exist from payment capture to money credited and unrestricted in an operator-controlled account (S11b, FWK-30). The rail check belongs to G2(c); G3 consumes it.

- Evidence required: PAYOUT_PATH claim rows at tier 3 for stages S05 to S11b including every intermediary hop, minimum withdrawal amounts, holds, cycles, and KYC-at-withdrawal; per-case threshold attainability citing an EARNINGS_OR_CONVERSION claim; S01 to S04 documented or ESTIMATED with an ASM row.
- PASS: every stage documented, G2(c) PASS, the best case built per FWK-30 reaches S11b on or before Day 30, and threshold attainability for the best case is YES.
- FAIL: G2(c) FAIL; or the best case cannot reach S11b by Day 30; or threshold attainability is NO for every case. Result REJECTED. T4 records failing here are REJECTED with their horizon class recorded and are reopenable per FWK-65.
- UNKNOWN: any stage S05 to S11b undocumented or expired; threshold attainability UNKNOWN for the best case; case ordering invalid (best later than base or base later than conservative is a schema defect, not a pass).
- Precedence: freshness first (expired evidence gives UNKNOWN), then documented FAIL, then remaining UNKNOWN.
- False positives: counting a pending balance; ignoring an intermediary hop or bank-side hold; a payout cycle closing after Day 30.
- False negatives: applying the longest documented hold when a documented shorter path exists for the operator's account type.

### FWK-05 G4 Laptop executability

Fatal. All core work must be executable through a laptop with an internet connection.

- PASS: DEPENDENCY_AVAILABILITY claims show no step requiring physical presence, physical handling of goods by the operator, or undocumented hardware.
- FAIL: any core step requires physical presence or physical labor by the operator. Result REJECTED.
- UNKNOWN: a core step depends on a tool whose laptop availability is undocumented.
- False positives: digital fulfilment whose returns or inspection require physical handling.

### FWK-06 G5 No bespoke-selling or named-individual dependency

Fatal. Cash must not depend on individualized sales calls, proposals, negotiation, networking, bespoke approvals, or any named individual.

- Inputs: `sales_mode` on the record; `interaction_mode`, `blocks_cash`, and `dependency_type` on every dependency row; the dependency map completeness attestation.
- PASS: `sales_mode` is SELF_SERVICE_CHECKOUT or STANDARDIZED_PROGRAM_PAYOUT; no dependency row has `interaction_mode` INDIVIDUALIZED_NEGOTIATION or SPONSORED_BY_NAMED_PERSON with `blocks_cash` true; no row is HUMAN_NAMED; the map is attested complete by a perspective other than the Discoverer.
- FAIL: `sales_mode` QUOTE_OR_PROPOSAL or NEGOTIATED; any HUMAN_NAMED row; any cash-blocking row with INDIVIDUALIZED_NEGOTIATION or SPONSORED_BY_NAMED_PERSON. Result REJECTED.
- UNKNOWN: `sales_mode` undocumented or the map not attested complete.
- Note: standardized applications and KYC are dependencies, not bespoke approvals.

### FWK-07 G6 Platform-policy compliance

Fatal. The mechanism must not require violating the terms of any platform it depends on.

- Evidence required: a PLATFORM_POLICY_COMPLIANCE claim at tier 3 within freshness per platform dependency, with `policy_finding`.
- PASS: every such claim is VERIFIED_FACT with `policy_finding` PERMITTED or NOT_ADDRESSED.
- FAIL: any claim with `policy_finding` PROHIBITED: multi-accounting, incentive abuse, misrepresentation, prohibited automation, geographic evasion, or any prohibited action. Result REJECTED.
- UNKNOWN: any claim UNKNOWN, OUTDATED, or missing.

### FWK-08 G7 Ethical exclusion

Fatal. The mechanism must not depend on deceiving buyers or payers, harming third parties, exploiting vulnerable users, or fraudulent conduct.

- PASS: the required conduct is documented and none of the above is required. FAIL: any of the above is required; result PROHIBITED. UNKNOWN: the required conduct is undocumented.

### FWK-09 Gate order, stop rules, and overrides

Gates run in the SYS-07 order. A verified G1 or G7 FAIL ends evaluation; no band is assigned. A material unresolved legal question (derived per FWK-62, never hand-set) produces QUARANTINED with subtype PROFESSIONAL_LEGAL_REVIEW_REQUIRED and takes precedence over every other quarantine reason, band, class, ordering, or experiment result. Bands are assigned only in the states listed in STR-04. No gate value may be inferred from a band, from another record, or from the persuasiveness of a description (FWK-64).

## Tracks and conditional gates

### FWK-10 Track assignment from structured fields

Applied at SYS-07 step 2, before any track-specific evaluation. Descriptions, names, and marketing terms never determine the track (CAP-16). Component tracks are derived:

1. Capital component (T2) is present when any of: `capital_role` is AT_RISK_CAPITAL; `payer_types` contains MARKET_COUNTERPARTY or PROTOCOL; `settlement_mechanism` is EXCHANGE_OR_BROKER or ON_CHAIN; `operator_supplies` contains CAPITAL; `at_risk_capital` high bound is greater than zero; `refundable_stake` high bound is greater than zero; any dependency row has type CUSTODY_COUNTERPARTY.
2. Reward component (T3) is present when `cash_source_is_reward` is true, that is cash comes from a sponsor, platform, or protocol as a referral, reward, grant, prize, bounty, or incentive rather than from a buyer of delivered value.
3. Asset component (T4) is present when the base-case timing model reaches S11b after Day 30 (FWK-30); at L1 the provisional input is `asset_build_first`, re-derived at L3.
4. Earned component (T1) is present when `payer_types` contains CONSUMER or BUSINESS and value is delivered in a standardized transaction.

Track is the single present component, or T5 when two or more are present. `component_tracks` and the rule steps that fired are recorded. Any T5 record inherits the full control set of every component. Stakes, bonds, deposits, and entry fees refundable on condition are at-risk capital, never direct costs.

### FWK-11 Conditional gates

Not fatal. An open ordering-required conditional gate keeps the record in CONDITIONAL. Conditional gates cannot be traded against each other or against bands.

| Gate | Closed when | Required for ELIGIBLE |
|---|---|---|
| C1a Channel open to a new account | FWK-36 part (a) | Yes |
| C1b Cold-start performance | FWK-36 part (b); the operator's own MEASURED experiment is the primary closer | Yes, but a record with only C1b open may enter VALIDATION_PENDING (STR-04) |
| C2 Dependency map | FWK-37 attested complete with no cash-blocking dependency at UNKNOWN availability | Yes |
| C3 Economic model | FWK-31 complete for all three cases with no UNKNOWN required input | Yes |
| C4 Timing model | FWK-30 complete for all three cases | Yes |
| C5 Capital-risk protocol | CAP-01 satisfied: no CAP field UNKNOWN (T2 component only; closed by default otherwise) | Yes |
| C6 Validation experiment | Designed per FWK-35 | No; designed only for records selected under SYS-14 |
| C7 Freshness | Every supporting claim within FWK-60 limits | Yes |
| C8 Contradiction search | EVD-09 count rule satisfied | Yes |
| C9 Feasibility | FWK-38 status WITHIN or BEYOND (not UNKNOWN); BEYOND is reported, not blocked | Yes |

## Bands and classes

### FWK-12 Evidence-confidence bands

Assigned from the mandatory claim set (EVD-03) of the record's component tracks, citing the claim IDs that determined the band. A missing mandatory claim is UNKNOWN.

| Band | Condition |
|---|---|
| HIGH | Every mandatory claim is VERIFIED_FACT or STRONGLY_SUPPORTED, so every performance claim has at least two independent origins |
| MODERATE | Every mandatory claim is at least DIRECTIONAL and none is UNKNOWN, OUTDATED, or an unresolved CONTRADICTION |
| LOW | Any mandatory claim is INFERENCE, ASSUMPTION, or HYPOTHESIS, and none is UNKNOWN, OUTDATED, or an unresolved CONTRADICTION |
| UNRESOLVED | Any mandatory claim is UNKNOWN, OUTDATED, or an unresolved CONTRADICTION; the record is QUARANTINED and the band is not published |

Volume of sources never moves a band (EVD-12). LOW records are listed outside the ordering as insufficient-evidence (FWK-47).

### FWK-13 Risk classification

Risk types recorded: CAPITAL_LOSS, LEVERAGE, PLATFORM_ACCOUNT_OR_PAYOUT, COUNTERPARTY_OR_CUSTODY, REGULATORY, REFUND_OR_CHARGEBACK, OPERATIONAL, REPUTATIONAL, CONCENTRATION. For each record the `max_plausible_loss` range and the capital exposure are compared with the operator profile's loss limit and capital limit. Hours belong to FWK-38, not here.

| Class | Condition |
|---|---|
| R1 Within limits | Every exposure high bound is below 80 percent of the relevant limit |
| R2 Near limits | Any exposure high bound is between 80 and 100 percent of a limit |
| R3 Beyond limits | Any exposure high bound exceeds a limit |
| R0 Not assessable | Any relevant limit is OPERATOR_INPUT_REQUIRED, or `max_plausible_loss` or counterparty status is UNKNOWN |

R0 is the state until the operator profile supplies limits; R0 records are listed as unassessed and are not ordered (FWK-47). The 80 percent threshold is a design parameter (CHANGELOG).

### FWK-14 30-day cash compatibility bands

Computed from the timing model (FWK-30) and economic model (FWK-31) per case. A case supports the horizon when its S11b day is on or before Day 30 and its pre-tax net collectible cash range has a low bound greater than zero. For a capital component the cases are built per CAP-14.

| Band | Condition |
|---|---|
| CASH_A | Conservative case supports |
| CASH_B | Base case supports, conservative does not |
| CASH_C | Best case supports only; always labelled "best case only" |
| CASH_D | No case supports; rendered ELIGIBLE_NO_30D_CASH when gates pass |
| CASH_U | Any required timing or economic input is UNKNOWN |

Raising any cost, hold, or delay can never move a record to a better band (T-26).

### FWK-15 Horizon classes and the scalability rule

`horizon_class` is computed from the base-case S11b day: H30 on or before Day 30, H90, H365, H_OPEN when UNKNOWN. Long-term scalability, asset value, or growth potential is recorded only in `scalability_note`, whose sole consumer is the report limitations section (STR-10). No gate, band, class, dominance comparison, tie-breaker, or scenario ordering may read it. A CASH_D or T4 record never appears in a 30-day ordering.

## Deduplication and coverage

### FWK-20 Mechanism deduplication and variants

Run at the discovery freeze (SYS-05), before coverage counting and before any screening. Two sightings whose signature fields (STR-13) are equal belong to one mechanism (MEC). Within a MEC, two sightings with equal variant fields are one OPP: the sighting with the more complete identity and variant fields survives, ties going to the earliest `first_seen`, and the other becomes MERGED with `merged_into` set. Sightings with equal signature and different variant fields are separate OPPs under the same MEC and are evaluated separately for G2, G3, G6, timing, and cash; the MEC is rejected only when every OPP under it is rejected. A MERGED OPP is promoted to SCREENED by DEC record when the survivor fails a variant-specific gate. Coverage (FWK-21) and saturation (SYS-06) count MECs only.

NEAR_DUPLICATE is flagged when exactly one signature field differs. Rule: merge as one MEC when the differing field is `payment_rail` or `platform_dependency_class` and the difference arises only from platform choice; otherwise keep separate. Every merge, promotion, and near-duplicate decision writes a DEC record naming both identifiers and the rule branch.

### FWK-21 Category coverage audit

At the freeze and before any report, the coverage audit records for every family F01 to F14: family sweeps completed, sightings, unique mechanisms after deduplication, near-duplicate flags, saturation status (SYS-06), negative-evidence queries run, and query novelty. For F15 and F16 it records the review result (SYS-05). COVERAGE_INCOMPLETE is declared when any family F01 to F14 has a PARTIAL sweep or is UNSATURATED at the freeze, with `reason` from BUDGET_EXHAUSTED, TIME_BOX, SOURCE_ACCESS. The audit also records the three structured bias reviews (SYS-05), languages and markets not searched, and families with zero mechanisms after a complete sweep, which must be stated. Coverage status is written on the DISCOVERY_FREEZE decision record and printed in every ordering header (STR-10).

## Timing and cash models

### FWK-30 Thirty-day timing model

Day 0 is a record-level field: the date the decision to execute is recorded in the decision log, or UNDATED during research, in which case day counts are relative. Days are calendar days. Stages carry an elapsed-days range per case, `timing_tag` CALENDAR_FIXED or EFFORT_DRIVEN, `sequence_tag` SEQUENTIAL or PARALLEL with the stage overlapped, a source, and a per-case provenance.

| Stage | Meaning |
|---|---|
| S01 | Setup and account creation |
| S02 | KYC, identity, or program approval |
| S03 | Distribution start |
| S04 | First sale or qualifying event |
| S05 | Payment capture |
| S06 | Hold or reserve period |
| S07 | Payout eligibility reached (threshold and cycle) |
| S08 | Payout request |
| S09 | Payout processing |
| S10 (repeatable, `hop_index`) | Receipt into an intermediary account; each hop records minimum withdrawal amount and any KYC-at-withdrawal |
| S11a | Withdrawal to the operator-controlled account initiated |
| S11b | Credited, converted, and unrestricted in the operator-controlled account, including inbound bank hold |

Stage mapping by settlement mechanism: PLATFORM_PAYOUT uses S06 to S09 then S10 hops; DIRECT_PROCESSOR skips S07 cycles unless documented; EXCHANGE_OR_BROKER maps S05 to trade settlement and S10 to exchange or broker withdrawal; ON_CHAIN maps S10 hops to wallet, exchange off-ramp, and fiat receipt. Usable-cash day per case is Day 0 plus the sequential sum of elapsed days with PARALLEL stages overlapping their named stage. Cases: conservative uses the documented maximum for CALENDAR_FIXED stages, one full cycle plus processing for cycle-based stages (cut-off missed), the high estimate for EFFORT_DRIVEN stages, and thresholds unmet unless attainability is YES; base uses typical values and half a cycle; best uses documented minimums and is built only from DOCUMENTED or MEASURED values, ESTIMATED stages taking their high value. Effort hours are recorded separately and never substitute for elapsed days; for every EFFORT_DRIVEN stage elapsed days must be at least effort hours divided by the operator's daily hours (weekly limit divided by seven), else the case is UNKNOWN. A stage with no documented value is UNKNOWN and forces CASH_U. Only S11b ends the model.

### FWK-31 Net collectible cash model

For each case, pre-tax by construction:

```
NCC = receipts_gross captured on or before Day 30 (must cite an EARNINGS_OR_CONVERSION claim)
    - reserve_withheld at Day 30 (timing item; reported as a contingent asset)
    - refunds_realized on or before Day 30
    - refund_provision = (receipts_gross - refunds_realized) within refund_tail_days x refund_rate (FWK-33)
    - platform fees
    - payment processing fees
    - dispute fees
    - withholding_at_source
    - direct costs incurred on or before Day 30 (tools, advertising including cold_start_channel_cost, fulfilment)
    - withdrawal and currency conversion costs (FWK-34)
    - recovered_principal (FWK-32, computed)
```

`ncc_after_tax` exists only when `tax_status` is RESOLVED by a logged professional opinion id. Costs count when incurred even if the related revenue never arrives. The following never count as receipts or net cash: views, followers, leads, trial users, monetization eligibility, pending marketplace balances, balances below payout thresholds, unrealized gains, theoretical asset value, and sales that cannot reach S11b by Day 30. Returned principal is part of gross proceeds and never part of net cash. Any required input at UNKNOWN makes the case UNKNOWN. NCC inherits the worst provenance class of its inputs (FWK-63).

### FWK-32 Recovered principal and realized return

For a capital component, `recovered_principal` is computed as the lesser of receipts_gross and `capital_deployed` for the case; it is never typed. It is subtracted from receipts, reported in its own field on every dashboard, and is never classified as income, receipts, or return in any field or ordering. `realized_return` equals receipts_gross minus recovered_principal minus costs. Unrealized gains are excluded entirely.

### FWK-33 Reserve, refund, and chargeback tail

Applies to PLATFORM_PAYOUT and DIRECT_PROCESSOR settlement with CARD, WALLET, or PLATFORM_BALANCE rails. Each record documents `refund_tail_days` and `refund_rate` for the mechanism; `reserve_withheld` is the documented platform or processor reserve at Day 30. If the refund rate is undocumented the conservative case is UNKNOWN. For EXCHANGE_OR_BROKER and ON_CHAIN settlement the refund rate is zero by rail type, recorded as DOCUMENTED, and CAP-06 withdrawal fees and holds apply instead. Any tail extending past Day 30 is a contingent liability disclosed on D4.

### FWK-34 Currency conversion, withholding, tax, and account type

Conversion uses the documented rate on the access date with the rate source logged; the conservative case widens the AED figure by the FX band design parameter. Withholding at source documented at tier 3 is a realized deduction. `tax_status` defaults to PROFESSIONAL_TAX_REVIEW_REQUIRED and becomes RESOLVED only with a professional opinion id; every NCC header reads "pre-tax". Account type, license scope, residency, and rails come only from the operator profile (SYS-00); no candidate record may assert them.

## Feasibility, validation, distribution, dependencies

### FWK-35 Validation experiment constraints

A minimum legal validation experiment is preregistered with: the claim it tests; `exp_metric` and `exp_threshold`; `exp_max_days` not exceeding 14; `exp_max_spend` not exceeding the profile's experiment budget (OPERATOR_INPUT_REQUIRED until stated); `exp_accounts_used` limited to accounts the operator already holds (a fresh account is itself a G6 multi-accounting check); reversibility or a bounded disclosed downside; no misleading claim to any buyer or platform; no pre-selling of anything the operator cannot deliver; compliance with G1, G6, and any A7 data obligation; and a result recorded whether POSITIVE, NEGATIVE, or AMBIGUOUS. Experiments are designed only for records selected under SYS-14, capped per cycle by the profile. A result is evidence about the tested claim only.

### FWK-36 Cold-start distribution verification

Part (a), C1a: at least one channel with `channel_entry_type` in OPEN_MARKETPLACE_SEARCH, PAID_ADS, ALGORITHMIC_FEED, or STANDARDIZED_APPLICATION, evidenced by a tier 3 source that a new account can enter it; FOLLOWER_BASED and INVITE_ONLY channels never close C1a. Part (b), C1b: a DISTRIBUTION_PERFORMANCE claim whose source records `starting_audience_documented` ZERO (EVD-10), or a MEASURED result from the operator's own preregistered cold-start experiment. Channel cost is recorded as `cold_start_channel_cost` and flows into FWK-31. A record whose distribution is described but not evidenced carries `assumed_distribution` true and both parts stay open.

### FWK-37 Dependency mapping

Every L2 record lists each dependency with `dependency_type`, `provider_id`, `interaction_mode`, `blocks_cash`, `availability_status` with its evidence id, and `failure_impact`. Types: HUMAN_NAMED, HUMAN_ROLE, PLATFORM_APPROVAL, KYC_IDENTITY, PAYMENT_PROCESSOR, SUPPLIER_FULFILMENT, SUPPORT_BURDEN, ACCOUNT_LIMIT, TOOLING, OPERATOR_COMPANY, CUSTODY_COUNTERPARTY. The map is complete only when attested by a perspective other than the Discoverer; an unattested map leaves G5 UNKNOWN. OPERATOR_COMPANY availability comes only from the operator profile. `provider_id` values are shared across records so that FWK-50 can compute shared limits and concentration.

### FWK-38 Time, capital, skill, and workload feasibility

Each L2 record states setup hours, recurring weekly hours, support hours, required skills from the controlled skill list with `gap_status` (NONE, LEARNABLE_IN_SETUP, BLOCKING), setup capital, working capital, and at-risk capital, all as ranges with provenance. `capital_total` is the sum of setup, working, and at-risk capital. Feasibility status is WITHIN when recurring hours plus support hours high bound is within the profile's weekly hours and no skill gap is BLOCKING without a documented no-code substitute; BEYOND when either fails; UNKNOWN when the profile is missing. BLOCKING skill gaps with no substitute make the record REJECTED with reason FEASIBILITY. Effort and elapsed time are never interchanged (FWK-30).

## Prioritization

### FWK-40 Prioritization sequence

There is no composite score. Ordering proceeds in this fixed sequence, within one track at a time:

1. Eligibility: only records satisfying FWK-47 enter; all others are listed by reason.
2. 30-day cash compatibility band (FWK-14).
3. Evidence-confidence band (FWK-12).
4. Risk class (FWK-13) and feasibility status (FWK-38) for the scenario in force.
5. Within-track non-dominance grouping (FWK-41).
6. Lexicographic fallback inside each front (FWK-42).
7. Explicit tie-breakers (FWK-43).
8. Bounded scenario-dependent ordering (FWK-44).

Steps 2 to 4 partition records into groups ordered CASH_A before CASH_B before CASH_C; HIGH before MODERATE; R1 before R2 before R3; WITHIN before BEYOND. Groups are never interleaved.

### FWK-41 Within-track non-dominance

Inside a group, record A dominates record B when A is at least as good on every dimension and strictly better on at least one, comparing the full ranges after FWK-63 rounding: conservative NCC (higher), conservative S11b day (earlier), recurring plus support hours (fewer), `capital_total` (lower), `max_plausible_loss` (lower). A range is at least as good when both bounds are at least as good; strictly better only when the ranges are disjoint. Non-dominated records form the front. Dominated records list every dominator and are ordered by successive fronts.

### FWK-42 Lexicographic fallback

Inside a front, records are compared level by level: conservative NCC, conservative S11b day, `max_plausible_loss`, hours. A level decides the order only when the rounded ranges are disjoint; otherwise the comparison falls to the next level, then to FWK-43, then to a preserved tie. This is declared as lexicographic ordering, not a composite, and each output states the level that decided.

### FWK-43 Tie-breakers

Applied only when every FWK-42 level is undecided. In order: lower `max_plausible_loss` high bound; earlier conservative S11b; lower hours high bound; cheaper and more reversible validation experiment (`exp_max_spend`, then reversibility); lower platform concentration (fewer SINGLE_PLATFORM or CUSTODIAL dependencies by `provider_id`). Each applies only when the values are disjoint after rounding; otherwise the tie is preserved (FWK-46).

### FWK-44 Bounded scenario-dependent ordering

Scenario variables and their class thresholds are design parameters (CHANGELOG): capital available and loss tolerance classes C0 (0 AED), C1 (up to 2,000 AED), C2 (2,001 to 10,000 AED), C3 (above 10,000 AED); weekly hours classes H1 (under 10), H2 (10 to 25), H3 (over 25); account access PERSONAL, COMPANY, BOTH. The default published set is the eight scenarios H1 or H2 by C0 or C1 by PERSONAL or COMPANY; the operator profile selects the applicable one and may replace the set with at most eight named scenarios. No probability is assigned to any scenario. Every scenario table row states its inputs in full.

### FWK-45 Cross-track reporting

Each track is ordered separately. The cross-track table lists each record's track and components, cash band, confidence band, risk class, feasibility status, conservative pre-tax NCC range in AED, conservative S11b day, hours, and `capital_total`, with units normalized and differences disclosed, and carries no rank column. T2 records and T5 records with a capital component are ordered with T2 and never appear in an income ordering; T4 records appear only in a horizon list. Realized return and recovered principal are separate columns.

### FWK-46 Ties and incomparability

Genuine ties and incomparable pairs are preserved and labelled. No rule may force a total order.

### FWK-47 Prioritization eligibility

A record enters an ordering only when: state is ELIGIBLE or VALIDATED; L3 complete; every fatal gate PASS; every ordering-required conditional gate closed; confidence band HIGH or MODERATE; cash band CASH_A, CASH_B, or CASH_C; risk class R1, R2, or R3 for the scenario in force; feasibility status WITHIN or BEYOND; every supporting claim within freshness; and, for a T2 component, edge status at least STRONGLY_SUPPORTED with a logged professional opinion. Records failing a condition are listed outside the ordering under the first failing reason: unassessed-risk (R0), insufficient-evidence (LOW), no-30-day-cash (CASH_D), unresolved (CASH_U), or their state.

## Portfolio

### FWK-50 Portfolio feasibility gate

A portfolio of individually eligible records is feasible only when all hold: the weekly workload profile, built per member from the critical path (setup hours spread over S01 to S03 elapsed days, recurring hours from S03, support hours from S04, summed across members week by week), has a peak week within the profile's weekly hours; peak simultaneous capital, computed over each member's S01 to S11b window as setup plus working plus at-risk capital, is within the capital limit; aggregate `max_plausible_loss` is within the loss limit; shared providers, computed by `provider_id` across dependency rows, exceed no documented ACCOUNT_LIMIT and trigger a G6 multi-accounting check when two members use one platform account; correlated platform, counterparty, regulatory, and market risks are grouped by `provider_id` and risk type. Any limit that is OPERATOR_INPUT_REQUIRED makes the result CONDITIONAL with the breakpoint at which the portfolio would fail. Any UNKNOWN shared limit or correlation on a cash-blocking dependency blocks approval. Individual feasibility never establishes portfolio feasibility.

## Freshness, jurisdiction, precision, reopening

### FWK-60 Source freshness limits

Freshness class is derived from tier. Age is measured from the earlier of the source's last-updated date and its access date; a source with no update date is tier 7 at most (EVD-11). A source whose effective date is later than the access date is PENDING and every claim it supports is UNKNOWN.

| Tier | Freshness limit | Rationale |
|---|---|---|
| 3 platform sources | 30 days | Changes frequently and without notice |
| 1 and 2 regulatory sources | 90 days | Changes on announcement cycles |
| 4 and 5 datasets and research | 365 days | Slower-moving; still dated |
| 6 and 7 practitioner and community | 180 days | Discovery use only |

A claim whose every admissible source has expired is OUTDATED, and every gate linked to it through `gate_ids` becomes UNKNOWN until reverified. Limits are design parameters (CHANGELOG).

### FWK-61 Jurisdiction routing question matrix

Routing separates five facts: operator residence (emirate and residency status from the operator profile), company jurisdiction (registered free-zone company; licensed activity scope from the profile), customer location, platform jurisdiction, and activity class. For each activity class the matrix lists questions to verify and authority classes; authority names live only in the authority register with `confirmed_at` and `remit_source_id`, refreshed under the 90-day limit. Nothing in this matrix is a legal conclusion. Platform policy is never an authority here; it belongs to G6.

Mandatory REG rows: OPERATOR_RESIDENCE and COMPANY_JURISDICTION for every record; PLATFORM_JURISDICTION for every platform dependency, citing the platform's stated governing law; CUSTOMER_LOCATION for classes A3 to A7, A10, and A14, and for every other class a row "customer location: worldwide" with applicability UNCERTAIN that forces professional review unless a tier 1 or 2 source states the activity is not customer-regulated. A14 applies to every record.

| Activity class | Questions to verify | Authority classes |
|---|---|---|
| A1 Sale of digital goods or services | Within licensed scope? Personal-capacity sale permitted? E-commerce and consumer rules? | Free-zone authority; federal economy ministry; consumer-protection body |
| A2 Advertising, affiliate, marketing services | Advertising standards, disclosure, influencer or advertiser permits? | Media regulator; free-zone authority |
| A3 Financial promotion or advice | Does any content constitute regulated promotion or advice? | Federal securities regulator; financial free-zone regulators |
| A4 Securities, derivatives, FX trading | Venue licensed for UAE residents? Leverage or product restrictions? Tax treatment? | Federal securities regulator; central bank; financial free-zone regulators; federal tax authority |
| A5 Virtual assets | Activity, venue, or service permitted or licensed for UAE residents? Does the operator's own activity require a license? | Emirate-level virtual-asset regulator; federal securities regulator; central bank; financial free-zone regulators |
| A6 Payments, transfers, money-transmission-like activity | Does handling others' funds or facilitating payments require authorization? | Central bank |
| A7 Data collection, monitoring, personal data | Data-protection obligations for collected or resold data? Telecom rules for bandwidth or proxy resale? | Federal data-protection authority; free-zone data regimes; telecom regulator |
| A8 Competitions, prizes, bounties | Prize or promotion rules or permits engaged? | Emirate economic department |
| A9 IP licensing | Ownership, rights clearance? | IP office |
| A10 Consumer sales and VAT-relevant commerce | VAT registration thresholds, corporate tax, invoicing rules? | Federal tax authority; free-zone authority |
| A11 Physical goods and customs | Import, customs, product-safety, physical-goods consumer rules? | Customs authority; standards body |
| A12 Transfer of digital properties and accounts | Legal transferability of accounts, domains, and properties? | Free-zone authority; platform governing law via G6 |
| A13 Gaming-adjacent and wagering-like contests | Gaming, lottery, or wagering rules engaged? | Federal gaming regulator; emirate economic department |
| A14 Sanctions and AML (cross-cutting) | Customer-location screening and AML obligations for the activity? | Central bank; federal AML authority |

Family-to-class default mapping: F01, F05, F06, F07 to A1 plus A7 or A9 as triggered; F02 to A1 plus A12 where accounts transfer; F03, F04, F09 to A2 plus A8 for prizes; F08 to A1, A10, A11; F10 to A12; F11 to A8 plus A13 where contest structure is wagering-like; F12 to A3, A4; F13 to A3, A5; F14 to A4, A5, or A6 as triggered; F15 and F16 by component. Every record adds any triggered class.

### FWK-62 Professional verification rule

Professional review is mandatory, the matching subtype is set, and `material_unresolved_legal_question` is derived true whenever: the activity class includes A3, A4, A5, or A6; any REG row is UNRESOLVED with applicability APPLIES or UNCERTAIN; a tax question arises; the company's license scope is engaged; or binding law must be interpreted against the operator's facts and no EXPLICIT_EXEMPTION_TEXT exists. Researcher interpretation cannot close such an item, and the record is QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED until a professional opinion id is logged (FWK-09).

### FWK-63 Precision and numeric provenance

Every quantity is a range with a provenance class (STR-11). Derived quantities inherit the worst provenance class among their inputs and display it. Reports show at most two significant figures and ordering comparisons use the rounded bounds. No probability is stated without a documented basis. Point estimates for demand, earnings, conversion, or edge are permitted only with MEASURED or DOCUMENTED provenance. ESTIMATED values name their basis in the assumption register.

### FWK-64 Wording invariance

Gates, bands, classes, and orderings consume only structured fields. Free-text descriptions, persuasive language, source volume, and presentation never change any output. Every structured field that carries an evidential judgment cites a `basis_id` (STR-12). Two records with identical structured fields must produce identical outputs (T-24).

### FWK-65 Reopening on new evidence

A new admissible source, a contradiction log entry with result FOUND_MATERIAL, a platform or regulatory change, a freshness expiry, a validation result, or an operator profile change reopens the record at the earliest SYS-07 step it affects. Prior values are preserved in the decision log. A record may move in either direction, including from REJECTED or PROHIBITED back to SCREENED and from ELIGIBLE to QUARANTINED.

### FWK-66 Quarantine exit

A QUARANTINED record exits only when the named blocking item is resolved by an admissible source of the required tier (EVD-03), a logged operator profile input, a logged platform confirmation, or a logged professional opinion, matching the Open/TBD subtype. `exit_condition` is structured as the subtype plus the required evidence class. Evaluation then resumes at the producing step. If the recheck date passes unresolved, the record stays QUARANTINED and is flagged STALE on D1.
