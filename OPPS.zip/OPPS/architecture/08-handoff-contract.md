# 08 Handoff contract for later real research

Owner layer: System (SYS-17). This file binds any later mass-research cycle that uses this architecture. It lists obligations, the unresolved variables by Open/TBD subtype and timing group, and what the architecture does not establish.

## Obligations of any research cycle

1. Open the operator profile first (SYS-00) and record every unsupplied fact once with its subtype. Never assert a profile fact on a candidate record (FWK-34).
2. Create the `research/` root for every real record; keep fixtures out of it (SYS-16). The validator scans it.
3. Declare Day 0 in the decision log before any timing model is dated (FWK-30); use UNDATED until then.
4. Run family sweeps across F01 to F14 under three lenses with the verbatim query log, search surface, language, and novelty fields (SYS-03, SYS-04).
5. At the freeze (SYS-05), resolve identity fields, deduplicate into mechanisms and variants (FWK-20), complete the coverage audit (FWK-21), run the three structured bias reviews and the F16 review through the Adversary.
6. Evaluate every OPP in the fixed 13-step order (SYS-07): L1 is FAIL-only, L2 resolves every fatal gate, L3 decides. Never skip a step, never infer a gate from a band, never let wording change an output (FWK-64).
7. Hold one claim row per mandatory class of each component track (EVD-03); compute claim status, never type it (EVD-06). Register every source with origin, upstream, incentive, operator position, and dates.
8. Treat every UNKNOWN fatal gate, missing input, or missing mandatory claim as quarantine with a subtype, resolver, and recheck date (FWK-01, SYS-10).
9. Route every candidate through the jurisdiction matrix with mandatory rows (FWK-61); record `finding_basis` on every REG row; never let a researcher reading close G1 (FWK-02); set professional-review subtypes where FWK-62 applies and log opinion ids before any capital-risk record leaves quarantine (CAP-13).
10. Derive component tracks from structured fields only (FWK-10). Apply the full capital-risk protocol to every T2 component; build its cases per CAP-14; report recovered principal separately (FWK-32); report expected return as UNKNOWN when edge is unknown (CAP-14).
11. Verify every supporting claim's freshness before any ELIGIBLE transition or ordering (FWK-60, SYS-09).
12. Publish orderings per track only, with reason lists, dominance groups, named deciding levels, tie-breakers, preserved ties, and the bounded scenario table (FWK-40 to FWK-47). Never publish a composite score. Publish no ordering while the profile is absent.
13. Design experiments only for selected records (SYS-14) with structured preregistration (FWK-35).
14. Test every proposed portfolio with weekly profiles and provider-keyed shared limits (FWK-50).
15. Publish the five dashboards, reason lists, per-family saturation with any COVERAGE_INCOMPLETE header, freshness status, and the five-way validation status (SYS-17). Label every cash figure pre-tax.
16. Record every transition, merge, promotion, near-duplicate decision, taxonomy review, freeze, reopening, and experiment result in the decision log with prior values preserved (STR-04, FWK-65).
17. State in every report that saturation is a stopping rule and not exhaustive discovery (SYS-06).

## Unresolved variables by timing group

| Timing group | Variable | Open/TBD subtype | Effect until resolved |
|---|---|---|---|
| Before discovery | Research budget in queries and hours | OPERATOR_INPUT_REQUIRED | Sweeps may end COVERAGE_INCOMPLETE |
| Before discovery | Languages and markets to search | OPERATOR_INPUT_REQUIRED | Coverage audit records them as not searched |
| Before discovery | Bias floors and scenario thresholds as calibrated design parameters | FURTHER_RESEARCH_REQUIRED | Defaults in CHANGELOG apply |
| Before screening | Account types available | OPERATOR_INPUT_REQUIRED | G2 UNKNOWN where availability differs by type |
| Before screening | Free-zone license activity scope | OPERATOR_INPUT_REQUIRED and PROFESSIONAL_LEGAL_REVIEW_REQUIRED | G1 UNKNOWN where LICENSE_REQUIRED; OPERATOR_COMPANY dependencies unresolved |
| Before screening | Emirate, residency status, existing rails | OPERATOR_INPUT_REQUIRED | Jurisdiction roles unchecked; G1 UNKNOWN |
| Before decision | Capital available, loss limit, weekly hours | OPERATOR_INPUT_REQUIRED | R0, feasibility UNKNOWN, no ordering |
| Before decision | Experiment budget and per-cycle cap | OPERATOR_INPUT_REQUIRED | Experiments designed but not run |
| Before decision | Skills held | OPERATOR_INPUT_REQUIRED | Skill gaps unassessed |
| Before decision | Tax treatment | PROFESSIONAL_TAX_REVIEW_REQUIRED | All cash pre-tax |
| Before decision | Regulatory status for A3 to A6 and A14 for the operator | PROFESSIONAL_LEGAL_REVIEW_REQUIRED | Affected records QUARANTINED |
| Before portfolio | Preferences over risk types and target cash amount | OPERATOR_INPUT_REQUIRED | Portfolio CONDITIONAL with breakpoints |
| Continuous | Platform policies, fees, payout, eligibility, KYC documents | PLATFORM_CONFIRMATION_REQUIRED | Reverified per FWK-60 |
| Continuous | Authority register entries | FURTHER_RESEARCH_REQUIRED | Confirmed at check dates |
| Continuous | Availability of the EVD-14 methodological references | FURTHER_RESEARCH_REQUIRED | Cite with access date at first use |

## What this architecture does not establish

It does not establish that any opportunity exists, is legal for the operator, is available from the UAE, will produce demand, will pay out, will be profitable, has a financial edge, or ranks above any other. It does not prove real-world income or investment performance. Fixture outcomes are logical tests only. The reference engine models the rules; it is not a substitute for reading them. Every such question is answered, if at all, by a later research cycle operating under this contract, and many will remain Open/TBD with a subtype.
