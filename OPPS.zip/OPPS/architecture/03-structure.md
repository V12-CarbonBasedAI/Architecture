# 03 Structure: the information architecture

Owner layer: Structure. This file owns taxonomies, identifiers, record depths, states, registers, dashboards, report organization, units, and schema conventions. Field-level schemas live in `templates/`. Process is in [02-system.md](02-system.md). Decision rules are in [04-framework.md](04-framework.md).

## Universe taxonomy

### STR-01 Discovery families and secondary dimensions

Sixteen discovery families define the search territory. They are exploration buckets, not endorsements and not survival quotas. F01 to F14 are searchable families. F15 and F16 are assignment classes: they receive records but are exempt from the per-family query minimum (SYS-03) and saturate by review (SYS-06). Every L0 sighting carries exactly one primary family and any number of secondary families.

| ID | Family | Scope note |
|---|---|---|
| F01 | Digital products | Standardized digital goods sold to unknown buyers |
| F02 | Marketplaces and platform-native economies | Value exchanged inside a platform's own market; includes standardized services and productized labor sold per unit through self-service listings |
| F03 | Media and attention | Cash from audience attention paid by a platform program or sponsor |
| F04 | Marketing and distribution | Cash from a business for delivered demand, traffic, or conversions |
| F05 | Software and automation | Tools, no-code products, bots, APIs, automations sold or metered; includes rental of digital capacity such as compute, storage, bandwidth, API quota, or seats |
| F06 | Data and research | Datasets, monitoring, curation, research products; includes paid participation as a data subject (surveys, usability tests, labeling) |
| F07 | Licensing and intellectual property | Rights-based cash from digital IP |
| F08 | Digitally fulfilled commerce | Physical or hybrid goods with fulfilment by third parties |
| F09 | Referrals, incentives, and partner programs | Referral, onboarding, partner rewards; includes cashback, loyalty-point liquidation, and gift-card conversion |
| F10 | Online properties and digital assets | Websites, domains, accounts, and other transferable digital properties |
| F11 | Competitions, grants, and bounties | Prize, grant, and bounty cash; includes prediction, skill-contest, and wagering-like structures, whose legality G1 decides |
| F12 | Regulated financial markets | Stocks, ETFs, currencies, derivatives, and other regulated instruments |
| F13 | Crypto and digital-asset systems | Digital assets, staking, protocol incentives, and related mechanisms |
| F14 | Pricing and market inefficiencies | Legal arbitrage, spread capture, inefficiency exploitation; includes unregulated credit, revenue-share, and financing structures, always with capital_role AT_RISK_CAPITAL |
| F15 | Hybrid opportunities | Assignment class for records whose secondary families are decisive for evaluation; carries the primary family in `secondary_families` |
| F16 | Emerging or uncategorized opportunities | Mandatory catch-all; includes recoveries, rebates, settlements, and unclaimed funds until a family exists; every entry is reviewed per SYS-05 |

Family assignment order when families overlap: payer first (SPONSOR_OR_GRANTOR pays: F09 or F11; BUSINESS pays for delivered demand: F04; PLATFORM pays for attention: F03), then what the operator supplies, then settlement mechanism. The assignment reason is logged on the mechanism record.

Secondary dimensions are recorded on every mechanism record (STR-13) and drive track assignment (FWK-10), deduplication (FWK-20), and risk typing (FWK-13):

| Dimension | Allowed values |
|---|---|
| payer_types (set) | CONSUMER, BUSINESS, PLATFORM, PROTOCOL, SPONSOR_OR_GRANTOR, MARKET_COUNTERPARTY |
| operator_supplies (set) | LABOR, CAPITAL, ASSET, DATA, ATTENTION |
| capital_role | NONE, WORKING_CAPITAL, AT_RISK_CAPITAL |
| platform_dependency_class | NONE, SINGLE_PLATFORM, MULTI_PLATFORM, CUSTODIAL |
| settlement_mechanism | DIRECT_PROCESSOR, PLATFORM_PAYOUT, EXCHANGE_OR_BROKER, ON_CHAIN, BANK_TRANSFER |
| payment_rail | CARD, BANK, WALLET, PLATFORM_BALANCE, CRYPTO |
| value_delivered_class | STANDARDIZED_DIGITAL_GOOD, STANDARDIZED_SERVICE_UNIT, METERED_SOFTWARE_ACCESS, AUDIENCE_ATTENTION, DEMAND_DELIVERY, DATASET_OR_REPORT, PARTICIPATION_AS_SUBJECT, IP_LICENSE, THIRD_PARTY_FULFILLED_GOOD, REFERRAL_OR_ONBOARDING, DIGITAL_PROPERTY_TRANSFER, DIGITAL_CAPACITY_RENTAL, PRIZE_OR_GRANT_ENTRY, RISK_BEARING_OR_LIQUIDITY, PROTOCOL_PARTICIPATION, SPREAD_CAPTURE, RECOVERY_OR_REBATE, OTHER |
| horizon_class | H30, H90, H365, H_OPEN |

WORKING_CAPITAL is capital recoverable by contract independent of price movement and counterparty solvency. AT_RISK_CAPITAL is every other capital the operator places, including stakes, bonds, deposits, and entry fees refundable on condition. `OTHER` in value_delivered_class forces F16 review.

### STR-02 Identifier scheme

Identifiers are immutable once issued, zero-padded, and never reused after merge or rejection.

| Prefix | Record | Notes |
|---|---|---|
| OPR-nnn | Operator profile | One per research cycle; stage 0 (SYS-00) |
| SWP-nnn-Fnn | Family sweep | One per family per sweep |
| OPP-nnnn | Opportunity candidate record | Evaluation unit; one per variant of a mechanism |
| MEC-nnnn | Mechanism record | Coverage and deduplication unit; one per unique signature |
| CLM-nnnnn | Claim | Row in the claim-evidence matrix |
| SO-nnnnn | Source | Row in the source register |
| AUT-nnn | Authority | Row in the authority register |
| ASM-nnnn | Assumption | Assumption register |
| CON-nnnn | Contradiction | Contradiction log |
| UNC-nnnn | Uncertainty | Uncertainty register |
| REJ-nnnn | Rejection | Rejection log |
| QUA-nnnn | Quarantine | Quarantine log |
| REG-nnnn | Regulatory verification | Regulatory verification log |
| DEC-nnnn | Decision | Decision log |
| EXP-nnnn | Validation experiment | Embedded in L3 record and decision log |
| POR-nnn | Portfolio | Portfolio feasibility record |
| FIX-nnn | Controlled hypothetical architecture fixture | `tests/` only (STR-14) |

### STR-03 Research depths

Four depths plus an identity step at the discovery freeze. A record may only deepen after the prior depth's required fields are complete. Fields are defined in `templates/opportunity-record.md`.

| Depth | Name | Purpose | Required content |
|---|---|---|---|
| L0 | Sighting | Capture breadth cheaply | OPP id, sweep id, lens, query id, primary family, one-line description, source locator with access date, date |
| Identity (at freeze, SYS-05) | Mechanism identity | Deduplicate before any screening | Signature fields (STR-13, UNKNOWN permitted until resolved at freeze), variant fields, `mec_id`, `dedup_result` |
| L1 | Preliminary screen | Cheap FAIL-only elimination | Component-track inputs and track (FWK-10), sales_mode, obvious prohibition and ethical exclusion, obvious platform unavailability, obvious laptop failure. Gate values at L1 are FAIL or DEFERRED only; DEFERRED means "not yet evaluated", never "assumed" |
| L2 | Investigation record | Resolve every applicable fatal gate | Claim rows for the mandatory claim set (EVD-03), gate values PASS, FAIL, or UNKNOWN for G1 to G7, payment and settlement path, cold-start evidence, dependency map with completeness attestation, feasibility fields, jurisdiction routing output, evidence-sufficiency review |
| L3 | Decision record | Decide and prepare for prioritization | Timing model, economic model, capital-risk model where applicable, decision state, confidence band, risk class, feasibility status, cash band, horizon class, prioritization result, reverification triggers; validation experiment design only for records selected under SYS-14 |

L2 exists to resolve fatal gates; a record is not blocked from L2 by a DEFERRED gate. Quarantine is raised only at the end of L2 or later. Only records with every applicable fatal gate at PASS may reach prioritization (FWK-47).

### STR-04 Decision state machine

| State | Meaning |
|---|---|
| DISCOVERED | L0 exists |
| MERGED | Identical variant of another OPP under the same mechanism; terminal unless promoted per FWK-20 |
| SCREENED | L1 complete, no FAIL |
| PROHIBITED | Verified legal prohibition (G1 FAIL) or ethical exclusion (G7 FAIL); terminal for current evidence |
| REJECTED | Any other fatal gate FAIL, or track-specific gate FAIL |
| QUARANTINED | Any fatal gate or mandatory claim UNKNOWN, OUTDATED, or in unresolved CONTRADICTION at end of L2 or later; carries an Open/TBD subtype (STR-05) |
| CONDITIONAL | All fatal gates PASS, one or more conditional gates open |
| ELIGIBLE | All fatal gates PASS, all ordering-required conditional gates closed, L3 complete |
| VALIDATION_PENDING | Validation experiment designed or running |
| VALIDATED | Experiment supported the tested claim |
| INVALIDATED | Experiment contradicted the tested claim |

Transitions and triggers:

| From | To | Trigger |
|---|---|---|
| DISCOVERED | MERGED | FWK-20: same signature and identical variant fields |
| DISCOVERED | SCREENED | L1 complete, no FAIL |
| DISCOVERED or SCREENED | PROHIBITED | G1 or G7 FAIL verified |
| SCREENED | REJECTED | G2, G3, G4, G5, G6 FAIL at L1 or L2 |
| SCREENED | QUARANTINED | Any gate or mandatory claim UNKNOWN, OUTDATED, or unresolved CONTRADICTION at end of L2 |
| SCREENED | CONDITIONAL | L2 and L3 complete, all fatal PASS, conditional open |
| SCREENED | ELIGIBLE | L2 and L3 complete, all fatal PASS, ordering-required conditional gates closed |
| QUARANTINED | SCREENED | Blocking item resolved per FWK-66; resume at the producing step |
| QUARANTINED | REJECTED or PROHIBITED | Blocking item resolved to FAIL |
| CONDITIONAL | ELIGIBLE | Last ordering-required conditional gate closed |
| CONDITIONAL | VALIDATION_PENDING | Only C1b open, experiment designed and selected per SYS-14 |
| CONDITIONAL or ELIGIBLE | QUARANTINED | Freshness expiry (FWK-60) or contradiction reopening (FWK-65) turns a gate or claim UNKNOWN |
| ELIGIBLE | VALIDATION_PENDING | Experiment designed per FWK-35 and selected per SYS-14 |
| VALIDATION_PENDING | VALIDATED or INVALIDATED | Experiment result recorded |
| Any non-terminal | REJECTED | Track-specific gate FAIL at L3 |
| MERGED | SCREENED | Promotion per FWK-20 when the survivor fails a variant-specific gate |
| REJECTED or PROHIBITED | SCREENED | Reopened per FWK-65 with new admissible evidence; prior decision preserved |

Every transition writes a DEC record. Bands and classes (FWK-12, FWK-13, FWK-14) are assigned only to records in CONDITIONAL, ELIGIBLE, VALIDATION_PENDING, VALIDATED, or INVALIDATED. PROHIBITED, REJECTED, QUARANTINED, and MERGED records carry no band.

### STR-05 Open/TBD status taxonomy

Open/TBD is a controlled status, never a placeholder. Each Open/TBD item carries exactly one subtype:

| Subtype | Meaning | Resolver |
|---|---|---|
| OPERATOR_INPUT_REQUIRED | Depends on an operator profile fact not supplied | Operator |
| FURTHER_RESEARCH_REQUIRED | Admissible evidence likely exists and has not been gathered | Researcher |
| PLATFORM_CONFIRMATION_REQUIRED | Only the platform can confirm (eligibility, limits, approval, documents) | Platform |
| PROFESSIONAL_LEGAL_REVIEW_REQUIRED | Needs qualified legal interpretation for the operator's facts | Professional |
| PROFESSIONAL_TAX_REVIEW_REQUIRED | Needs qualified tax interpretation | Professional |
| EVIDENCE_UNAVAILABLE | Credible evidence does not exist or cannot be accessed | None; stays unknown |

Operator-profile items are logged once on the OPR record, not per candidate. A released architecture contains no Open/TBD item without a subtype and no unfinished placeholder text.

### STR-06 Analytical tracks and components

Every record carries `component_tracks`, a set derived by FWK-10 from structured fields. The track is the single component when one exists and T5 when two or more exist.

| Component | Cash arises from |
|---|---|
| T1 Earned digital income | Delivering value to a payer in a standardized transaction |
| T2 Capital-risk returns | Placing capital at risk of loss beyond fees and direct costs; investment, speculation, trading, arbitrage with capital exposure, yield |
| T3 Rewards and incentive income | Referral, reward, grant, prize, bounty, or protocol incentive paid by a sponsor, platform, or protocol |
| T4 Longer-horizon asset creation | Building an asset whose base-case usable cash arrives after Day 30 |
| T5 Hybrid | Two or more components; inherits every component's controls; ordered with T2 when a capital component exists |

Tracks are compared only within themselves for ordering (FWK-45). An empty T2 ordering is the expected result of most cycles (CAP-01).

### STR-07 Project-level registers and the research root

Registers are kept once per research project. Real-research records live only under a `research/` directory created by the research cycle; the validator scans every file type there for fixture leakage (STR-14).

| Register | Template |
|---|---|
| Operator profile | `templates/operator-profile.md` |
| Mechanism registry (canonical holder of signature and variant fields) | `templates/mechanism-registry.md` |
| Claim-evidence matrix | `templates/claim-evidence-matrix.md` |
| Source register (freshness derived from tier) | `templates/source-register.md` |
| Authority register | `templates/authority-register.md` |
| Query log | `templates/query-log.md` |
| Family-sweep coverage | `templates/family-sweep-coverage.md` |
| Coverage audit | `templates/coverage-audit.md` |
| Assumption register | `templates/assumption-register.md` |
| Contradiction log | `templates/contradiction-log.md` |
| Uncertainty register (includes research limitations) | `templates/uncertainty-register.md` |
| Rejection log | `templates/rejection-log.md` |
| Quarantine log | `templates/quarantine-log.md` |
| Regulatory verification log | `templates/regulatory-verification-log.md` |
| Decision log | `templates/decision-log.md` |
| Capital-risk dashboard | `templates/capital-risk-dashboard.md` |
| Scenario table | `templates/scenario-table.md` |
| Cross-track table | `templates/cross-track-table.md` |
| Portfolio feasibility | `templates/portfolio-feasibility.md` |

Per-candidate content lives in one file per OPP built from `templates/opportunity-record.md` and its section fragments. Fields marked `computed: true` in a schema are produced by rule, never typed.

### STR-08 Claim status vocabulary and claim classes

Every material claim carries exactly one status. Assignment rules are EVD-06.

VERIFIED_FACT, STRONGLY_SUPPORTED, DIRECTIONAL, INFERENCE, ASSUMPTION, HYPOTHESIS, CONTRADICTION, UNKNOWN, OUTDATED.

Claim classes: LEGALITY, PLATFORM_ELIGIBILITY, PLATFORM_POLICY_COMPLIANCE, PAYOUT_PATH, FEES_AND_COSTS, DEMAND, EARNINGS_OR_CONVERSION, DISTRIBUTION_PERFORMANCE, FINANCIAL_EDGE, DEPENDENCY_AVAILABILITY. Every claim in these classes is decision-critical by construction; there is no researcher-set criticality flag. The mandatory claim set per component track is in EVD-03.

### STR-09 Dashboards

Five dashboards are produced from registers. None ranks across tracks.

| Dashboard | Rows | Columns |
|---|---|---|
| D1 Gate status | Every OPP | State, G1 to G7 values (DEFERRED at L1), blocking item and Open/TBD subtype, MEC id and variant key |
| D2 Evidence confidence | Every banded OPP | Band (FWK-12), mandatory claims by status, independent origin count |
| D3 Risk and feasibility | Every banded OPP | Risk class (FWK-13), feasibility status (FWK-38), risk types present, max plausible loss range, exposure versus limit |
| D4 30-day cash | Every banded OPP | Band (FWK-14) with CASH_C labelled "best case only", conservative, base, best day of usable cash, conservative pre-tax net collectible cash range, recovered principal shown separately, contingent items |
| D5 Capital-risk dashboard | Every OPP with a T2 component | Fields of `templates/capital-risk-dashboard.md` |

Quarantined, rejected, prohibited, and merged records appear on D1 only, with reasons. Records in ELIGIBLE with CASH_D render as ELIGIBLE_NO_30D_CASH. The portfolio view is a section of D4 built from POR records.

### STR-10 Report organization

A research report body contains: scope, Day 0 and operator profile status; coverage audit with saturation status per family and any COVERAGE_INCOMPLETE header; the five dashboards; per-track orderings and the scenario table; the cross-track table; the unassessed-risk, insufficient-evidence, and no-30-day-cash lists; validation experiments and results; portfolio results; the five-way validation status; limitations including the non-exhaustiveness statement (SYS-06) and any scalability notes, which are reported here only and never consumed by any ordering rule (FWK-15). Full quarantine, rejection, assumption, contradiction, and uncertainty lists are machine-generated appendices from the registers. Every ordering and table header states "pre-tax" and prints COVERAGE_INCOMPLETE when applicable.

### STR-11 Units, currencies, dates, and numeric provenance

- Money is stored with an ISO 4217 code and reported in AED at the documented rate on the access date, with the rate source logged. The conservative case widens conversions by the FX band design parameter (CHANGELOG). Original currency is retained.
- Dates are ISO 8601. Elapsed time is in calendar days. Effort is in hours and is a separate field from elapsed time.
- Every quantitative field is a range `{low, high}` with a `provenance_class` from: MEASURED, DOCUMENTED, ESTIMATED, STIPULATED, UNKNOWN. STIPULATED is legal only inside `tests/`. Fields typed `range|UNKNOWN` may hold the literal UNKNOWN.
- Reports show at most two significant figures; ordering comparisons use the rounded bounds (FWK-42, FWK-63).

### STR-12 Template schema convention

Every template begins with YAML front matter containing `template`, `version`, `owner_control`, and a `fields` list. Each field has `name`, `type`, `required` or `required_at`, and `consumer`. `consumer` lists the control IDs that read the field. A field with no decision consumer declares `consumer: [admin]` and a `justification`. `computed: true` marks a field produced by rule. Boolean and enum fields that carry an evidential judgment declare `evidence_ref: true`, meaning the row must cite a source, claim, REG, ASM, or OPR id in its `basis_id` companion field. The structural validator (`tests/validate.py`) checks consumers, admin justifications, enum allowed lists, and that every engine input field exists on a template.

### STR-13 Mechanism record and variant structure

A mechanism record (MEC) is the canonical holder of the signature. Signature fields: `value_delivered_class`, `payer_types`, `operator_supplies`, `payment_rail`, `settlement_mechanism`, `platform_dependency_class`, plus `signature_version`. Two records with equal signatures (set fields compared as sets) are the same mechanism (FWK-20). Cross-field validity: settlement ON_CHAIN requires payment_rail CRYPTO; EXCHANGE_OR_BROKER requires operator_supplies containing CAPITAL; a violation is a schema defect.

Variant fields identify an OPP within a MEC and do affect evaluation: `platform_id`, `geography`, `pricing_model`, `format`. Two sightings with equal signature and equal variant fields are one OPP (MERGED). Two sightings with equal signature and different variant fields are two OPPs under one MEC, each evaluated separately for G2, G3, G6, timing, and cash. The MEC also carries: primary family, secondary families, family assignment reason, component tracks, list of OPP ids, first and last seen, sweep ids, saturation contribution.

### STR-14 Fixture namespace isolation

Fixture identifiers use `FIX-` followed by three digits and exist only in `tests/`, including blind packs under `tests/blind/`. Fixture records use `provenance_class: STIPULATED`. No file under `research/` and no rule or template file may contain the pattern `FIX-` followed by three digits or a STIPULATED provenance value outside an `allowed:` list or the STR-11 definition. The validator enforces both across every file type under `research/` and every markdown or JSON file elsewhere.
