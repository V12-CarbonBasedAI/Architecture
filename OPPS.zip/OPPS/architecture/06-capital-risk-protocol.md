# 06 Capital-risk protocol (Framework module)

Owner layer: Framework module. This file owns every control that applies to records with a capital component (T2, and T5 with a capital component). Field shapes are in `templates/sections/capital-risk-model.md` and `templates/capital-risk-dashboard.md`. Jurisdiction routing is FWK-61.

### CAP-01 Applicability

The full protocol applies to every record whose component tracks (FWK-10) include T2. Conditional gate C5 closes only when no CAP field holds UNKNOWN. A record with `max_plausible_loss` UNKNOWN or `counterparty_regulatory_status` UNVERIFIABLE or UNKNOWN is QUARANTINED with EVIDENCE_UNAVAILABLE or PLATFORM_CONFIRMATION_REQUIRED. No candidate may opt out by describing itself as low risk, hedged, risk-free, or guaranteed. In most research cycles no record will satisfy CAP-09; an empty T2 ordering is the expected result, and D5 is the T2 deliverable.

### CAP-02 Capital fields

Required ranges with provenance, using the single names shared with the opportunity record: `capital_deployed`; `at_risk_capital`; `contractual_max_loss` (omitted when `contractual_max_loss_unlimited` is true); `max_plausible_loss` (the loss under documented adverse conditions including gap, liquidation, or counterparty failure, or the literal UNKNOWN). When contractual loss is unlimited, `max_plausible_loss` low bound must exceed `capital_deployed` high bound and risk type LEVERAGE is set.

### CAP-03 Drawdown, volatility, and liquidity

Record documented or measured maximum drawdown over the evidence period, the volatility measure with its window, and whether the full position can exit within one day without material slippage. Undocumented values are UNKNOWN and make `max_plausible_loss` UNKNOWN.

### CAP-04 Leverage and liquidation

Record leverage ratio, margin requirements, liquidation mechanics, and the price move that triggers liquidation. Leverage above 1 sets risk type LEVERAGE and `max_plausible_loss` must include liquidation costs.

### CAP-05 Counterparty and custody

Record who holds capital at each stage, the custody model, the counterparty's regulatory status for UAE residents (routed through FWK-61 class A4 or A5), and documented failure or freeze events. Every custodian is a dependency row of type CUSTODY_COUNTERPARTY with a `provider_id`.

### CAP-06 Fees, spread, financing, slippage, and withdrawal holds

Record trading fees, spread, financing or funding costs, borrow costs, withdrawal fees, documented withdrawal limits and holds, and expected slippage. Net-of-cost figures are the only return figures used anywhere. A zero fee or hold is recorded as DOCUMENTED, never assumed.

### CAP-07 Settlement and withdrawal

Map settlement and withdrawal through S05 to S11b (FWK-30), including trade settlement, exchange or broker withdrawal limits, on-chain confirmation, fiat off-ramp availability for the UAE, and bank acceptance of the inbound transfer. Any undocumented stage makes G3 UNKNOWN.

### CAP-08 Market-regime dependency

State the market conditions under which the mechanism's evidence was generated and whether the evidence spans more than one regime. Single-regime evidence caps FINANCIAL_EDGE at DIRECTIONAL (EVD-06).

### CAP-09 Evidence of persistent edge

The FINANCIAL_EDGE claim carries five items: `edge_out_of_sample` (results separate from any fitting period), `edge_net_of_costs` (net of all CAP-06 costs), `edge_sample_size` and period, `edge_trials_count` (variants tried, so overfitting can be assessed), and class A sourcing with `origin_id`. Absent any item, the claim is UNKNOWN. With all items and multi-regime evidence the claim follows EVD-06 tiering; with all items and a single regime it is at most DIRECTIONAL. `edge_status` on the model is computed from the claim, never typed. Edge is never inferred from a single profitable outcome, a backtest alone, or a promoter's claim.

### CAP-10 Backtest validity

A backtest used as evidence records data source and survivorship treatment, look-ahead controls, transaction-cost model, number of trials, and an overfitting assessment per EVD-14. A backtest failing any item, or a claim resting on a backtest alone, is at most HYPOTHESIS.

### CAP-11 Repeatability after costs

A profitable outcome is never classified as a repeatable income mechanism. Repeatability requires `repeatability_evidence` MULTI_PERIOD_NET: the net-of-cost result recurred across independent periods or instances under CAP-08 and CAP-09. Investment, speculation, trading, arbitrage, yield, and incentive capture are recorded under distinct `mechanism_kind` values and are never merged with earned income, which lives in the economic model's earned rows.

### CAP-12 Probability of impairment and ruin

Where credible inputs exist (documented return distribution, position sizing, loss limits), record the probability of capital impairment over 30 days and the probability of ruin, with ruin measured against the operator profile's loss limit or, when unsupplied, against `capital_total`, with method and inputs. Where inputs are not credible, both fields hold the literal UNKNOWN, never zero or a favorable placeholder.

### CAP-13 Regulatory and tax routing

Every T2 component is routed through FWK-61 classes A3, A4, A5, or A6 as triggered and through FWK-62; the record is QUARANTINED with PROFESSIONAL_LEGAL_REVIEW_REQUIRED until a professional opinion id is logged. `legal_review_status` and `tax_review_status` are separate fields; tax defaults to PROFESSIONAL_TAX_REVIEW_REQUIRED.

### CAP-14 Cases, reporting, and ordering of capital-risk outcomes

For the capital component the economic cases are built as follows: conservative realized return equals the negative of `max_plausible_loss`, so the conservative pre-tax NCC is at or below zero and CASH_A is unreachable for a capital component by construction; base and best realized returns are the documented median and best net-of-cost period returns only when `edge_status` is at least STRONGLY_SUPPORTED and regime span is MULTI_REGIME, otherwise UNKNOWN, which makes the case UNKNOWN and the band CASH_U. `recovered_principal` is computed per FWK-32. `expected_return` is UNKNOWN whenever `edge_status` is UNKNOWN, HYPOTHESIS, or DIRECTIONAL. Capital-risk records appear in the T2 ordering and the cross-track table only, never in any income ordering (FWK-45), and enter the T2 ordering only under FWK-47.

### CAP-15 Capital-risk dashboard

D5 (STR-09) is built from `templates/capital-risk-dashboard.md` and lists every record with a T2 component with the CAP-02, CAP-03, CAP-04, CAP-05, CAP-09, CAP-12, CAP-13, and CAP-14 fields. Any UNKNOWN is displayed as UNKNOWN.

### CAP-16 Wording cannot evade the protocol

Track assignment (FWK-10) and CAP-01 applicability are decided only by the structured triggers in FWK-10. Terms such as arbitrage, yield, staking, market-neutral, risk-free, passive, guaranteed, or spread capture have no effect. Any record meeting a FWK-10 capital trigger has a T2 component regardless of description or of the values a researcher types into `capital_role`, and this is tested (T-11).
